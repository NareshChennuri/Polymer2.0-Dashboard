/*
This module reads config settings from localConfig.json when running locally,
  or from the VCAPS environment variables when running in Cloud Foundry.
*/

var settings = {};

// checking NODE_ENV to load cloud properties from VCAPS
// or development properties from config.json.
// These properties are not needed for fetching mock data.
// Only needed if you want to connect to real Predix services.
var node_env = process.env.node_env || 'development';
if(node_env === 'development') {
  // use localConfig file
	var devConfig = require('./localConfig.json')[node_env];
	// console.log(devConfig);
	settings.base64ClientCredential = devConfig.base64ClientCredential;
	settings.loginBase64ClientCredential = devConfig.loginBase64ClientCredential;
	settings.clientId = devConfig.clientId;
	settings.uaaURL = devConfig.uaaURL;
	settings.tokenURL = devConfig.uaaURL;
	settings.appURL = devConfig.appURL;
	settings.callbackURL = devConfig.appURL + '/callback';

	settings.serviceURL = devConfig.serviceURL;
	settings.wsUsersURL = devConfig.wsUsersURL; // user services API
	settings.wsBasicURL = devConfig.wsBasicURL; // basic services API
	settings.wsCacheURL = devConfig.wsCacheURL; // cache services API
	settings.wsCatalogURL = devConfig.wsCatalogURL; // catalog services API
	settings.wsAEPURL = devConfig.wsAEPURL; // aep services API
	settings.projEcoAPI = devConfig.projEcoAPI; // economics services API 
	settings.bopServiceAPI = devConfig.bopServiceAPI; // BOP services API 

	settings.assetURL = devConfig.assetURL;
	settings.assetZoneId = devConfig.assetZoneId;
	settings.timeseriesZoneId = devConfig.timeseriesZoneId;
	settings.timeseriesURL = devConfig.timeseriesURL;

} else {
	// read VCAP_SERVICES
	var vcapsServices = JSON.parse(process.env.VCAP_SERVICES);


	// read VCAP_APPLICATION
	var vcapsApplication = JSON.parse(process.env.VCAP_APPLICATION);
	// console.log('Process ENV ===> ',process.env);
	settings.appURL = 'https://' + vcapsApplication.uris[0];
	settings.clientId = process.env.clientId;
	settings.uaaURL = process.env.uaaURL;
	settings.tokenURL = process.env.uaaURL;
	settings.callbackURL = settings.appURL + '/callback';
	settings.base64ClientCredential = process.env.base64ClientCredential;
	settings.loginBase64ClientCredential = process.env.loginBase64ClientCredential;
	settings.serviceURL = process.env.serviceURL;
	settings.wsUsersURL = process.env.wsUsersURL;
	settings.wsBasicURL = process.env.wsBasicURL; // basic services API
	settings.wsCacheURL = process.env.wsCacheURL; // cache services API
	settings.wsCatalogURL = process.env.wsCatalogURL; // catalog services API
	settings.wsAEPURL = process.env.wsAEPURL; // aep services API
	settings.projEcoAPI = process.env.projEcoAPI; // economics services API
	settings.bopServiceAPI = process.env.bopServiceAPI; // BOP services API
}
// console.log('config settings: ' + JSON.stringify(settings));

// This vcap object is used by the proxy module.
settings.buildVcapObjectFromLocalConfig = function(config) {
	'use strict';
	// console.log('local config: ' + JSON.stringify(config));
	var vcapObj = {};
	if (config.uaaURL) {
		vcapObj['predix-uaa'] = [{
			credentials: {
				uri: config.uaaURL
			}
		}];
	}
	if (config.timeseriesURL) {
		vcapObj['predix-timeseries'] = [{
			credentials: {
				query: {
					uri: config.timeseriesURL,
					'zone-http-header-value': config.timeseriesZoneId
				}
			}
		}];
	}
	if (config.assetURL) {
		vcapObj['predix-asset'] = [{
			credentials: {
				uri: config.assetURL,
				zone: {
					'http-header-value': config.assetZoneId
				}
			}
		}];
	}
	return vcapObj;
};

settings.isUaaConfigured = function() {
	// console.log('settings ===> ',settings);
	return settings.clientId &&
    settings.uaaURL &&
    settings.uaaURL.indexOf('https') === 0 &&
    settings.base64ClientCredential;
};

module.exports = settings;
