var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser'); // used for session cookie
var bodyParser = require('body-parser');
// simple in-memory session is used here. use connect-redis for production!!
var session = require('express-session');
var proxy = require('./routes/proxy'); // used when requesting data from real services.

var index = require('./routes/index');

// get config settings from local file or VCAPS env var in the cloud
var config = require('./predix-config');

var passport;  // only used if you have configured properties for UAA
// configure passport for oauth authentication with UAA
var passportConfig = require('./passport-config');

var userInfo = require('./routes/user-info');
// getting role info from the server
var userRole = require('./routes/user-role');

//parentUrl [baseUrl] for actual page redirect 
var parentUrl = `/`


// if running locally, we need to set up the proxy from local config file:
var node_env = process.env.node_env || 'development';
if (node_env === 'development') {
  var devConfig = require('./localConfig.json')[node_env];
	proxy.setServiceConfig(config.buildVcapObjectFromLocalConfig(devConfig));
	proxy.setUaaConfig(devConfig);
}

//a back-end java microservice used in the Build A Basic App learningpath
var windServiceURL = devConfig ? devConfig.windServiceURL : process.env.windServiceURL;

console.log('************'+node_env+'******************');

if (config.isUaaConfigured()) {
	passport = passportConfig.configurePassportStrategy(config);
}

//turns on or off text or links depending on which tutorial you are in, guides you to the next tutorial
var learningpaths = require('./learningpaths/learningpaths.js');

/**********************************************************************
       SETTING UP EXRESS SERVER
***********************************************************************/
var app = express();

app.set('trust proxy', 1);
app.use(cookieParser('predixsample'));
// Initializing default session store
// *** Use this in-memory session store for development only. Use redis for prod. **
app.use(session({
	secret: 'predixsample',
	name: 'cookie_name',
	proxy: true,
	resave: true,
	saveUninitialized: true}));

console.log('UAA Conf ===> ',config.isUaaConfigured());
if (config.isUaaConfigured()) {
  console.log('UAA Configured Succesfully');
	app.use(passport.initialize());
  // Also use passport.session() middleware, to support persistent login sessions (recommended).
	app.use(passport.session());
}

//Initializing application modules
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var server = app.listen(process.env.VCAP_APP_PORT || 5000, function () {
	console.log ('Server started on port: ' + server.address().port);
});

/****************************************************************************
	SET UP EXPRESS ROUTES
*****************************************************************************/

//route to retrieve learningpath info which drives what is displayed
app.get('/learning-paths', function(req, res) {
	//console.log(learningpaths);
	res.json({"learningPathsConfig": learningpaths.getLearningPaths(config)});
});

app.use(express.static(path.join(__dirname, process.env['base-dir'] ? process.env['base-dir'] : '../public')));

if (config.isUaaConfigured()) {
  console.log('UA')
	//Use this route to make the entire app secure.  This forces login for any path in the entire app.
  app.use('/', index);

  //fixing the refresh problem
  app.get('/login1', function(req, res) {
    // storing the page refreshed url
    parentUrl = req.query.parentUrl;
    // now redirecting to normal login flow
    res.redirect('/login');
  });

  app.get('/login', passport.authenticate('predix', {'scope': ''}), function(req, res) {
    console.log('Full URL ',req, req.params)
    // The request will be redirected to Predix for authentication, so this
    // function will not be called.
  });

  app.get('/userinfodetails', userInfo(config.uaaURL), function (req, res) {
    // res.send(req.user.details);
    res.send(req.user);
  });
  // route to fetch user info from UAA for use in the browser
  app.get('/userinfo', userInfo(config.uaaURL), function (req, res) {
    res.send(req.user.details);
    //res.send(req.user);
  });

   //for getting backend url in the code
   app.get('/getUrl', function (req, res) {
    res.send({
      url: config.serviceURL
    });
  });


  // access real Predix services using this route.
  // the proxy will add UAA token and Predix Zone ID.    
  app.use(['/predix-api', '/api'],
  passport.authenticate('main', {
    noredirect: true
  }),
  proxy.router);

  //callback route redirects to secure route after login
  app.get('/callback', passport.authenticate('predix', {
  	failureRedirect: '/'
  }), function(req, res) {
  	console.log('Redirecting to secure route...');
  	res.redirect('/windselect');
  });

  // example of calling a custom microservice.
  if (windServiceURL && windServiceURL.indexOf('https') === 0) {
    app.get('/api/services/windservices/*', passport.authenticate('main', { noredirect: true}),
      // if calling a secure microservice, you can use this middleware to add a client token.
      // proxy.addClientTokenMiddleware,
      proxy.customProxyMiddleware('/api', windServiceURL)
    );
  }

  /**
  ** this endpoint is required by Timeseries.js, for winddata is switch
  **/
    app.get('/config-details', passport.authenticate('main', {
      noredirect: true //Don't redirect a user to the authentication page, just show an error
      }), function(req, res) {
      console.log('Accessing the secure route data');
      res.setHeader('Content-Type', 'application/json');
      var configuration = {};
      if(!windServiceURL) {
        configuration.connectToTimeseries = "true";
      }
      if(config.assetURL && config.assetZoneId) {
        configuration.isConnectedAssetEnabled = "true";
      }
      res.send(JSON.stringify(configuration));

    });

  //Or you can follow this pattern to create secure routes,
  // if only some portions of the app are secure.
  app.get('/secure', passport.authenticate('main', {
    noredirect: true //Don't redirect a user to the authentication page, just show an error
    }), function(req, res) {
    console.log('Accessing the secure route ');
    // modify this to send a secure.html file if desired.
    res.sendFile(path.join(__dirname + '/../secure/secure.html'));
    // res.send('<h2>This is a sample secure route.</h2>');
  });

  app.get('/windselect', passport.authenticate('main', {
    noredirect: true //Don't redirect a user to the authentication page, just show an error
    }), function(req, res) {
  	console.log('redirect to parent url if present ...########## - ' + parentUrl);
    if (parentUrl && parentUrl != '/') {
      var tmpParentUrl = parentUrl;
      parentUrl = '/';
      res.redirect('/windselect/#'+tmpParentUrl);
    } else {
  	  // modify this to send a secure.html file if desired.
  	  parentUrl = '/';
      // console.log('ws1'+ path.join(__dirname + '/../windselect/'));
      res.sendFile(path.join(__dirname + '/../windselect/index.html'));
      // res.send('<h2>This is a sample secure route.</h2>');
  	}
  });
  
  app.get('/windselect/*', passport.authenticate('main', {
    noredirect: true //Don't redirect a user to the authentication page, just show an error
    }), function(req, res) {
    // console.log('Accessing the ws2 route');
    // modify this to send a secure.html file if desired.
    // console.log('ws2'+ path.join(__dirname + '/../windselect/'));
    res.sendFile(path.join(__dirname + '/../windselect/'));
    // res.send('<h2>This is a sample secure route.</h2>');
  });

  app.get('/getParentUrl',  function(req, res) {
    console.log('Accessing the ws1 route');
    res.json({ success: true, parentUrl })
  });

   /****************************************************
   * PROXY ROUTES
   ****************************************************/
  // var serviceURL = config.serviceURL;
  var wsUsersURL = config.wsUsersURL;
  var wsBasicURL = config.wsBasicURL;
  var wsCacheURL = config.wsCacheURL;
  var wsCatalogURL = config.wsCatalogURL;
  var wsAEPURL = config.wsAEPURL;
  var projEcoAPI = config.projEcoAPI;
  var bopServiceAPI  = config.bopServiceAPI;

  app.get('/ws-user/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-user', wsUsersURL)
  );

  app.post('/ws-user/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-user', wsUsersURL)
  );

  app.get('/ws-basic/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-basic', wsBasicURL)
  );

  app.post('/ws-basic/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-basic', wsBasicURL)
  );
  
  app.put('/ws-basic/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-basic', wsBasicURL)
  );
 
  app.options('/ws-basic/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-basic', wsBasicURL)
  );
  
  app.get('/ws-cache/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-cache', wsCacheURL)
  );

  app.post('/ws-cache/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-cache', wsCacheURL)
  );
  
  app.options('/ws-cache/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-cache', wsCacheURL)
  );
  
  app.put('/ws-cache/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-cache', wsCacheURL)
  );

  app.get('/ws-catalog/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-catalog', wsCatalogURL)
  );

  app.post('/ws-catalog/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-catalog', wsCatalogURL)
  );
 
  app.options('/ws-catalog/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-catalog', wsCatalogURL)
  );
 
  app.put('/ws-catalog/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-catalog', wsCatalogURL)
  );

  app.get('/ws-aep/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-aep', wsAEPURL)
  );

  app.post('/ws-aep/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-aep', wsAEPURL)
  );

  app.put('/ws-aep/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-aep', wsAEPURL)
  );
 
  app.options('/ws-aep/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-aep', wsAEPURL)
  );

  app.get('/ws-projeco/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-projeco', projEcoAPI)
  );

  app.post('/ws-projeco/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-projeco', projEcoAPI)
  );
 
  app.options('/ws-projeco/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-projeco', projEcoAPI)
  );

    app.put('/ws-bop/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-bop', bopServiceAPI)
  );
  
   app.get('/ws-bop/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-bop', bopServiceAPI)
  );

  app.post('/ws-bop/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-bop', bopServiceAPI)
  );
 
  app.options('/ws-bop/*',
    passport.authenticate('main', {
      noredirect: true
    }),
    proxy.addClientTokenMiddleware,
    proxy.customProxyMiddleware('/ws-bop', bopServiceAPI)
  ); 


}

//logout route
app.get('/logout', function(req, res) {
	req.session.destroy();
	req.logout();
  passportConfig.reset(); //reset auth tokens
  res.redirect(config.uaaURL + '/logout?redirect=' + config.appURL);
});

app.get('/favicon.ico', function (req, res) {
	res.send('favicon.ico');
});


////// error handlers //////
// catch 404 and forward to error handler
app.use(function(err, req, res, next) {
  console.error(err.stack);
	var err = new Error('Not Found');
	err.status = 404;
	next(err);
});

// development error handler - prints stacktrace
if (node_env === 'development') {
	app.use(function(err, req, res, next) {
		if (!res.headersSent) {
			res.status(err.status || 500);
			res.send({
				message: err.message,
				error: err
			});
		}
	});
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
	if (!res.headersSent) {
		res.status(err.status || 500);
		res.send({
			message: err.message,
			error: {}
		});
	}
});

module.exports = app;
