var express = require('express');
var router = express.Router();
var fullUrl = ``;

/* GET index page. */

router.use(function(req,res,next){
  // console.log('index.html from router - index.js');
  // console.log('Full URL ', req.protocol + '://' + req.get('host') + req.originalUrl)
  next();
});

router.get('/', function(req, res, next) {
  res.sendFile('index.html');
});

module.exports = router;
