//custom middleware to get the user roel from onewind backend
//function below hits the onewind backend service to get user role
var request = require('request');
var getRole = function (accessToken, baseApi, sso, callback) {

  var options = {
    method: 'POST',
    url: baseApi + '/user/authenticate',
    headers: {
      'Authorization': 'Bearer ' + accessToken,
      'Content-Type': 'application/json',
    },
    // qs: {
    //   'ssoId': sso
    //     }
    body: JSON.stringify({
      "ssoId": sso,
      "applicationName": "ONEWIND"
    })
  };
  request(options, function (err, response, body) {
    if (!err) {
      var role = JSON.parse(body);
      callback(role);

    } else {
      console.error('ERROR in fetching role: ' + err);

    }
  });
};



module.exports = function (serviceURL) {
  return function (req, res, next) {
    // check if access value exists
    if (typeof req.user.role == "undefined" || req.user.role == false) {
      // make request to endpoint

      getRole(req.user.ticket.access_token, serviceURL, req.user.details.user_name, function (role) {

        req.user.role = false;
        if (role.data) {
          for (var each in role.data.roles) {
            if (role.data.roles[each].match(/^onewind.*$/i)) {
              role.data.roles[each] = role.data.roles[each].split('_')[1];
            }
          }
          
          if (role.data.roles.includes("Commercial_Leader") || role.data.roles.includes("Application_Engineer") || role.data.roles.includes("Admin")) {
            req.user.role = true;
            next();
          } else {
            req.user.role = false;
            res.redirect("/unauthorized");
            
          }
        } else {
          req.user.role = false;
          if (role.message == null)
            role.message = "Something went wrong."

          var response = '<body style="margin: 0;"><div  style="border: 2px solid black;background-color: black;color: black;margin: 0;height: calc(100% - 4px);width: calc(100% - 4px);left: 0px;">' +
            '<div style="background-color: white;color: black;height: 30%;width: 60%;padding: 16px;margin: 0 auto; margin-top: 10%;">' +
            '<p>Hello User,</p>' +
            '<p>Thank you for trying to login to OneWIND. </p><b>' +
            role.message +
            '</b><p>You can drop a note to OneWIND Support at <a href="mailto:OneWIND.Support@ge.com" class="cursor"><b><u>OneWIND.Support@ge.com</u></b></a> ' +
            ' if you have questions or need help.  </p>' +
            '<p>Thanks,<br />OneWIND Team.</p>' +
            ' </div>' +
            '</div></body>';
          if (role.code == "404") {
            res.redirect("/unauthorized");
          } else
            res.send(response);

        }

      });
    } else if (req.user.role) {
      next();
    } else {
      res.redirect("/unauthorized");
    }
  }
};