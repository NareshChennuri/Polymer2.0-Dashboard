import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { ActionsComponent } from './actions/actions.component';
import { ProformaReportsComponent } from './proforma-reports/proforma-reports.component';
import { PowerCurveComponent } from './power-curve/power-curve.component';

const routes: Routes = [
  { path: '', redirectTo: '/sessions', pathMatch: 'full' },
  { path: 'sessions', component: DashboardComponent },
  { path: 'actions', component: ActionsComponent },
  { path: 'actions/:id', component: ActionsComponent },
  { path: 'proforma-reports', component: ProformaReportsComponent },
  { path: 'proforma-reports/:id', component: ProformaReportsComponent },
  { path: 'powerCurve', component: PowerCurveComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,  { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
