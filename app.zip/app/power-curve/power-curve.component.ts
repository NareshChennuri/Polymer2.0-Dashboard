import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from '../shared/api/data.service';
import { GlobalsService } from '../shared/api/globals.service';
import { combineLatest, Subscription } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-power-curve',
  templateUrl: './power-curve.component.html',
  styleUrls: ['./power-curve.component.css']
})
export class PowerCurveComponent implements OnInit, OnDestroy {
  private combinedSubscribe: Subscription;
  private getManufacturersSubscribe: Subscription;
  private getTurbinesPCListSubscribe: Subscription;
  private getPowerCurveDetailsSubscribe: Subscription;
  private savePowerCurveDetailsSubscribe: Subscription;
  private uploadPCFileSubscribe: Subscription;
  manufacturers: any[];
  turbineDetails: any[];
  currentUser: any;
  selectedCountry: any;
  selectedState: any;
  pvalues: any[] = [];
  windselectId: any;
  powerCurveDetails: any = {};
  powercurveList: any;
  machineTypeList: any[] = [];
  machineType: String;
  pcdata: any = [];
  turbineId: number;
  uploadresp: any;
  thrustCurveId: any;
  manufacturersList: any[];
  fileData: File = null;
  input_up: any;
  constructor(
    private dataService: DataService,
    private globals: GlobalsService,
    private http: HttpClient,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.resetForm();
    this.machineTypeList = [
      { id: 'OnShore', name: 'OnShore' },
      { id: 'OffShore', name: 'OffShore' }
    ];
    this.getManufactureList();
    const sessionDtls$ = this.globals.currentSession;
    const manufacturersList$ = this.dataService.getManufacturers();
    const getPvalues$ = this.dataService.getPValues();
    const getTurbines$ = this.dataService.getTurbines();
    const curretCountry$ = this.globals.currentCountry;
    const curretState$ = this.globals.currentState;
    const currentUser$ = this.globals.currentUser;
    const combined = combineLatest(
      sessionDtls$,
      curretCountry$,
      curretState$,
      currentUser$,
      manufacturersList$
    );

    this.combinedSubscribe = combined.subscribe(
      ([sessionDtls, country, state, currentUser, manufacturers]) => {
        this.windselectId = sessionDtls;
        this.selectedCountry = country;
        this.selectedState = state;
        this.currentUser = currentUser;
        this.manufacturers = manufacturers;
      }
    );
  }

  getManufactureList() {
    this.getManufacturersSubscribe = this.dataService.getManufacturers().subscribe(manufacturers => {
      this.manufacturers = manufacturers;
      this.manufacturersList = manufacturers;
    });
  }

  manufacturerChange($event, trbId) {
    const manufacturer = $event.value;
    if (manufacturer) {
      this.getTurbinesPCListSubscribe = this.dataService
        .getTurbinesPCList(manufacturer, this.currentUser.roleId)
        .subscribe(items => {
          this.manufacturers.filter(item => {
            if (item.id === trbId) {
              this.powercurveList = items;
              return item;
            }
          });
        });
    }
  }
  public pcInfoChange($eve) {
    this.turbineId = $eve.value;
  }
  public searchPC() {
    this.powerCurveDetails = {};
    this.pcdata = [];
    // Search Power Curve API Call
    const getPCDataReq = {
      id: this.turbineId
    };
    this.getPowerCurveDetailsSubscribe = this.dataService
      .getPowerCurveDetails(getPCDataReq)
      .subscribe(pcresp => {
        const manufacturerName = this.manufacturersList.filter(
          result => pcresp.manufacturers === result.id
        );
        if (pcresp.thrustcurveMasterDetails == null) {
          console.log('test');
          this.powerCurveDetails = {
            id: pcresp.manufacturers,
            companyId: pcresp.manufacturers,
            turbineId: pcresp.id,
            companyName: manufacturerName[0].manufacturer,
            turbineName: pcresp.turbineName,
            namePlateRatingMw: pcresp.namePlateRatingMw,
            rotorDiameter: pcresp.rotorDiameter,
            revisionNumber: pcresp.revisionNumber || '',
            hubHeight1: pcresp.hubHeight1,
            hubHeight2: pcresp.hubHeight2,
            hubHeight3: pcresp.hubHeight3,
            hubHeight4: pcresp.hubHeight4,
            hubHeight5: pcresp.hubHeight5,
            hubHeight6: pcresp.hubHeight6,
            hubHeight7: pcresp.hubHeight7,
            hubHeight8: pcresp.hubHeight8,
            referenzertrag1: pcresp.referenzertrag1,
            referenzertrag2: pcresp.referenzertrag2,
            referenzertrag3: pcresp.referenzertrag3,
            referenzertrag4: pcresp.referenzertrag4,
            machineTypeOnshoreOffshore: pcresp.machineTypeOnshoreOffshore,
            manufacturers: pcresp.manufacturers,
            turbulence: pcresp.turbulence,
            cpFactor: pcresp.cpFactor,
            cutInSpeed: pcresp.cutInSpeed,
            cutOutSpeed: pcresp.cutOutSpeed,
            utilitiesConsumed: pcresp.utilitiesConsumed,
            wtgClass: pcresp.wtgClass,
            wtgForMarketingUseOnly: pcresp.wtgForMarketingUseOnly,
            wtgForTechnicalEvaluation: pcresp.wtgForTechnicalEvaluation,
            thrustcurveMasterDetailsId: pcresp.thrustcurveMasterDetails
              ? pcresp.thrustcurveMasterDetails.thrustcurveMasterDetailsId
              : 0,
            turbineStatus: pcresp.turbineStatus,
            customerStatus: pcresp.customerStatus,
            commentsAddpc: pcresp.commentsAddpc,
            towerDiameter: pcresp.towerDiameter,
            bladeLength: pcresp.bladeLength,
            bladeMass: pcresp.bladeMass,
            nacelleMass: pcresp.nacelleMass,
            topHeadMass: pcresp.topHeadMass
          };
          this.thrustCurveId = this.powerCurveDetails.thrustcurveMasterDetailsId;
          for (let i = 1; i <= 30; i++) {
            const windSpeed = 'windSpeed' + i;
            const temp = {
              windSpeed: i,
              powerCurve: pcresp[windSpeed],
              thrustCurve: 0,
              gencalc: 0
            };
            this.pcdata.push(temp);
            const temp1 = {
              windSpeed: i + 0.5,
              powerCurve: 0,
              thrustCurve: 0,
              gencalc: 0
            };
            if (i <= 29) {
              this.pcdata.push(temp1);
            }
          }
        } else if (pcresp) {
          this.powerCurveDetails = {
            id: pcresp.manufacturers,
            companyId: pcresp.manufacturers,
            turbineId: pcresp.id,
            companyName: manufacturerName[0].manufacturer,
            turbineName: pcresp.turbineName,
            namePlateRatingMw: pcresp.namePlateRatingMw,
            rotorDiameter: pcresp.rotorDiameter,
            revisionNumber: pcresp.revisionNumber || '',
            hubHeight1: pcresp.hubHeight1,
            hubHeight2: pcresp.hubHeight2,
            hubHeight3: pcresp.hubHeight3,
            hubHeight4: pcresp.hubHeight4,
            hubHeight5: pcresp.hubHeight5,
            hubHeight6: pcresp.hubHeight6,
            hubHeight7: pcresp.hubHeight7,
            hubHeight8: pcresp.hubHeight8,
            referenzertrag1: pcresp.referenzertrag1,
            referenzertrag2: pcresp.referenzertrag2,
            referenzertrag3: pcresp.referenzertrag3,
            referenzertrag4: pcresp.referenzertrag4,
            machineTypeOnshoreOffshore: pcresp.machineTypeOnshoreOffshore,
            manufacturers: pcresp.manufacturers,
            turbulence: pcresp.turbulence,
            cpFactor: pcresp.cpFactor,
            cutInSpeed: pcresp.cutInSpeed,
            cutOutSpeed: pcresp.cutOutSpeed,
            utilitiesConsumed: pcresp.utilitiesConsumed,
            wtgClass: pcresp.wtgClass,
            wtgForMarketingUseOnly: pcresp.wtgForMarketingUseOnly,
            wtgForTechnicalEvaluation: pcresp.wtgForTechnicalEvaluation,
            thrustcurveMasterDetailsId: pcresp.thrustcurveMasterDetails
              ? pcresp.thrustcurveMasterDetails.thrustcurveMasterDetailsId
              : 0,
            turbineStatus: pcresp.turbineStatus,
            customerStatus: pcresp.customerStatus,
            commentsAddpc: pcresp.commentsAddpc,
            towerDiameter: pcresp.towerDiameter,
            bladeLength: pcresp.bladeLength,
            bladeMass: pcresp.bladeMass,
            nacelleMass: pcresp.nacelleMass,
            topHeadMass: pcresp.topHeadMass
          };
          this.thrustCurveId = this.powerCurveDetails.thrustcurveMasterDetailsId;
          // wind speed table data mapping
          for (let i = 1; i <= 30; i++) {
            const windSpeed = 'windSpeed' + i;
            const thrustSpeed = 'thrustSpeed' + i;
            const cps = 'cps' + i;
            const temp = {
              windSpeed: i,
              powerCurve: pcresp[windSpeed],
              thrustCurve: pcresp.thrustcurveMasterDetails[thrustSpeed] || 0,
              gencalc: pcresp.thrustcurveMasterDetails[cps] || 0
            };
            this.pcdata.push(temp);
            const thrustSpeed_5 = 'thrustSpeed' + i + '_5';
            const cps_5 = 'cps' + i + '_5';
            const temp1 = {
              windSpeed: i + 0.5,
              powerCurve: 0,
              thrustCurve: pcresp.thrustcurveMasterDetails[thrustSpeed_5] || 0,
              gencalc: pcresp.thrustcurveMasterDetails[cps_5] || 0
            };
            if (i <= 29) {
              this.pcdata.push(temp1);
            }
          }
          this.toastr.success(`Power Curve Details Retrieved Successfully!!`);
        }
      });
  }
  public machineTypeChange($event) {
    this.powerCurveDetails.machineTypeOnshoreOffshore = $event.value;
  }

  public resetForm() {
    this.powerCurveDetails = {};
    this.pcdata = [];
    for (let i = 1; i <= 30; i++) {
      const temp = {
        windSpeed: i,
        powerCurve: '',
        thrustCurve: '',
        gencalc: ''
      };
      this.pcdata.push(temp);
      const temp1 = {
        windSpeed: i + 0.5,
        powerCurve: '',
        thrustCurve: '',
        gencalc: ''
      };
      if (i <= 29) {
        this.pcdata.push(temp1);
      }
    }
  }
  public addNewPC() {
    // Form Reset
    this.resetForm();
    this.thrustCurveId = 0;
  }
  public savePC() {
    // Save Power Curve API Call
    const savePCDataReq = {
      id: this.powerCurveDetails.turbineId || 0,
      turbineId: this.powerCurveDetails.turbineId || 0,
      turbineName: this.powerCurveDetails.turbineName || '',
      namePlateRatingMw: this.powerCurveDetails.namePlateRatingMw || 0,
      rotorDiameter: this.powerCurveDetails.rotorDiameter,
      hubHeight1: this.powerCurveDetails.hubHeight1 || 0,
      hubHeight2: this.powerCurveDetails.hubHeight2 || 0,
      hubHeight3: this.powerCurveDetails.hubHeight3 || 0,
      hubHeight4: this.powerCurveDetails.hubHeight4 || 0,
      hubHeight5: this.powerCurveDetails.hubHeight5 || 0,
      hubHeight6: this.powerCurveDetails.hubHeight6 || 0,
      hubHeight7: this.powerCurveDetails.hubHeight7 || 0,
      hubHeight8: this.powerCurveDetails.hubHeight8 || 0,
      referenzertrag1: this.powerCurveDetails.referenzertrag1 || 0,
      referenzertrag2: this.powerCurveDetails.referenzertrag2 || 0,
      referenzertrag3: this.powerCurveDetails.referenzertrag3 || 0,
      referenzertrag4: this.powerCurveDetails.referenzertrag4 || 0,
      machineTypeOnshoreOffshore: this.powerCurveDetails
        .machineTypeOnshoreOffshore,
      manufacturers: this.powerCurveDetails.companyId,
      turbulence: this.powerCurveDetails.turbulence || 0,
      cpFactor: this.powerCurveDetails.cpFactor || 0,
      cutInSpeed: this.powerCurveDetails.cutInSpeed || 0,
      cutOutSpeed: this.powerCurveDetails.cutOutSpeed || 0,
      utilitiesConsumed: this.powerCurveDetails.utilitiesConsumed || 0,
      wtgClass: this.powerCurveDetails.wtgClass || 0,
      wtgForMarketingUseOnly:
        this.powerCurveDetails.wtgForMarketingUseOnly || 0,
      wtgForTechnicalEvaluation:
        this.powerCurveDetails.wtgForTechnicalEvaluation || 0,
      yearOfIntroduction: null,
      windSpeed1: this.pcdata[0].powerCurve || 0,
      windSpeed2: this.pcdata[2].powerCurve || 0,
      windSpeed3: this.pcdata[4].powerCurve || 0,
      windSpeed4: this.pcdata[6].powerCurve || 0,
      windSpeed5: this.pcdata[8].powerCurve || 0,
      windSpeed6: this.pcdata[10].powerCurve || 0,
      windSpeed7: this.pcdata[12].powerCurve || 0,
      windSpeed8: this.pcdata[14].powerCurve || 0,
      windSpeed9: this.pcdata[16].powerCurve || 0,
      windSpeed10: this.pcdata[18].powerCurve || 0,
      windSpeed11: this.pcdata[20].powerCurve || 0,
      windSpeed12: this.pcdata[22].powerCurve || 0,
      windSpeed13: this.pcdata[24].powerCurve || 0,
      windSpeed14: this.pcdata[26].powerCurve || 0,
      windSpeed15: this.pcdata[28].powerCurve || 0,
      windSpeed16: this.pcdata[30].powerCurve || 0,
      windSpeed17: this.pcdata[32].powerCurve || 0,
      windSpeed18: this.pcdata[34].powerCurve || 0,
      windSpeed19: this.pcdata[36].powerCurve || 0,
      windSpeed20: this.pcdata[38].powerCurve || 0,
      windSpeed21: this.pcdata[40].powerCurve || 0,
      windSpeed22: this.pcdata[42].powerCurve || 0,
      windSpeed23: this.pcdata[44].powerCurve || 0,
      windSpeed24: this.pcdata[46].powerCurve || 0,
      windSpeed25: this.pcdata[48].powerCurve || 0,
      windSpeed26: this.pcdata[50].powerCurve || 0,
      windSpeed27: this.pcdata[52].powerCurve || 0,
      windSpeed28: this.pcdata[54].powerCurve || 0,
      windSpeed29: this.pcdata[56].powerCurve || 0,
      windSpeed30: this.pcdata[58].powerCurve || 0,
      lastModifiedDate: '2017-03-02T00:00:00.000+0000',
      remarks: '',
      turbineStatus: this.powerCurveDetails.turbineStatus,
      modifiedby: '',
      customerStatus: this.powerCurveDetails.customerStatus,
      commentsAddpc: this.powerCurveDetails.commentsAddpc || '',
      towerDiameter: this.powerCurveDetails.towerDiameter || 0,
      bladeLength: this.powerCurveDetails.bladeLength || 0,
      bladeMass: this.powerCurveDetails.bladeMass || 0,
      nacelleMass: this.powerCurveDetails.nacelleMass || 0,
      topHeadMass: this.powerCurveDetails.topHeadMass || 0,
      manufacturerId: {
        id: this.powerCurveDetails.id,
        manufacturer: this.powerCurveDetails.companyName,
        oem: this.powerCurveDetails.companyName,
        status: 'Active'
      },
      thrustcurveMasterDetails: {
        thrustcurveMasterDetailsId: this.thrustCurveId,
        thrustSpeed1: this.pcdata[0].thrustCurve || 0,
        thrustSpeed2: this.pcdata[2].thrustCurve || 0,
        thrustSpeed3: this.pcdata[4].thrustCurve || 0,
        thrustSpeed4: this.pcdata[6].thrustCurve || 0,
        thrustSpeed5: this.pcdata[8].thrustCurve || 0,
        thrustSpeed6: this.pcdata[10].thrustCurve || 0,
        thrustSpeed7: this.pcdata[12].thrustCurve || 0,
        thrustSpeed8: this.pcdata[14].thrustCurve || 0,
        thrustSpeed9: this.pcdata[16].thrustCurve || 0,
        thrustSpeed10: this.pcdata[18].thrustCurve || 0,
        thrustSpeed11: this.pcdata[20].thrustCurve || 0,
        thrustSpeed12: this.pcdata[22].thrustCurve || 0,
        thrustSpeed13: this.pcdata[24].thrustCurve || 0,
        thrustSpeed14: this.pcdata[26].thrustCurve || 0,
        thrustSpeed15: this.pcdata[28].thrustCurve || 0,
        thrustSpeed16: this.pcdata[30].thrustCurve || 0,
        thrustSpeed17: this.pcdata[32].thrustCurve || 0,
        thrustSpeed18: this.pcdata[34].thrustCurve || 0,
        thrustSpeed19: this.pcdata[36].thrustCurve || 0,
        thrustSpeed20: this.pcdata[38].thrustCurve || 0,
        thrustSpeed21: this.pcdata[40].thrustCurve || 0,
        thrustSpeed22: this.pcdata[42].thrustCurve || 0,
        thrustSpeed23: this.pcdata[44].thrustCurve || 0,
        thrustSpeed24: this.pcdata[46].thrustCurve || 0,
        thrustSpeed25: this.pcdata[48].thrustCurve || 0,
        thrustSpeed26: this.pcdata[50].thrustCurve || 0,
        thrustSpeed27: this.pcdata[52].thrustCurve || 0,
        thrustSpeed28: this.pcdata[54].thrustCurve || 0,
        thrustSpeed29: this.pcdata[56].thrustCurve || 0,
        thrustSpeed30: this.pcdata[58].thrustCurve || 0,
        lastModifiedDate: '2017-03-02T00:00:00.000+0000',
        remarks: null,
        turbineStatus: 'Active',
        modifiedby: '208',
        cps1: this.pcdata[0].gencalc || 0,
        cps2: this.pcdata[2].gencalc || 0,
        cps3: this.pcdata[4].gencalc || 0,
        cps4: this.pcdata[6].gencalc || 0,
        cps5: this.pcdata[8].gencalc || 0,
        cps6: this.pcdata[10].gencalc || 0,
        cps7: this.pcdata[12].gencalc || 0,
        cps8: this.pcdata[14].gencalc || 0,
        cps9: this.pcdata[16].gencalc || 0,
        cps10: this.pcdata[18].gencalc || 0,
        cps11: this.pcdata[20].gencalc || 0,
        cps12: this.pcdata[22].gencalc || 0,
        cps13: this.pcdata[24].gencalc || 0,
        cps14: this.pcdata[26].gencalc || 0,
        cps15: this.pcdata[28].gencalc || 0,
        cps16: this.pcdata[30].gencalc || 0,
        cps17: this.pcdata[32].gencalc || 0,
        cps18: this.pcdata[34].gencalc || 0,
        cps19: this.pcdata[36].gencalc || 0,
        cps20: this.pcdata[38].gencalc || 0,
        cps21: this.pcdata[40].gencalc || 0,
        cps22: this.pcdata[42].gencalc || 0,
        cps23: this.pcdata[44].gencalc || 0,
        cps24: this.pcdata[46].gencalc || 0,
        cps25: this.pcdata[48].gencalc || 0,
        cps26: this.pcdata[50].gencalc || 0,
        cps27: this.pcdata[52].gencalc || 0,
        cps28: this.pcdata[54].gencalc || 0,
        cps29: this.pcdata[56].gencalc || 0,
        cps30: this.pcdata[58].gencalc || 0,
        thrustSpeed1_5: this.pcdata[1].thrustCurve || 0,
        thrustSpeed2_5: this.pcdata[3].thrustCurve || 0,
        thrustSpeed3_5: this.pcdata[5].thrustCurve || 0,
        thrustSpeed4_5: this.pcdata[7].thrustCurve || 0,
        thrustSpeed5_5: this.pcdata[9].thrustCurve || 0,
        thrustSpeed6_5: this.pcdata[11].thrustCurve || 0,
        thrustSpeed7_5: this.pcdata[13].thrustCurve || 0,
        thrustSpeed8_5: this.pcdata[15].thrustCurve || 0,
        thrustSpeed9_5: this.pcdata[17].thrustCurve || 0,
        thrustSpeed10_5: this.pcdata[19].thrustCurve || 0,
        thrustSpeed11_5: this.pcdata[21].thrustCurve || 0,
        thrustSpeed12_5: this.pcdata[23].thrustCurve || 0,
        thrustSpeed13_5: this.pcdata[25].thrustCurve || 0,
        thrustSpeed14_5: this.pcdata[27].thrustCurve || 0,
        thrustSpeed15_5: this.pcdata[29].thrustCurve || 0,
        thrustSpeed16_5: this.pcdata[31].thrustCurve || 0,
        thrustSpeed17_5: this.pcdata[33].thrustCurve || 0,
        thrustSpeed18_5: this.pcdata[35].thrustCurve || 0,
        thrustSpeed19_5: this.pcdata[37].thrustCurve || 0,
        thrustSpeed20_5: this.pcdata[39].thrustCurve || 0,
        thrustSpeed21_5: this.pcdata[41].thrustCurve || 0,
        thrustSpeed22_5: this.pcdata[43].thrustCurve || 0,
        thrustSpeed23_5: this.pcdata[45].thrustCurve || 0,
        thrustSpeed24_5: this.pcdata[47].thrustCurve || 0,
        thrustSpeed25_5: this.pcdata[49].thrustCurve || 0,
        thrustSpeed26_5: this.pcdata[51].thrustCurve || 0,
        thrustSpeed27_5: this.pcdata[53].thrustCurve || 0,
        thrustSpeed28_5: this.pcdata[55].thrustCurve || 0,
        thrustSpeed29_5: this.pcdata[57].thrustCurve || 0,
        cps1_5: this.pcdata[1].gencalc || 0,
        cps2_5: this.pcdata[3].gencalc || 0,
        cps3_5: this.pcdata[5].gencalc || 0,
        cps4_5: this.pcdata[7].gencalc || 0,
        cps5_5: this.pcdata[9].gencalc || 0,
        cps6_5: this.pcdata[11].gencalc || 0,
        cps7_5: this.pcdata[13].gencalc || 0,
        cps8_5: this.pcdata[15].gencalc || 0,
        cps9_5: this.pcdata[17].gencalc || 0,
        cps10_5: this.pcdata[19].gencalc || 0,
        cps11_5: this.pcdata[21].gencalc || 0,
        cps12_5: this.pcdata[23].gencalc || 0,
        cps13_5: this.pcdata[25].gencalc || 0,
        cps14_5: this.pcdata[27].gencalc || 0,
        cps15_5: this.pcdata[29].gencalc || 0,
        cps16_5: this.pcdata[31].gencalc || 0,
        cps17_5: this.pcdata[33].gencalc || 0,
        cps18_5: this.pcdata[35].gencalc || 0,
        cps19_5: this.pcdata[37].gencalc || 0,
        cps20_5: this.pcdata[39].gencalc || 0,
        cps21_5: this.pcdata[41].gencalc || 0,
        cps22_5: this.pcdata[43].gencalc || 0,
        cps23_5: this.pcdata[45].gencalc || 0,
        cps24_5: this.pcdata[47].gencalc || 0,
        cps25_5: this.pcdata[49].gencalc || 0,
        cps26_5: this.pcdata[51].gencalc || 0,
        cps27_5: this.pcdata[53].gencalc || 0,
        cps28_5: this.pcdata[55].gencalc || 0,
        cps29_5: this.pcdata[57].gencalc || 0
      }
    };
    this.savePowerCurveDetailsSubscribe = this.dataService
      .savePowerCurveDetails(savePCDataReq)
      .subscribe(pcresp => {
        if (pcresp.message) {
          this.toastr.success(`Power Curve Details Added Successfully!!`);
        }
      });
  }

  public fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
  }

  handleFileInput(file) {
    this.pcdata = [];
    const formData = new FormData();
    formData.append('file', file[0]);
    if (formData) {
      this.uploadPCFileSubscribe = this.dataService
        .uploadPCFile(formData)
        .subscribe(resp => {
          if (resp) {
            for (let i = 0; i < 59; i++) {
              const temp = {
                windSpeed: resp.WindSpeed[i],
                powerCurve: resp.PowerCurve[i] || 0, //  pcresp[windSpeed],
                thrustCurve: resp.ThrustCurve[i] || 0,
                gencalc: resp.GenCalcPC[i] || 0
              };
              this.pcdata.push(temp);
            }
          }
        });
    }
  }

  onCustomerStatusChange(event) {
    if (event === true) {
      this.powerCurveDetails.customerStatus = 'Active';
    } else {
      this.powerCurveDetails.customerStatus = 'InActive';
    }
  }

  onTurbineStatusChange(event) {
    if (event === true) {
      this.powerCurveDetails.turbineStatus = 'Active';
    } else {
      this.powerCurveDetails.turbineStatus = 'InActive';
    }
  }

  constructTurbineModel() {
    const manufacturerName = this.manufacturersList.filter(
      result => this.powerCurveDetails.companyId === result.id
    );
    if (manufacturerName && manufacturerName.length > 0) {
      const name = manufacturerName[0].manufacturer
        ? manufacturerName[0].manufacturer
        : '';
      const rating = this.powerCurveDetails.namePlateRatingMw
        ? this.powerCurveDetails.namePlateRatingMw
        : '';
      const rotor = this.powerCurveDetails.rotorDiameter
        ? this.powerCurveDetails.rotorDiameter
        : '';
      const rev = this.powerCurveDetails.revisionNumber
        ? this.powerCurveDetails.revisionNumber
        : '';
      this.powerCurveDetails.turbineName =
        name + ' ' + rating + ' ' + rotor + ' ' + rev;
    }
  }

  ngOnDestroy() {
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.getManufacturersSubscribe) {
      this.getManufacturersSubscribe.unsubscribe();
    }
    if (this.getTurbinesPCListSubscribe) {
      this.getTurbinesPCListSubscribe.unsubscribe();
    }
    if (this.getPowerCurveDetailsSubscribe) {
      this.getPowerCurveDetailsSubscribe.unsubscribe();
    }
    if (this.savePowerCurveDetailsSubscribe) {
      this.savePowerCurveDetailsSubscribe.unsubscribe();
    }
    if (this.uploadPCFileSubscribe) {
      this.uploadPCFileSubscribe.unsubscribe();
    }
  }
}
