import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
  OnDestroy
} from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-recent-sessions',
  templateUrl: './recent-sessions.component.html',
  styleUrls: ['./recent-sessions.component.css']
})
export class RecentSessionsComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private currentUserSubscribe: Subscription;
  private sessionFilterSubscribe: Subscription;
  private opportunityNameFilterSubscribe: Subscription;
  private opportunityNumberFilterSubscribe: Subscription;
  private createdByFilterSubscribe: Subscription;
  private updatedByFilterSubscribe: Subscription;
  private countryFilterSubscribe: Subscription;
  private stateFilterSubscribe: Subscription;
  private createdDateFilterSubscribe: Subscription;
  private updatedDateFilterSubscribe: Subscription;
  private getRecentSessionsSubscribe: Subscription;

  displayedColumns: string[] = [
    'session',
    'opportunityName',
    'opportunityNumber',
    'createdBy',
    'updatedBy',
    'country',
    'state',
    'createdDate',
    'updatedDate'
  ];
  dataSource = new MatTableDataSource<any>();

  sessionFilter = new FormControl('');
  opportunityNameFilter = new FormControl('');
  opportunityNumberFilter = new FormControl('');
  createdByFilter = new FormControl('');
  updatedByFilter = new FormControl('');
  countryFilter = new FormControl('');
  stateFilter = new FormControl('');
  createdDateFilter = new FormControl('');
  updatedDateFilter = new FormControl('');

  filterValues = {
    session: '',
    opportunityName: '',
    opportunityNumber: '',
    createdBy: '',
    updatedBy: '',
    country: '',
    state: '',
    createdDate: '',
    updatedDate: ''
  };
  userDetails: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private router: Router,
    private dataService: DataService,
    private globals: GlobalsService
  ) {}

  ngOnInit() {
    this.currentUserSubscribe = this.globals.currentUser.subscribe(userInfo => {
      this.userDetails = userInfo;
      if (userInfo && userInfo.userId) {
        const userData = {
          beginRange: 0,
          endRange: 50,
          ssoId: userInfo.userId
        };
        this.getRecentSessions(userData);
      }
    });

    this.dataSource.filterPredicate = this.createFilter();

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    this.sessionFilterSubscribe = this.sessionFilter.valueChanges.subscribe(
      session => {
        this.filterValues.session = session;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.opportunityNameFilterSubscribe = this.opportunityNameFilter.valueChanges.subscribe(
      opportunityName => {
        this.filterValues.opportunityName = opportunityName;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.opportunityNumberFilterSubscribe = this.opportunityNumberFilter.valueChanges.subscribe(
      opportunityNumber => {
        this.filterValues.opportunityNumber = opportunityNumber;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.createdByFilterSubscribe = this.createdByFilter.valueChanges.subscribe(
      createdBy => {
        this.filterValues.createdBy = createdBy;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.updatedByFilterSubscribe = this.updatedByFilter.valueChanges.subscribe(
      updatedBy => {
        this.filterValues.updatedBy = updatedBy;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.countryFilterSubscribe = this.countryFilter.valueChanges.subscribe(
      country => {
        this.filterValues.country = country;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.stateFilterSubscribe = this.stateFilter.valueChanges.subscribe(
      state => {
        this.filterValues.state = state;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.createdDateFilterSubscribe = this.createdDateFilter.valueChanges.subscribe(
      createdDate => {
        this.filterValues.createdDate = createdDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.updatedDateFilterSubscribe = this.updatedDateFilter.valueChanges.subscribe(
      updatedDate => {
        this.filterValues.updatedDate = updatedDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
  }

  getRecentSessions(userData) {
    this.getRecentSessionsSubscribe = this.dataService
      .getRecentSessions(userData)
      .subscribe(sessionData => {
        const sessionList = [];
        if (sessionData && sessionData.length) {
          for (const session of sessionData) {
            const obj = {};
            obj['id'] = sessionList.length + 1;
            obj['session'] = session.windSelectId || '';
            obj['opportunityName'] = session.opportunityName || '';
            obj['opportunityNumber'] = session.opportunityNo || '';
            obj['createdBy'] = session.createdBy || '';
            obj['updatedBy'] = session.modifiedBy || '';
            obj['country'] = session.countryName || '';
            obj['state'] = session.stateName || '';
            obj['createdDate'] = session.createdDate
              ? new Date(session.createdDate).toLocaleDateString('en-US', {
                  month: '2-digit',
                  day: '2-digit',
                  year: 'numeric'
                })
              : '';
            obj['updatedDate'] = session.updatedDate
              ? new Date(session.updatedDate).toLocaleDateString('en-US', {
                  month: '2-digit',
                  day: '2-digit',
                  year: 'numeric'
                })
              : '';
            sessionList.push(obj);
          }
        }
        this.dataSource.data = sessionList;
      });
  }

  createFilter(): (data: any, filter: string) => boolean {
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
    const filterFunction = function(data, filter): boolean {
      const searchTerms = JSON.parse(filter);
      return (
        data.session
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.session) !== -1 &&
        data.opportunityName
          .toLowerCase()
          .indexOf(searchTerms.opportunityName) !== -1 &&
        data.opportunityNumber
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.opportunityNumber) !== -1 &&
        data.createdBy
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.createdBy) !== -1 &&
        data.updatedBy
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.updatedBy) !== -1 &&
        data.country.toLowerCase().indexOf(searchTerms.country) !== -1 &&
        data.state.toLowerCase().indexOf(searchTerms.state) !== -1 &&
        data.createdDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.createdDate) !== -1 &&
        data.updatedDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.updatedDate) !== -1
      );
    };
    return filterFunction;
  }

  ngAfterViewInit() {
    this.dataSource.sortingDataAccessor = (item, property) => {
      switch (property) {
        case 'createdDate': {
          const newDate = new Date(item.createdDate);
          return newDate;
        }
        case 'updatedDate': {
          const newDate = new Date(item.updatedDate);
          return newDate;
        }
        default:
          return item[property];
      }
    };
  }

  ngOnDestroy() {
    if (this.currentUserSubscribe) {
      this.currentUserSubscribe.unsubscribe();
    }
    if (this.sessionFilterSubscribe) {
      this.sessionFilterSubscribe.unsubscribe();
    }
    if (this.opportunityNameFilterSubscribe) {
      this.opportunityNameFilterSubscribe.unsubscribe();
    }
    if (this.opportunityNumberFilterSubscribe) {
      this.opportunityNumberFilterSubscribe.unsubscribe();
    }
    if (this.createdByFilterSubscribe) {
      this.createdByFilterSubscribe.unsubscribe();
    }
    if (this.updatedByFilterSubscribe) {
      this.updatedByFilterSubscribe.unsubscribe();
    }
    if (this.countryFilterSubscribe) {
      this.countryFilterSubscribe.unsubscribe();
    }
    if (this.stateFilterSubscribe) {
      this.stateFilterSubscribe.unsubscribe();
    }
    if (this.createdDateFilterSubscribe) {
      this.createdDateFilterSubscribe.unsubscribe();
    }
    if (this.updatedDateFilterSubscribe) {
      this.updatedDateFilterSubscribe.unsubscribe();
    }
    if (this.getRecentSessionsSubscribe) {
      this.getRecentSessionsSubscribe.unsubscribe();
    }
  }
}
