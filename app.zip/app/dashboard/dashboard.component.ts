import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../shared/api/data.service';
import { GlobalsService } from '../shared/api/globals.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  private getNewSessionIdSubscribe: Subscription;
  constructor(
    private router: Router,
    private dataService: DataService,
    private globals: GlobalsService
  ) {}

  ngOnInit() {
    this.resetGlobalData();
  }

  gotoAction() {
    this.resetGlobalData();
    this.getNewSessionIdSubscribe = this.dataService
      .getNewSessionId()
      .subscribe(result => {
        // tslint:disable-next-line:no-unused-expression
        result.sessionId &&
          this.router.navigate([`/actions/${result.sessionId}`]);
      });
  }

  resetGlobalData() {
    this.globals.changeCountry('');
    this.globals.changeState('');
    this.globals.changeCodDate('');
    this.globals.changeBopValue('');
    // this.globals.changeSesssion('');
    // this.globals.changeUser('');
    this.globals.updateSessionInfo('');
    this.globals.changeparkTitle('');
    this.globals.changeSelectedCaseId('');
    this.globals.changeSelectedCaseInfo('');
    this.globals.changeWindParkData('');
    this.globals.changeMarketInfoData('');
    this.globals.changeCasesList({});
    this.globals.changeProjEconomics([]);
    this.globals.changeProjResults([]);
    this.globals.updateLoadedCaseData({});
    this.globals.updateOpportunityNoData('');
    this.globals.updateOpportunityNameData('');
  }

  ngOnDestroy() {
    if (this.getNewSessionIdSubscribe) {
      this.getNewSessionIdSubscribe.unsubscribe();
    }
  }
}
