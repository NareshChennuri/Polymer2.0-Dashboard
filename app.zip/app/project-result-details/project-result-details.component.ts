import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { GlobalsService } from '../shared/api/globals.service';
@Component({
  selector: 'app-project-result-details',
  templateUrl: './project-result-details.component.html',
  styleUrls: ['./project-result-details.component.css']
})
export class ProjectResultDetailsComponent implements OnInit, OnDestroy {
  private sessionSaveInfoSubscribe: Subscription;
  private projectResultsSubscribe: Subscription;
  public resultsList = [];
  constructor(private globals: GlobalsService) {}
  ngOnInit(): void {
    this.resultsList = [];
    this.updateProjResultsData();
    this.sessionSaveInfoSubscribe = this.globals.sessionSaveInfo.subscribe(
      sessionInfo => {
        if (sessionInfo && sessionInfo.windFarmInputs) {
          this.resultsList = sessionInfo.windFarmInputs.map(trbData => {
            const trb = {
              id: trbData.windselectParkData.parkId,
              windfarmId: trbData.windselectParkData.parkId,
              projectIrr: trbData.windselectParkData.projectIrr,
              projectEquityIrr: trbData.windselectParkData.projectEquityIrr,
              projectEquityNpv: trbData.windselectParkData.projectEquityNpv,
              totalWtgPriceperMw: trbData.windselectParkData.totalWtgPriceperMw,
              totalWtgPriceperMwh:
                trbData.windselectParkData.totalWtgPriceperMwh,
              totalCapexperMw: trbData.windselectParkData.totalCapexperMw,
              lcoeCentsperKwh: trbData.windselectParkData.lcoeCentsperKwh,
              wtgPrice: trbData.windselectParkData.wtgPriceResults,
              onmNpv: trbData.windselectParkData.onmNpv,
              wtgpriceOnmpriceNpv:
                trbData.windselectParkData.wtgpriceOnmpriceNpv,
              totalOnmpriceperMwh:
                trbData.windselectParkData.totalOnmpriceperMwh,
              totalWtgpriceOnmpriceperMwh:
                trbData.windselectParkData.totalWtgpriceOnmpriceperMwh,
              capexOpexperMwh: trbData.windselectParkData.capexOpexperMwh
            };
            return trb;
          });
        }
        this.updateProjResultsData();
      }
    );

    this.projectResultsSubscribe = this.globals.projectResults.subscribe(
      trb => {
        if (trb) {
          this.addProjectResult(trb);
        }
      }
    );
  }

  addProjectResult(trbData) {
    const windfarmId = (trbData && trbData.windfarmId) || 0;
    const addedRes = {
      id: windfarmId,
      windfarmId,
      projectIrr: '',
      projectEquityIrr: '',
      projectEquityNpv: '',
      totalWtgPriceperMw: '',
      totalWtgPriceperMwh: '',
      totalCapexperMw: '',
      lcoeCentsperKwh: '',
      wtgPrice: '',
      onmNpv: '',
      wtgpriceOnmpriceNpv: '',
      totalOnmpriceperMwh: '',
      totalWtgpriceOnmpriceperMwh: '',
      capexOpexperMwh: '',
      parkComments: ''
    };
    this.resultsList.push(addedRes);
    this.updateProjResultsData();
  }

  deleteProjectResultInfo(trb) {
    this.resultsList = this.resultsList.filter(item => item.id !== trb.trb.id);
  }
  updateProjResultsData() {
    this.globals.changeProjResults(this.resultsList);
  }

  ngOnDestroy() {
    if (this.sessionSaveInfoSubscribe) {
      this.sessionSaveInfoSubscribe.unsubscribe();
    }
    if (this.projectResultsSubscribe) {
      this.projectResultsSubscribe.unsubscribe();
    }
  }
}
