import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectResultDetailsComponent } from './project-result-details.component';

describe('ProjectResultDetailsComponent', () => {
  let component: ProjectResultDetailsComponent;
  let fixture: ComponentFixture<ProjectResultDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectResultDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectResultDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
