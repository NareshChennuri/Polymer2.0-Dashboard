import { Subscription } from 'rxjs';
import { Component, OnDestroy } from '@angular/core';
import { GlobalsService } from '../shared/api/globals.service';

@Component({
  selector: 'app-comments-details',
  templateUrl: './comments-details.component.html',
  styleUrls: ['./comments-details.component.css']
})
export class CommentsDetailsComponent implements OnDestroy {
  private sessionSaveInfoSubscribe: Subscription;
  sessionComments: any;
  constructor(private globals: GlobalsService) {
    this.sessionSaveInfoSubscribe = this.globals.sessionSaveInfo.subscribe(
      sessionInfo => {
        if (sessionInfo.windselectMainInputs) {
          this.sessionComments =
            sessionInfo.windselectMainInputs.sessionComments;
        }
      }
    );
  }
  ngOnDestroy() {
    if (this.sessionSaveInfoSubscribe) {
      this.sessionSaveInfoSubscribe.unsubscribe();
    }
  }
}
