import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkCommentsComponent } from './park-comments.component';

describe('ParkCommentsComponent', () => {
  let component: ParkCommentsComponent;
  let fixture: ComponentFixture<ParkCommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParkCommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParkCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
