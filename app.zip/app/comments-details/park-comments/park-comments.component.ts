import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { GlobalsService } from 'src/app/shared/api/globals.service';

@Component({
  selector: 'app-park-comments',
  templateUrl: './park-comments.component.html',
  styleUrls: ['./park-comments.component.css']
})
export class ParkCommentsComponent implements OnInit, OnDestroy {
  private sessionSaveInfoSubscribe: Subscription;
  private parkCommentsSubscribe: Subscription;
  turbines: any = [];
  constructor(private globals: GlobalsService) {}

  ngOnInit() {
    this.sessionSaveInfoSubscribe = this.globals.sessionSaveInfo.subscribe(
      turbineDlts => {
        if (turbineDlts.windFarmInputs) {
          this.turbines = [];
          turbineDlts.windFarmInputs.forEach(element => {
            this.turbines.push(element.windselectParkData);
          });
        }
      }
    );
    this.parkCommentsSubscribe = this.globals.parkComments.subscribe(result => {
      this.cloneParkComment(result);
    });
  }

  addParkComment(trb) {
    this.turbines.push({ parkId: trb.windfarmId });
  }

  cloneParkComment(trb) {
    this.turbines.push({ parkId: trb.id, parkComments: trb.parkComments });
  }

  deleteParkComment(trb) {
    let i = 0;
    this.turbines.forEach(element => {
      if (element.parkId === trb.trb.parkId) {
        this.turbines.splice(i, 1);
      }
      i++;
    });
  }

  ngOnDestroy() {
    if (this.sessionSaveInfoSubscribe) {
      this.sessionSaveInfoSubscribe.unsubscribe();
    }
    if (this.parkCommentsSubscribe) {
      this.parkCommentsSubscribe.unsubscribe();
    }
  }
}
