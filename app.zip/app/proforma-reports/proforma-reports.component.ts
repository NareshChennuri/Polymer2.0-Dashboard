import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
  OnDestroy
} from '@angular/core';
import { MatPaginator } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../shared/api/data.service';
import { GlobalsService } from '../shared/api/globals.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

export interface PeriodicElement {
  financialModelId: any;
  frequency: any;
  indexId: any;
  marketType: any;
  recordId: any;
  subType: any;
  totAmount: any;
  unitOfMeasure: any;
  windparkId: any;
  windselectId: any;
}

@Component({
  selector: 'app-proforma-reports',
  templateUrl: './proforma-reports.component.html',
  styleUrls: ['./proforma-reports.component.css']
})
export class ProformaReportsComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private windParkDataSubscribe: Subscription;
  private codDateSubscribe: Subscription;
  private constructionStartDateGlobalSubscribe: Subscription;
  private paramMapSubscribe: Subscription;
  private getConsolidatedProformaSubscribe: Subscription;
  private downloadProformaReportsSubscribe: Subscription;
  displayedColumns: string[] = [
    'financialModelId',
    'frequency',
    'indexId',
    'marketType',
    'recordId',
    'subType',
    'totAmount',
    'unitOfMeasure',
    'windparkId',
    'windselectId'
  ];
  proformaData: PeriodicElement[] = [];
  dataSource: any;
  selectedSession: any;
  currentUser: any;
  consolidatedResults: any[];
  years = 0;
  selectedViewType: any;
  viewTypes: any = [];
  consolidatedData = {
    epc: 0,
    wtgPrice: 0,
    transportation: 0,
    bopCost: 0,
    installCommCost: 0,
    otherCapitalCost: 0,
    omDuring: 0,
    omPost: 0,
    buildersRisk: 0
  };
  consolidatedView: any = [];
  selectedResults: any = [];
  tblHeaders: any = [];
  proformaYrs: any = {};
  selectedProfYr: any;
  consolidatedTotals = {
    totalProjectCost: 0,
    totalRevenueStreams: 0,
    totalCommericalTax: 0
  };
  consolidatedTotalResults = [];
  codDate:any;
  constructionDate:any;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private dataService: DataService,
    private globals: GlobalsService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.consolidatedResults = [];
    this.selectedResults = [];
    this.viewTypes = [];
    this.proformaYrs = [];
    this.tblHeaders = [];
    this.selectedViewType = this.selectedProfYr = ``;
    this.proformaYrs = {};

    this.windParkDataSubscribe =  this.globals.windParkData.subscribe(result => {
      if(result && result.length>0){
        result.map(result1 =>{
          const parks = { value: result1.parkId, viewValue: result1.parkName };
          this.viewTypes.push(parks);
        });
        this.selectedViewType = this.viewTypes[0].value;
      }
    });

    this.codDateSubscribe =  this.globals.codDate.subscribe(cod => {
      this.codDate = cod;
    });
    this.constructionStartDateGlobalSubscribe =  this.globals.constructionStartDateGlobal.subscribe(construction => {
      this.constructionDate = construction;
    });
  }

  ngAfterViewInit(){
    this.proformaParkData();
  }

  proformaParkData(){
    this.consolidatedResults = [];
    this.selectedResults = [];
    this.tblHeaders = [];
    this.selectedProfYr = [];
    this.consolidatedView = [];
    this.proformaYrs = {};
    this.paramMapSubscribe =  this.route.paramMap.subscribe(params => {
      this.selectedSession = params.get('id');
      this.getConsolidatedProformaSubscribe =  this.dataService
        .getConsolidatedProforma({ windselectId: this.selectedSession,parkId: this.selectedViewType })
        .subscribe(reports => {
          if (reports.length > 0) {
            reports.map(profarma => {
              this.consolidatedView.push({ parkId: profarma.windParkId, consolidatedView: profarma.consolidatedView});
              if (Object.keys(profarma.dataMap).length > 0) {
                // divide by 1000
                for (const key in profarma.dataMap) {
                  if (profarma.dataMap[key]) {
                    for (const kk in profarma.dataMap[key]) {
                      if (profarma.dataMap[key][kk]) {
                        for (
                          let i = 0;
                          i < profarma.dataMap[key][kk].length;
                          i++
                        ) {
                          if (
                            profarma.dataMap[key][kk][i] &&
                            profarma.dataMap[key][kk][i] !== 0
                          ) {
                            profarma.dataMap[key][kk][i] = parseFloat(
                              parseFloat(
                                profarma.dataMap[key][kk][i] / 1000 + ''
                              ).toFixed(0)
                            );
                          }
                        }
                      }
                    }
                  }
                }
                for (const keys in profarma.dataMap) {
                  if (profarma.dataMap[keys]) {
                    const totals = [];
                    for (const key in profarma.dataMap[keys]) {
                      const keyName = key.split('#')[0] + '';
                      if(keyName!=='Ending Balance'&&keyName!=='Begining Balance'&&keyName!=='Debt Interest'&&keyName!=='Debt Principle Amount'){
                      if (profarma.dataMap[keys][key]) {
                        for (
                          let i = 0;
                          i < profarma.dataMap[keys][key].length;
                          i++
                        ) {
                          totals[i] = parseFloat(
                            parseFloat(
                              (totals[i] || 0) + +profarma.dataMap[keys][key][i]
                            ).toFixed(3)
                          );
                        }
                      }
                    }
                    }
                    let totalLabel = 'Total ';
                    if (keys === 'REVSTR') {
                      totalLabel = 'Operations Revenue';
                      profarma.dataMap[keys][totalLabel] = totals;
                      this.years = profarma.dataMap[keys][totalLabel].length>this.years?profarma.dataMap[keys][totalLabel].length:this.years;
                    }  else if (keys === 'OPERCOST') {
                      totalLabel = 'Operations Expences';
                      profarma.dataMap[keys][totalLabel] = totals;
                      this.years = profarma.dataMap[keys][totalLabel].length>this.years?profarma.dataMap[keys][totalLabel].length:this.years;
                    }else if (keys === 'FINANCE') {
                      totalLabel += 'Finance';
                      profarma.dataMap[keys][totalLabel] = totals;
                      this.years = profarma.dataMap[keys][totalLabel].length>this.years?profarma.dataMap[keys][totalLabel].length:this.years;
                    } else if (keys === 'DEPR') {
                      totalLabel += 'Depreciation';
                      profarma.dataMap[keys][totalLabel] = totals;
                      this.years = profarma.dataMap[keys][totalLabel].length>this.years?profarma.dataMap[keys][totalLabel].length:this.years;
                    } else if (keys === 'TAX') {
                      totalLabel += 'Tax';
                      profarma.dataMap[keys][totalLabel] = totals;
                      this.years = profarma.dataMap[keys][totalLabel].length>this.years?profarma.dataMap[keys][totalLabel].length:this.years;
                    }
                  }
                }
                const parkId = parseInt(profarma.windParkId, 10);
                for (const keys in profarma.dataMap) {
                  if (keys === 'REVSTR') {
                    this.consolidatedResults.push({
                      parkId,
                      REVSTR: profarma.dataMap[keys]
                    });
                  }  else if (keys === 'OPERCOST') {
                    this.consolidatedResults.push({
                      parkId,
                      OPERCOST: profarma.dataMap[keys]
                    });
                  }else if (keys === 'Operations Income') {
                    this.consolidatedResults.push({
                      parkId,
                      'Operations Income': profarma.dataMap[keys]
                    });
                  } else if (keys === 'FINANCE') {
                    this.consolidatedResults.push({
                      parkId,
                      FINANCE: profarma.dataMap[keys]
                    });
                  } else if (keys === 'DEPR') {
                    this.consolidatedResults.push({
                      parkId,
                      DEPR: profarma.dataMap[keys]
                    });
                  } else if (keys === 'TAX') {
                    this.consolidatedResults.push({
                      parkId,
                      TAX: profarma.dataMap[keys]
                    });
                  } else if (keys === 'OPERATINGINCOME') {
                    this.consolidatedResults.push({
                      parkId,
                      OPERATINGINCOME: profarma.dataMap[keys]
                    });
                  } else if (keys === 'NPV') {
                    this.consolidatedResults.push({
                      parkId,
                      NPV: profarma.dataMap[keys]
                    });
                  } else if (keys === 'IRR') {
                    this.consolidatedResults.push({
                      parkId,
                      IRR: profarma.dataMap[keys]
                    });
                  }
                }
                const yrs = [],
                  // currentYr = new Date(profarma.cod).getFullYear();
                  currentYr = new Date(this.constructionDate).getFullYear();
                for (
                  let i = currentYr;
                  i < this.years + currentYr;
                  i++
                ) {
                  yrs.push(i);
                }
                this.proformaYrs[profarma.windParkId] = yrs;
              }
            });

            if (Object.keys(this.consolidatedResults).length > 0) {
              this.selectedProfYr = this.proformaYrs[this.selectedViewType];

              const processedResults = [];
              this.consolidatedResults.map(item => {
                if (item.parkId === this.selectedViewType) {
                  if (item['REVSTR']) {
                    const rowData = this.processRowData(item['REVSTR']);
                    processedResults.push({ REVSTR: rowData });
                  }  else if (item['OPERCOST']) {
                    const rowData = this.processRowData(item['OPERCOST']);
                    processedResults.push({ OPERCOST: rowData });
                  }else if (item['Operations Income']) {
                    const rowData = this.processRowData(item['Operations Income']);
                    processedResults.push({ Operations_Income: rowData });
                  } else if (item['FINANCE']) {
                    const rowData = this.processRowData(item['FINANCE']);
                    processedResults.push({ FINANCE: rowData });
                  } else if (item['DEPR']) {
                    const rowData = this.processRowData(item['DEPR']);
                    processedResults.push({ DEPR: rowData });
                  }else if (item['TAX']) {
                    const rowData = this.processRowData(item['TAX']);
                    processedResults.push({ TAX: rowData });
                  } else if (item['OPERATINGINCOME']) {
                    const rowData = this.processRowData(item['OPERATINGINCOME']);
                    processedResults.push({ OPERATINGINCOME: rowData });
                  } else if (item['NPV']) {
                    const rowData = this.processRowData(item['NPV']);
                    processedResults.push({ NPV: rowData });
                  } else if (item['IRR']) {
                    const rowData = this.processRowData(item['IRR']);
                    processedResults.push({ IRR: rowData });
                  }
                }
              });
              this.selectedResults = processedResults;
              this.consolidatedView.map(data => {
                if(this.selectedViewType===data.parkId){
              this.consolidatedData = {
                epc: data.consolidatedView.totalEpc || 0,
                wtgPrice: data.consolidatedView.wtgPrice || 0,
                transportation: data.consolidatedView.transpotation || 0,
                bopCost: data.consolidatedView.bop || 0,
                installCommCost: data.consolidatedView.installCommCost || 0,
                otherCapitalCost: data.consolidatedView.otherCapitalCost || 0,
                omDuring: data.consolidatedView.omDuring || 0,
                omPost: data.consolidatedView.omPost || 0,
                buildersRisk: data.consolidatedView.buildersRisk || 0
              };
              this.consolidatedTotals = {
                totalProjectCost: data.consolidatedView.totalProjectCost || 0,
                totalRevenueStreams: data.consolidatedView.revenue || 0,
                totalCommericalTax: data.consolidatedView.commercialTax || 0
              };
            }
            });
            }
          }
        });
    });
  }

  processRowData(keyData) {
    const rowData = [];
    for (const keys in keyData) {
      if (keyData[keys]) {
        const keyName = keys.split('#')[0] + '';
        if(keyName!=='Ending Balance'&&keyName!=='Begining Balance'&&keyName!=='Debt Interest'&&keyName!=='Debt Principle Amount'){
        const dataArray = [...keyData[keys]];
        dataArray.unshift(keyName);
        rowData.push(dataArray);
        }
      }
    }
    return rowData;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue
      ? filterValue.trim().toLowerCase()
      : '';
  }

  modeChange($eve) {
    if (Object.keys(this.consolidatedResults).length > 0) {
      this.selectedResults = this.selectedProfYr = [];
      this.selectedProfYr = this.proformaYrs[this.selectedViewType];

      const processedResults = [];
      this.consolidatedResults.map(item => {
        if (item.parkId === this.selectedViewType) {
          if (item['REVSTR']) {
            const rowData = this.processRowData(item['REVSTR']);
            processedResults.push({ REVSTR: rowData });
          }  else if (item['OPERCOST']) {
            const rowData = this.processRowData(item['OPERCOST']);
            processedResults.push({ OPERCOST: rowData });
          }else if (item['Operations Income']) {
            const rowData = this.processRowData(item['Operations Income']);
            processedResults.push({ Operations_Income: rowData });
          } else if (item['FINANCE']) {
            const rowData = this.processRowData(item['FINANCE']);
            processedResults.push({ FINANCE: rowData });
          } else if (item['DEPR']) {
            const rowData = this.processRowData(item['DEPR']);
            processedResults.push({ DEPR: rowData });
          }else if (item['TAX']) {
            const rowData = this.processRowData(item['TAX']);
            processedResults.push({ TAX: rowData });
          } else if (item['OPERATINGINCOME']) {
            const rowData = this.processRowData(item['OPERATINGINCOME']);
            processedResults.push({ OPERATINGINCOME: rowData });
          } else if (item['NPV']) {
            const rowData = this.processRowData(item['NPV']);
            processedResults.push({ NPV: rowData });
          } else if (item['IRR']) {
            const rowData = this.processRowData(item['IRR']);
            processedResults.push({ IRR: rowData });
          }
        }
      });
      this.selectedResults = processedResults;
      this.consolidatedView.map(data => {
        if(this.selectedViewType===data.parkId){
      this.consolidatedData = {
        epc: data.consolidatedView.totalEpc || 0,
        wtgPrice: data.consolidatedView.wtgPrice || 0,
        transportation: data.consolidatedView.transpotation || 0,
        bopCost: data.consolidatedView.bop || 0,
        installCommCost: data.consolidatedView.installCommCost || 0,
        otherCapitalCost: data.consolidatedView.otherCapitalCost || 0,
        omDuring: data.consolidatedView.omDuring || 0,
        omPost: data.consolidatedView.omPost || 0,
        buildersRisk: data.consolidatedView.buildersRisk || 0
      };
      this.consolidatedTotals = {
        totalProjectCost: data.consolidatedView.totalProjectCost || 0,
        totalRevenueStreams: data.consolidatedView.revenue || 0,
        totalCommericalTax: data.consolidatedView.commercialTax || 0
      };
    }
    });
    }
  }

  downloadProforma() {
    if (this.selectedSession) {
      this.downloadProformaReportsSubscribe =  this.dataService
        .downloadProformaReports({ windselectId: this.selectedSession })
        .subscribe(reports => {
          // console.log('reports', reports);
          const fileName = `proforma_reports_${this.selectedSession}.xls`;
          this.downloadFile(
            reports,
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            fileName
          );
        });
    }
  }

  downloadFile(blob: any, type: string, filename: string) {
    const binaryData = [];
    binaryData.push(blob);

    const url = window.URL.createObjectURL(
      new Blob(binaryData, { type: type })
    );
    // create hidden dom element (so it works in all browsers)
    const a = document.createElement('a');
    a.setAttribute('style', 'display:none;');
    document.body.appendChild(a);

    // create file, attach to hidden element and open hidden element
    a.href = url;
    a.download = filename;
    a.click();
  }

  backToSession() {
    this.router.navigate([`/actions/${this.selectedSession}`]);
    const caseData = {};
    this.globals.updateLoadedCaseData(caseData);
  }

  ngOnDestroy() {
    if (this.windParkDataSubscribe) {
      this.windParkDataSubscribe.unsubscribe();
    }
    if (this.codDateSubscribe) {
      this.codDateSubscribe.unsubscribe();
    }
    if (this.constructionStartDateGlobalSubscribe) {
      this.constructionStartDateGlobalSubscribe.unsubscribe();
    }
    if (this.paramMapSubscribe) {
      this.paramMapSubscribe.unsubscribe();
    }
    if (this.getConsolidatedProformaSubscribe) {
      this.getConsolidatedProformaSubscribe.unsubscribe();
    }
    if (this.downloadProformaReportsSubscribe) {
      this.downloadProformaReportsSubscribe.unsubscribe();
    }
  }
}
