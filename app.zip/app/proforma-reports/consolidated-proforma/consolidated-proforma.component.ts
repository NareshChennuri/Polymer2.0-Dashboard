import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-consolidated-proforma',
  templateUrl: './consolidated-proforma.component.html',
  styleUrls: ['./consolidated-proforma.component.css']
})
export class ConsolidatedProformaComponent implements OnInit {
  selectedViewType: any;
  @Input() consolidatedData: any = [];
  @Input() consolidatedTotals: any = [];
  viewTypes = [
    {value: 'quarterly', viewValue: 'Quarterly'},
    {value: 'monthly', viewValue: 'Monthly'},
    {value: 'yearly', viewValue: 'Yearly'}
  ];
  constructor() { }

  ngOnInit() {
  }

}
