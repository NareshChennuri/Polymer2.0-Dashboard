import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidatedProformaComponent } from './consolidated-proforma.component';

describe('ConsolidatedProformaComponent', () => {
  let component: ConsolidatedProformaComponent;
  let fixture: ComponentFixture<ConsolidatedProformaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsolidatedProformaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidatedProformaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
