import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProformaReportsComponent } from './proforma-reports.component';

describe('ProformaReportsComponent', () => {
  let component: ProformaReportsComponent;
  let fixture: ComponentFixture<ProformaReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProformaReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProformaReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
