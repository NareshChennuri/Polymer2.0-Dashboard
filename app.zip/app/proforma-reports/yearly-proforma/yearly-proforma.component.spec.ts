import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearlyProformaComponent } from './yearly-proforma.component';

describe('YearlyProformaComponent', () => {
  let component: YearlyProformaComponent;
  let fixture: ComponentFixture<YearlyProformaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearlyProformaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearlyProformaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
