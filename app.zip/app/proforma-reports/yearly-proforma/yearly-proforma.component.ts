import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';

@Component({
  selector: 'app-yearly-proforma',
  templateUrl: './yearly-proforma.component.html',
  styleUrls: ['./yearly-proforma.component.css']
})
export class YearlyProformaComponent implements OnInit {
  @Input() selectedResults: any = [];
  @Input() tblHeaders: any = [];
  @Input() selectedProfYr: any = [];

  constructor() {}

  ngOnInit() {}
}
