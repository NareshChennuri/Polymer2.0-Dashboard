import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectEconomicsDetailsComponent } from './project-economics-details.component';

describe('ProjectEconomicsDetailsComponent', () => {
  let component: ProjectEconomicsDetailsComponent;
  let fixture: ComponentFixture<ProjectEconomicsDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectEconomicsDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectEconomicsDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
