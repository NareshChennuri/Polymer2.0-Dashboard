import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { MatDialog } from '@angular/material';
import { Subscription } from 'rxjs';
import { ProjEconomicsDialogComponent } from './proj-economics-dialog/proj-economics-dialog.component';
import { DataService } from '../shared/api/data.service';
import { GlobalsService } from '../shared/api/globals.service';

@Component({
  selector: 'app-project-economics-details',
  templateUrl: './project-economics-details.component.html',
  styleUrls: ['./project-economics-details.component.css']
})
export class ProjectEconomicsDetailsComponent implements OnInit, OnDestroy {
  private parkTitleSubscribe: Subscription;
  private bopValueSubscribe: Subscription;
  private projEconomicsDataSubscribe: Subscription;
  private windParkDataSubscribe: Subscription;
  private sessionSaveInfoSubscribe: Subscription;
  private listOfCasesSubscribe: Subscription;
  private windParkData2Subscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  private currentSessionSubscribe: Subscription;
  private getDynamicCostsSubscribe: Subscription;
  private bopValue2Subscribe: Subscription;
  private windParkData3Subscribe: Subscription;
  private getHubHeightsListSubscribe: Subscription;
  bopValue: string;
  parkTitle: string;
  parkIndex: number;
  casesList: any[];
  @Output() openBopCalculation = new EventEmitter<{}>();
  economicDetails = [];
  windParkData: any[];

  constructor(
    private _service: DataService,
    public dialog: MatDialog,
    private globals: GlobalsService
  ) {}

  ngOnInit() {
    this.parkTitleSubscribe = this.globals.parkTitle.subscribe(title => {
      this.parkTitle = title;
    });
    this.bopValueSubscribe = this.globals.bopValue.subscribe(value => {
      this.bopValue = value;
    });
    this.projEconomicsDataSubscribe = this.globals.projEconomicsData.subscribe(
      res => {
        this.economicDetails = res;
      }
    );
    this.windParkDataSubscribe = this.globals.windParkData.subscribe(res => {
      this.windParkData = res;
    });
    this.updateProjEconomicsData();
    this.sessionSaveInfoSubscribe = this.globals.sessionSaveInfo.subscribe(
      sessionInfo => {
        if (sessionInfo && sessionInfo.windFarmInputs) {
          this.economicDetails = sessionInfo.windFarmInputs.map(trbData => {
            const trb = {
              id: trbData.windselectParkData.parkId,
              windfarmId: trbData.windselectParkData.parkId,
              parkName: trbData.windselectParkData.parkName,
              case: trbData.windselectParkData.caseId,
              wtgPrice: trbData.windselectParkData.wtgPrice || 0,
              transportation: trbData.windselectParkData.transportation || 0,
              installCommCost: trbData.windselectParkData.installCommCost || 0,
              bopCost: trbData.windselectParkData.bopCost || 0,
              otherCapitalCost:
                trbData.windselectParkData.otherCapitalCost || 0,
              omDuring: trbData.windselectParkData.omDuring || 0,
              omPost: trbData.windselectParkData.omPost || 0
            };
            return trb;
          });
          this.updateProjEconomicsData();
        }
      }
    );
    this.listOfCasesSubscribe = this.globals.listOfCases.subscribe(caseList => {
      this.casesList = caseList;
    });
  }

  updateParkDetails() {
    this.windParkData2Subscribe = this.globals.windParkData.subscribe(
      trbData => {
        if (trbData.length) {
          this.economicDetails = trbData.map(wpData => {
            const trb = {
              id: wpData.parkId,
              windfarmId: wpData.parkId,
              parkName: wpData.parkName,
              case: wpData.caseId,
              wtgPrice: wpData.wtgPrice || 0,
              transportation: wpData.transportation || 0,
              installCommCost: wpData.installCommCost || 0,
              bopCost: wpData.bopCost || 0,
              otherCapitalCost: wpData.otherCapitalCost || 0,
              omDuring: wpData.omDuring || 0,
              omPost: wpData.omPost || 0
            };
            return trb;
          });
        }
      }
    );
    this.updateProjEconomicsData();
  }

  addEnergy(trbData) {
    const windfarmId = (trbData && trbData.windfarmId) || 0;
    this.parkIndex = windfarmId;
    const turbine = {
      id: windfarmId,
      windfarmId,
      parkName: '',
      case: '',
      wtgPrice: '',
      transportation: '',
      installCommCost: '',
      bopCost: '',
      otherCapitalCost: '',
      omDuring: '',
      omPost: ''
    };
    this.economicDetails.push(turbine);
    this.updateProjEconomicsData();
  }

  public deleteParkInfo(trbI) {
    this.economicDetails = this.economicDetails.filter(
      item => item.id !== trbI.trb.id
    );
  }

  editProjEconomics(index) {
    this.parkIndex = this.economicDetails[index]
      ? this.economicDetails[index].id
      : 0;
    const data = { index };
    const dialogRef = this.dialog.open(ProjEconomicsDialogComponent, {
      disableClose: true,
      width: '1200px',
      maxHeight: '650px',
      data: data
    });
    this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(() => {
      this.globals.currentSession.subscribe(sessionId => {
        const sessionData = {
          windselectId: sessionId
        };
        this.getDynamicCostsSubscribe = this._service
          .getDynamicCosts(sessionData)
          .subscribe(calcData => {
            if (calcData) {
              this.economicDetails = this.economicDetails.map(item => {
                if (calcData.parkDataList.length === 0) {
                  item['wtgPrice'] = 0;
                  item['transportation'] = 0;
                  item['installCommCost'] = 0;
                  item['bopCost'] = 0;
                  item['otherCapitalCost'] = 0;
                  item['omDuring'] = 0;
                  item['omPost'] = 0;
                  item['case'] = item.case;
                  item['id'] = item.id;
                  item['parkName'] = item.parkName;
                  item['windfarmId'] = item.windfarmId;
                } else if (item.id === this.parkIndex) {
                  calcData['parkDataList'].map(calc => {
                    if (item.id === calc['parkId']) {
                      item = { ...item };
                      item['wtgPrice'] = calc['wtgPrice'] || 0;
                      item['transportation'] = calc['transportationCost'] || 0;
                      item['installCommCost'] = calc['installCommCost'] || 0;
                      item['bopCost'] = calc['bopCost'] || 0;
                      item['otherCapitalCost'] = calc['otherCapitalCost'] || 0;
                      item['omDuring'] = calc['omDuring'] || 0;
                      item['omPost'] = calc['omPost'] || 0;
                    }
                    this.windParkData.map(res => {
                      if (res.parkId === item.id) {
                        res.wtgPrice = item.wtgPrice;
                        res.transportation = item.transportation;
                        res.installCommCost = item.installCommCost;
                        res.bopCost = item.bopCost;
                        res.otherCapitalCost = item.otherCapitalCost;
                        res.omDuring = item.omDuring;
                        res.omPost = item.omPost;
                      }
                    });
                  });
                } else {
                  item = { ...item };
                  this.windParkData.map(res => {
                    if (res.parkId === item.id) {
                      res.wtgPrice = item.wtgPrice;
                      res.transportation = item.transportation;
                      res.installCommCost = item.installCommCost;
                      res.bopCost = item.bopCost;
                      res.otherCapitalCost = item.otherCapitalCost;
                      res.omDuring = item.omDuring;
                      res.omPost = item.omPost;
                    }
                  });
                }
                return item;
              });
              this.updateProjEconomicsData();
            }
          });
      });
    });
  }

  openBOP() {
    this.openBopCalculation.emit({});
  }

  updateBOP() {
    this.bopValue2Subscribe = this.globals.bopValue.subscribe(value => {
      this.bopValue = value;
      if (value) {
        this.windParkData3Subscribe = this.globals.windParkData.subscribe(
          wpData => {
            wpData.map((obj, index) => {
              let turbineMW = 0;
              // to calculate the BOP take the first turbine mw from the wind park and multiply with BOP value
              this.getHubHeightsListSubscribe = this._service
                .getHubHeightsList(obj.selectedPCList[0].turbineId)
                .subscribe(hubList => {
                  turbineMW = hubList.namePlateRatingMw;
                  if (turbineMW) {
                    this.economicDetails[index].bopCost = (
                      +this.bopValue * +turbineMW
                    ).toFixed(2);
                    this.updateProjEconomicsData();
                  }
                });
            });
          }
        );
      }
    });
  }

  updateProjEconomicsData() {
    this.globals.changeProjEconomics(this.economicDetails);
  }

  getCaseName(caseId) {
    let caseName = '';
    if (this.casesList.length) {
      this.casesList.map(item => {
        if (item.id === caseId) {
          caseName = item.name;
        }
      });
    }
    return caseName;
  }

  ngOnDestroy() {
    if (this.parkTitleSubscribe) {
      this.parkTitleSubscribe.unsubscribe();
    }
    if (this.bopValueSubscribe) {
      this.bopValueSubscribe.unsubscribe();
    }
    if (this.projEconomicsDataSubscribe) {
      this.projEconomicsDataSubscribe.unsubscribe();
    }
    if (this.windParkDataSubscribe) {
      this.windParkDataSubscribe.unsubscribe();
    }
    if (this.sessionSaveInfoSubscribe) {
      this.sessionSaveInfoSubscribe.unsubscribe();
    }
    if (this.listOfCasesSubscribe) {
      this.listOfCasesSubscribe.unsubscribe();
    }
    if (this.windParkData2Subscribe) {
      this.windParkData2Subscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
    if (this.getDynamicCostsSubscribe) {
      this.getDynamicCostsSubscribe.unsubscribe();
    }
    if (this.bopValue2Subscribe) {
      this.bopValue2Subscribe.unsubscribe();
    }
    if (this.windParkData3Subscribe) {
      this.windParkData3Subscribe.unsubscribe();
    }
    if (this.getHubHeightsListSubscribe) {
      this.getHubHeightsListSubscribe.unsubscribe();
    }
  }
}
