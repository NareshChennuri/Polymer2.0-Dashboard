import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import {
  MatDialog,
  MatTableDataSource,
  MAT_DIALOG_DATA,
  MatDialogRef
} from '@angular/material';
import { FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { DataService } from '../../shared/api/data.service';
import { ProjectEconomicsDetailsComponent } from '../project-economics-details.component';
import { ProjEconomicsAddComponent } from './proj-economics-add/proj-economics-add.component';
import { ProjEconomicsEditComponent } from './proj-economics-edit/proj-economics-edit.component';
import { GlobalsService } from '../../shared/api/globals.service';

export interface Element {
  configId: number;
  windselectId: string;
  parkId: number;
  windselectTurbineInputsId: number;
  turbineId: number;
  configItemCost: string;
  configItemVal: string;
  configStartDate: string;
  configEndDate: string;
  escalationStartDate: string;
  unitsOfMeasure: string;
  applyOn: string;
}

const ELEMENT_DATA: Element[] = [];

@Component({
  selector: 'app-proj-economics-dialog',
  templateUrl: './proj-economics-dialog.component.html',
  styleUrls: ['./proj-economics-dialog.component.css']
})
export class ProjEconomicsDialogComponent implements OnInit, OnDestroy {
  private currentSessionSubscribe: Subscription;
  private parkTitleSubscribe: Subscription;
  private windParkDataSubscribe: Subscription;
  private getEconomicConfigurationsSubscribe: Subscription;
  private getEconomicConfigurations2Subscribe: Subscription;
  private saveEconomicConfigurationsSubscribe: Subscription;
  private saveEconomicConfigurations2Subscribe: Subscription;
  private getConfigSequenceSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  private afterClosed2Subscribe: Subscription;
  private afterClosed3Subscribe: Subscription;
  private deleteProjEconomincConfigurationSubscribe: Subscription;
  currentSessionId: string;
  parkTitle: string;
  selectedRowId: number;
  selectedOpt: string;
  capital = new FormControl();
  capitalOptions: Observable<string[]>;
  selectedRecord: any;
  displayedColumns: string[] = [
    'configItemCost',
    'configItemVal',
    'configStartDate',
    'configEndDate',
    'unitsOfMeasure',
    'escalation',
    'escalationStartDate',
    'turbineId'
  ];
  options: string[] = [
    'WTG Price',
    'Transportation',
    'Install/Comm Cost',
    'BOP Costs',
    'O&M Contract Price/Yr',
    'O&M Price/Yr Post Contract',
    'Other Capital Cost'
  ];
  windParkData: object[] = [];
  configurationListItems: object[] = [];
  unitsListItems = [{ id: 'Direct Amount', name: 'Direct Amount' }];
  applyOnListItems: any = [];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  constructor(
    public dialog: MatDialog,
    private dataService: DataService,
    public dialogRef: MatDialogRef<ProjectEconomicsDetailsComponent>,
    private globals: GlobalsService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.currentSessionSubscribe = this.globals.currentSession.subscribe(
      sessionId => {
        this.currentSessionId = sessionId;
      }
    );
    const _this = this;
    this.capitalOptions = this.capital.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
    this.parkTitleSubscribe = this.globals.parkTitle.subscribe(title => {
      this.parkTitle = title;
    });
    this.windParkDataSubscribe = this.globals.windParkData.subscribe(data => {
      _this.windParkData = data[_this.data.index];
      if (_this.windParkData) {
        const configArray = [];
        const parkIdVal = _this.windParkData['parkId']
          ? _this.windParkData['parkId'].toString()
          : '';
        if (_this.windParkData['selectedPCList'].length) {
          for (
            let i = 0;
            i < _this.windParkData['selectedPCList'].length;
            i++
          ) {
            const pcData = _this.windParkData['selectedPCList'][i];
            const parkId = parkIdVal;
            const units = pcData['units'] ? pcData['units'] : '';
            const turbineId = pcData['turbineId'] ? pcData['turbineId'] : '';
            const selectedPCId = pcData['selectedPCId']
              ? pcData['selectedPCId']
              : '';
            const turbineName = pcData['turbineName']
              ? pcData['turbineName']
              : '';
            const hubHeight = pcData['hubHeight'] ? pcData['hubHeight'] : '';
            configArray.push({
              id: turbineId + '_' + selectedPCId + '_' + parkId,
              name: units + ' * ' + turbineName + ' - ' + hubHeight
            });
          }
        }
        _this.configurationListItems = configArray;
      }
    });
    this.fetchEconomicConfigData(true);
  }

  fetchEconomicConfigData(filterByParkId) {
    if (filterByParkId) {
      this.getEconomicConfigurationsSubscribe = this.dataService
        .getEconomicConfigurations({
          windselectId: this.currentSessionId
        })
        .subscribe(data => {
          this.dataSource.data = data.filter(
            obj => obj['parkId'] === this.windParkData['parkId']
          );
          this.dataSource.data = this.groupData(this.dataSource.data);
          this.data.configData = this.dataSource.data;
          this.dataSource._updateChangeSubscription();
        });
    } else {
      this.getEconomicConfigurations2Subscribe = this.dataService
        .getEconomicConfigurations({
          windselectId: this.currentSessionId
        })
        .subscribe(data => {
          this.dataSource.data = data;
          this.dataSource.data = this.groupData(this.dataSource.data);
          this.data.configData = this.dataSource.data;
        });
    }
  }

  groupData(data) {
    // get the unique turbine ids
    const ti = [];
    const tt = [];
    data.forEach(i => {
      if (ti.indexOf(i.windselectTurbineInputsId) === -1) {
        ti.push(i.windselectTurbineInputsId);
        tt.push({
          turbineId: i.turbineId,
          parkId: i.parkId,
          windselectTurbineInputsId: i.windselectTurbineInputsId
        });
      }
    });

    // get the unique configurationValues
    const configTypes = [];
    data.forEach(i => {
      if (configTypes.indexOf(i.configItemCost) === -1) {
        configTypes.push(i.configItemCost);
      }
    });

    // sort records by startDate
    data.sort(function(a, b) {
      return (
        new Date(a.configStartDate).getTime() -
        new Date(b.configStartDate).getTime()
      );
    });

    const sortingArr = [
      'WTG Price',
      'Transportation',
      'Install/Comm Cost',
      'BOP Costs',
      'OMDURING',
      'OMPOST',
      'Other Capital Cost'
    ];

    configTypes.sort(function(a, b) {
      return sortingArr.indexOf(a) - sortingArr.indexOf(b);
    });

    // group by turbine ids
    const groupedData = [];
    ti.forEach(i => {
      groupedData.push(data.filter(d => d.windselectTurbineInputsId === i));
    });

    const result = [];
    // get the records grouped by config Item
    groupedData.forEach(i => {
      const grouped = this.groupBy(i, l => l.configItemCost);
      const sortedData = [];
      configTypes.forEach(c => {
        const configData = grouped.get(c);
        if (configData) {
          sortedData.push(configData);
        }
      });
      result.push({
        windselectTurbineInputsId: i[0].windselectTurbineInputsId,
        sortedData
      });
    });

    const totalRecords = [];
    result.forEach(t => {
      t.sortedData.forEach(r => {
        r.forEach(k => {
          totalRecords.push(k);
        });
      });
    });

    const finalData = [];
    tt.forEach(i => {
      let turbineName = this.getConfigurationName(
        i.parkId,
        i.windselectTurbineInputsId,
        i.turbineId
      );
      if (turbineName === '') {
        turbineName = 'Turbine not found in WindPark';
      }
      const obj = { initial: turbineName, isGroupBy: true };
      finalData.push(obj);
      const rows = totalRecords.filter(
        d => d.windselectTurbineInputsId === i.windselectTurbineInputsId
      );
      rows.forEach(r => finalData.push(r));
    });

    return finalData;
  }

  groupBy(list, keyGetter) {
    const mapIt = new Map();
    list.forEach(item => {
      const key = keyGetter(item);
      const collection = mapIt.get(key);
      if (!collection) {
        mapIt.set(key, [item]);
      } else {
        collection.push(item);
      }
    });
    return mapIt;
  }

  isGroup(index, item): boolean {
    return item.isGroupBy;
  }

  saveProjEconomicsConfiguration(result) {
    if (result.action && result.action === 'edit') {
      let parkId = 0;
      let windselectTurbineInputsId = 0;
      let turbineId = 0;
      if (result.record.configuration.toString().split('_').length > 1) {
        parkId = result.record.configuration.split('_')[2];
        windselectTurbineInputsId =
          result.record.configuration.split('_')[1] || 0;
        turbineId = result.record.configuration.split('_')[0] || 0;
      } else {
        parkId = result.record.configuration;
      }
      const recordData = {
        configId: result.record.configId,
        windselectId: this.currentSessionId,
        parkId: parkId,
        windselectTurbineInputsId: windselectTurbineInputsId,
        turbineId: turbineId,
        configItemCost: result.record.configItemCost,
        configItemVal: result.record.configItemVal,
        configStartDate: this.globals.removeTimeZone(
          result.record.configStartDate
        ),
        configEndDate: this.globals.removeTimeZone(result.record.configEndDate),
        configuration: result.record.configuration,
        unitsOfMeasure: result.record.unitsOfMeasure,
        applyOn: result.record.applyOn,
        escalation: result.record.escalation || 0
      };
      if (
        result.record.configItemCost === 'OMDURING' ||
        result.record.configItemCost === 'OMPOST'
      ) {
        recordData['escalationStartDate'] = this.globals.removeTimeZone(
          result.record.escalationStartDate
        );
      } else {
        recordData['escalationStartDate'] = '';
      }
      this.saveEconomicConfigurationsSubscribe = this.dataService
        .saveEconomicConfigurations(recordData)
        .subscribe(saveStatus => {
          if (saveStatus.message) {
            this.toastr.success(`${saveStatus.message} !!`);
          }
          this.fetchEconomicConfigData(true);
        });
    } else {
      let parkId = 0;
      let windselectTurbineInputsId = 0;
      let turbineId = 0;
      if (result.configuration.toString().split('_').length > 1) {
        parkId = result.configuration.split('_')[2];
        windselectTurbineInputsId = result.configuration.split('_')[1] || 0;
        turbineId = result.configuration.split('_')[0] || 0;
      } else {
        parkId = result.configuration;
      }
      const recordData = {
        configId: result.record.configId,
        windselectId: this.currentSessionId,
        parkId: parkId,
        windselectTurbineInputsId: windselectTurbineInputsId,
        turbineId: turbineId,
        configItemCost: result.capital,
        configItemVal: result.price,
        configStartDate: this.globals.removeTimeZone(result.startDate),
        configEndDate: this.globals.removeTimeZone(result.endDate),
        configuration: result.configuration,
        unitsOfMeasure: result.units,
        applyOn: result.applyOn,
        escalation: result.escalation || 0
      };
      if (result.capital === 'OMDURING' || result.capital === 'OMPOST') {
        recordData['escalationStartDate'] = result.escalationStartDate;
      } else {
        recordData['escalationStartDate'] = '';
      }
      this.saveEconomicConfigurations2Subscribe = this.dataService
        .saveEconomicConfigurations(recordData)
        .subscribe(saveStatus => {
          if (saveStatus.message) {
            this.toastr.success(`${saveStatus.message} !!`);
          }
          this.fetchEconomicConfigData(true);
        });
    }
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option =>
      option.toLowerCase().includes(filterValue)
    );
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  addEnergyRow() {
    const _this = this;
    this.getConfigSequenceSubscribe = this.dataService
      .getConfigSequence()
      .subscribe(cId => {
        const configId = cId.configId;
        const data = {};
        const record = {
          configId: configId,
          configuration: '',
          capital: '',
          price: '',
          units: '',
          applyOn: '',
          startDate: '',
          endDate: '',
          escalation: '',
          escalationStartDate: ''
        };
        data['record'] = record;
        data['capitalOptions'] = _this.capitalOptions;
        data['windParkData'] = _this.windParkData;
        data['configurationListItems'] = _this.configurationListItems;
        data['unitsListItems'] = _this.unitsListItems;
        const dialogRef = this.dialog.open(ProjEconomicsAddComponent, {
          width: '1100px',
          data: data
        });

        this.afterClosedSubscribe = dialogRef
          .afterClosed()
          .subscribe(result => {
            _this.selectedRowId = null;
            if (result) {
              if (result.capital === 'O&M Contract Price/Yr') {
                result.capital = 'OMDURING';
              }
              if (result.capital === 'O&M Price/Yr Post Contract') {
                result.capital = 'OMPOST';
              }
              _this.saveProjEconomicsConfiguration(result);
            }
          });
      });
  }

  openActionDialog(id: number, flag: string): void {
    this.selectedRowId = id;
    if (flag === 'edit') {
      const data = {};
      const record = this.dataSource.data.filter(obj => {
        return obj.configId === id;
      })[0];
      this.selectedRecord = { ...record };
      data['record'] = record;
      data['record']['configStartDate'] = this.globals.returnFormattedDate(
        record.configStartDate
      );
      data['record']['configEndDate'] = this.globals.returnFormattedDate(
        record.configEndDate
      );
      if (
        data['record']['configItemCost'] === 'OMPOST' ||
        data['record']['configItemCost'] === 'OMDURING'
      ) {
        data['record'][
          'escalationStartDate'
        ] = this.globals.returnFormattedDate(record.escalationStartDate);
      } else {
        data['record']['escalationStartDate'] = '';
      }
      data['action'] = flag;
      data['options'] = this.options;
      data['capitalOptions'] = this.capitalOptions;
      data['windParkData'] = this.windParkData;
      data['unitsListItems'] = this.unitsListItems;
      data['configurationListItems'] = this.configurationListItems;
      const dialogRef = this.dialog.open(ProjEconomicsEditComponent, {
        width: '1100px',
        data: data
      });
      this.afterClosed2Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          if (result.record.configItemCost === 'O&M Contract Price/Yr') {
            result.record.configItemCost = 'OMDURING';
          }
          if (result.record.configItemCost === 'O&M Price/Yr Post Contract') {
            result.record.configItemCost = 'OMPOST';
          }
          this.saveProjEconomicsConfiguration(result);
        }
        if (!result) {
          const dataSource = this.dataSource.data.map(obj => {
            if (obj.configId === id) {
              obj = this.selectedRecord;
            }
            return obj;
          });
          this.dataSource.data = dataSource;
          this.data.configData = this.dataSource.data;
        }
      });
    }
    if (flag === 'delete') {
      const record = { id, action: flag };
      const dialogRef = this.dialog.open(ProjEconomicsEditComponent, {
        width: '300px',
        data: record
      });
      this.afterClosed3Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          this.deleteProjEconomincConfigurationSubscribe = this.dataService
            .deleteProjEconomincConfiguration({ configId: id })
            .subscribe(deleteStatus => {
              if (deleteStatus['configId']) {
                this.toastr.success(`Item deleted successfully!!`);
              }
              this.fetchEconomicConfigData(true);
            });
        }
      });
    }
  }

  getConfigurationName(parkId, windselectTurbineInputsId, turbineId): string {
    let configurationObj = {};
    if (parkId && windselectTurbineInputsId && turbineId) {
      configurationObj = this.configurationListItems.filter(
        obj =>
          obj['id'] ===
          turbineId + '_' + windselectTurbineInputsId + '_' + parkId
      )[0];
    } else if (parkId) {
      configurationObj = this.configurationListItems.filter(
        obj => obj['id'] === parkId.toString()
      )[0];
    }
    return configurationObj && configurationObj['name']
      ? configurationObj['name']
      : '';
  }

  getUnitsOfMeasureName(unitsOfMeasureId): string {
    let unitOfMeasure = {};
    if (unitsOfMeasureId) {
      unitOfMeasure = this.unitsListItems.filter(
        obj => obj['id'] === unitsOfMeasureId
      )[0];
    }
    return unitOfMeasure && unitOfMeasure['name'] ? unitOfMeasure['name'] : '';
  }

  getApplyOnName(applyOnId): string {
    const applyOn = {};
    if (applyOnId) {
      // applyOn = this.applyOnListItems.filter(obj => obj['id'] === applyOnId)[0];
    }
    return applyOn && applyOn['name'] ? applyOn['name'] : '';
  }

  ngOnDestroy() {
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
    if (this.parkTitleSubscribe) {
      this.parkTitleSubscribe.unsubscribe();
    }
    if (this.windParkDataSubscribe) {
      this.windParkDataSubscribe.unsubscribe();
    }
    if (this.getEconomicConfigurationsSubscribe) {
      this.getEconomicConfigurationsSubscribe.unsubscribe();
    }
    if (this.getEconomicConfigurations2Subscribe) {
      this.getEconomicConfigurations2Subscribe.unsubscribe();
    }
    if (this.saveEconomicConfigurationsSubscribe) {
      this.saveEconomicConfigurationsSubscribe.unsubscribe();
    }
    if (this.saveEconomicConfigurations2Subscribe) {
      this.saveEconomicConfigurations2Subscribe.unsubscribe();
    }
    if (this.getConfigSequenceSubscribe) {
      this.getConfigSequenceSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
    if (this.afterClosed2Subscribe) {
      this.afterClosed2Subscribe.unsubscribe();
    }
    if (this.afterClosed3Subscribe) {
      this.afterClosed3Subscribe.unsubscribe();
    }
    if (this.deleteProjEconomincConfigurationSubscribe) {
      this.deleteProjEconomincConfigurationSubscribe.unsubscribe();
    }
  }
}
