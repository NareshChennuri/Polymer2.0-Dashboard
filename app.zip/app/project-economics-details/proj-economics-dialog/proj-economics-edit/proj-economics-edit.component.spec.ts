import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjEconomicsEditComponent } from './proj-economics-edit.component';

describe('ProjEconomicsEditComponent', () => {
  let component: ProjEconomicsEditComponent;
  let fixture: ComponentFixture<ProjEconomicsEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjEconomicsEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjEconomicsEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
