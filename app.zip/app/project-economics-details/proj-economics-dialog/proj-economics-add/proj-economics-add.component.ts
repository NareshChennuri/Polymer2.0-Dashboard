import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';
import { DataService } from '../../../shared/api/data.service';
import { ProjEconomicsDialogComponent } from '../proj-economics-dialog.component';
import { GlobalsService } from '../../../shared/api/globals.service';

@Component({
  selector: 'app-proj-economics-add',
  templateUrl: './proj-economics-add.component.html',
  styleUrls: ['./proj-economics-add.component.css']
})
export class ProjEconomicsAddComponent implements OnInit, OnDestroy {
  private currentSessionSubscribe: Subscription;
  private codDateSubscribe: Subscription;
  private constructionStartDateGlobalSubscribe: Subscription;
  private findOmDuringEscSubscribe: Subscription;
  codDate: Date;
  constructionStart: Date;
  duringEndDate: Date;
  currentSessionId: any;
  constructor(
    public dialogRef: MatDialogRef<ProjEconomicsDialogComponent>,
    private globals: GlobalsService,
    private dataService: DataService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.currentSessionSubscribe = this.globals.currentSession.subscribe(
      sessionId => {
        this.currentSessionId = sessionId;
      }
    );

    this.codDateSubscribe = this.globals.codDate.subscribe(date => {
      this.codDate = new Date(this.globals.returnFormattedDate(date));
    });

    this.constructionStartDateGlobalSubscribe = this.globals.constructionStartDateGlobal.subscribe(
      date => {
        this.constructionStart = new Date(
          this.globals.returnFormattedDate(date)
        );
      }
    );

    this.data.startDate = this.constructionStart;
    this.data.endDate = this.codDate;
    this.data.escalationStartDate = this.codDate;
    this.data.units = 'Direct Amount';
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  configItemChange() {
    const year = this.codDate.getFullYear();
    const month = this.codDate.getMonth();
    const day = this.codDate.getDate();
    const studyPeriodVal = parseInt(this.data.windParkData.studyPeriod, 10);
    const windSelectTurbineInputsId = parseInt(
      this.data.configuration.split('_')[1],
      10
    );
    const parkId = parseInt(this.data.configuration.split('_')[2], 10);
    if (this.data.capital === 'O&M Contract Price/Yr') {
      this.data.units = 'Price/Unit';
      this.data.startDate = this.codDate;
      this.data.escalationStartDate = this.codDate;
      // O&M During date logic - COD + 10 years
      this.data.endDate = new Date(year + 10, month, day - 1);
      this.dateChange();
    } else if (this.data.capital === 'O&M Price/Yr Post Contract') {
      const req = {
        windselectId: this.currentSessionId,
        parkId: parkId,
        windselectTurbineInputsId: windSelectTurbineInputsId
      };
      this.data.units = 'Price/Unit';
      this.data.escalationStartDate = this.codDate;
      // O&M POST date logic
      this.data.endDate = new Date(year + studyPeriodVal, month, day - 1);
      this.findOmDuringEscSubscribe = this.dataService.findOmDuringEsc(req).subscribe(omresp => {
        this.data.escalation = omresp[0].escalation;
        this.duringEndDate = new Date(
          this.globals.returnFormattedDate(omresp[0].configEndDate)
        );
        const duringYear = this.duringEndDate.getFullYear();
        const duringMonth = this.duringEndDate.getMonth();
        const duriungDay = this.duringEndDate.getDate();
        this.data.startDate = new Date(duringYear, duringMonth, duriungDay + 1);
      });
      this.dateChange();
    } else {
      this.data.units = 'Direct Amount';
      this.dateChange();
    }
  }

  dateChange() {
    const startDate = this.data.startDate;
    const endDate = this.data.endDate;
  }

  ngOnDestroy() {
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
    if (this.codDateSubscribe) {
      this.codDateSubscribe.unsubscribe();
    }
    if (this.constructionStartDateGlobalSubscribe) {
      this.constructionStartDateGlobalSubscribe.unsubscribe();
    }
    if (this.findOmDuringEscSubscribe) {
      this.findOmDuringEscSubscribe.unsubscribe();
    }
  }
}
