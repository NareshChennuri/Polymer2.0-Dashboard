import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjEconomicsAddComponent } from './proj-economics-add.component';

describe('ProjEconomicsAddComponent', () => {
  let component: ProjEconomicsAddComponent;
  let fixture: ComponentFixture<ProjEconomicsAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjEconomicsAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjEconomicsAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
