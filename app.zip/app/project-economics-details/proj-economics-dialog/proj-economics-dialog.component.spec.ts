import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjEconomicsDialogComponent } from './proj-economics-dialog.component';

describe('ProjEconomicsDialogComponent', () => {
  let component: ProjEconomicsDialogComponent;
  let fixture: ComponentFixture<ProjEconomicsDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjEconomicsDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjEconomicsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
