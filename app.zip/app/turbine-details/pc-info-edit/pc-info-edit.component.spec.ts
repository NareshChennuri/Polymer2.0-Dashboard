import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PcInfoEditComponent } from './pc-info-edit.component';

describe('PcInfoEditComponent', () => {
  let component: PcInfoEditComponent;
  let fixture: ComponentFixture<PcInfoEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PcInfoEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PcInfoEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
