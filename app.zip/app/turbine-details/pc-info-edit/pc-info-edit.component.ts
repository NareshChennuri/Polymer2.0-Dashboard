import {
  Component,
  Inject,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  OnInit
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatSelect } from '@angular/material';
import { FormControl } from '@angular/forms';
import { ReplaySubject, Subject, Subscription } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { combineLatest } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { TurbineDetailsComponent } from '../turbine-details.component';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';

@Component({
  selector: 'app-pc-info-edit',
  templateUrl: './pc-info-edit.component.html',
  styleUrls: ['./pc-info-edit.component.css']
})
export class PcInfoEditComponent implements OnInit, AfterViewInit, OnDestroy {
  private marketInfoDataSubscribe: Subscription;
  private currentSessionSubscribe: Subscription;
  private projEconomicsDataSubscribe: Subscription;
  private getHubHeightsListSubscribe: Subscription;
  private selectedPcInfoFilterCtrlSubscribe: Subscription;
  private filteredPCListSubscribe: Subscription;
  private combinedSubscribe: Subscription;
  private getMaxRateSubscribe: Subscription;
  private deletePCInfoSubscribe: Subscription;
  private getDynamicCostsSubscribe: Subscription;
  powercurveFullList: any[];
  powercurveList: any[];
  pvalues: any[] = [];
  defaultPval: any[] = [];
  selectedPCList: any[] = [];
  selectePValList: any[] = [];
  marketInfoData: any[] = [];
  selectedSession: any;
  parkId: any;
  economicDetails = [];
  windParkData: any[];

  selectedPcInfoCtrl: FormControl = new FormControl();
  selectedPcInfoFilterCtrl: FormControl = new FormControl();
  filteredPCList: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  @ViewChild('singleSelect') singleSelect: MatSelect;
  protected _onDestroy = new Subject<void>();

  constructor(
    public dialogRef: MatDialogRef<TurbineDetailsComponent>,
    private dataService: DataService,
    private globals: GlobalsService,
    private toaster: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    const localData = { ...data };
    this.selectedPCList = this.powercurveList = this.powercurveFullList = this.powercurveList = [];
    if (localData.turbineInfo.powercurveList.length) {
      const sortedPCList = localData.turbineInfo.powercurveList.sort((a, b) => {
        if (a[1] < b[1]) {
          return -1;
        }
        if (a[1] > b[1]) {
          return 1;
        }
        return 0;
      });
      this.powercurveList = sortedPCList;
      this.powercurveFullList = sortedPCList;
    }
    this.pvalues = localData.turbineInfo.pvalues;
    this.selectedPCList = localData.turbineInfo.selectedPCList;
    this.parkId = localData.turbineInfo.parkId;
    this.defaultPval = localData.turbineInfo.pvalues.filter(item => {
      if (item.pvalue.indexOf('-Default') > -1) {
        return item;
      }
    });
    this.marketInfoDataSubscribe = this.globals.marketInfoData.subscribe(
      marketInfoData => {
        this.marketInfoData = marketInfoData;
      }
    );
    this.currentSessionSubscribe = this.globals.currentSession.subscribe(
      sessionDetails => {
        this.selectedSession = sessionDetails;
      }
    );
    this.projEconomicsDataSubscribe = this.globals.projEconomicsData.subscribe(
      res => {
        this.economicDetails = res;
      }
    );

    if (this.selectedPCList && this.selectedPCList.length > 0) {
      this.selectedPCList = this.selectedPCList.map((pcItem, index) => {
        const pcDataItem = {
          ...pcItem,
          hubHeightsList: []
        };
        this.getHubHeightsListSubscribe = this.dataService
          .getHubHeightsList(pcItem.turbineId)
          .subscribe(hubList => {
            const currentHubList = hubList;
            Object.keys(currentHubList).filter(hb => {
              if (currentHubList[hb] !== null && hb.indexOf('hubHeight') > -1) {
                pcDataItem.hubHeightsList.push(currentHubList[hb]);
              }
            });
            pcDataItem['mw'] = pcDataItem.megaWatts || 0;
            pcDataItem['megaWatts'] = pcDataItem.megaWatts || 0;
            pcDataItem['turbineQuantity'] = pcDataItem.units;
            pcDataItem.namePlateRatingMw = hubList.namePlateRatingMw;
          });
        return pcDataItem;
      });
    }
  }

  ngOnInit() {
    this.filteredPCList.next(this.powercurveList.slice());
    this.selectedPcInfoFilterCtrlSubscribe = this.selectedPcInfoFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filteredPcs();
      });
  }

  ngAfterViewInit(): void {
    this.setInitialValue();
  }

  protected setInitialValue() {
    this.filteredPCListSubscribe = this.filteredPCList
      .pipe(
        take(1),
        takeUntil(this._onDestroy)
      )
      .subscribe(() => {
        this.singleSelect.compareWith = (a: any, b: any) =>
          a && b && a.id === b.id;
      });
  }

  protected filteredPcs() {
    if (!this.powercurveList) {
      return;
    }
    let search = this.selectedPcInfoFilterCtrl.value;
    if (!search) {
      this.filteredPCList.next(this.powercurveList.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredPCList.next(
      (this.powercurveList = this.powercurveFullList.filter(pcInfo => {
        return pcInfo[1].toLowerCase().indexOf(search) > -1;
      }))
    );
  }

  public countChange($eve, trbInfo) {
    const qty = $eve.target.value;
    if (qty) {
      this.selectedPCList = this.selectedPCList.map(item => {
        if (item.selectedPCId === trbInfo.selectedPCId) {
          item.mw = parseFloat(item.maxRating) * parseInt(qty, 10) || 0;
          item.megaWatts =
            (parseFloat(item.maxRating) * parseInt(qty, 10)).toFixed(0) || 0;
        }
        return item;
      });
    }
    this.validateTotalMWUnits();
  }

  public mwChange($eve, trbInfo) {
    const mw = $eve.target.value;
    if (mw) {
      this.selectedPCList = this.selectedPCList.map(item => {
        if (item.selectedPCId === trbInfo.selectedPCId) {
          const toalQty = Math.round(
            parseFloat(mw) / parseFloat(item.maxRating)
          );
          item.units = toalQty.toFixed(0) || 0;
        }
        return item;
      });
    }
    this.validateTotalMWUnits();
  }

  public pcInfoChange($eve) {
    const pcId = $eve.value;
    if (pcId) {
      this.powercurveFullList.filter(item => {
        if (item[0] === pcId) {
          const currentItem = {
            turbineId: item[0],
            turbineName: item[1],
            namePlateRatingMw: 0,
            maxRating: 0,
            hubHeightsList: []
          };

          if (!item.uncertainty) {
            currentItem['uncertainty'] = this.defaultPval[0].uncertainty;
          }
          if (!item.pvalue) {
            currentItem['pvalue'] = this.defaultPval[0].pvalue;
          }
          if (!item.units) {
            currentItem['units'] = 0;
          }
          if (!item.mw) {
            currentItem['mw'] = 0;
          }
          if (!item.megaWatts) {
            currentItem['megaWatts'] = 0;
          }
          const trbSeq$ = this.dataService.getTurbineSequence();
          const hubList$ = this.dataService.getHubHeightsList(item[0]);
          const combined = combineLatest(trbSeq$, hubList$);
          this.combinedSubscribe = combined.subscribe(([trbSeq, hubList]) => {
            currentItem['windselectTurbineInputsId'] =
              trbSeq.windselectTurbineInputsId;
            currentItem['selectedPCId'] = trbSeq.windselectTurbineInputsId;
            const currentHubList = hubList;
            Object.keys(currentHubList).filter(hb => {
              if (currentHubList[hb] !== null && hb.indexOf('hubHeight') > -1) {
                currentItem.hubHeightsList.push(currentHubList[hb]);
              }
            });

            currentItem['turbineQuantity'] = hubList.units;
            currentItem.namePlateRatingMw = hubList.namePlateRatingMw;
            this.selectedPCList = [...this.selectedPCList, currentItem];
          });

          const reqTrbRate = {
            id: pcId
          };
          this.getMaxRateSubscribe = this.dataService
            .getMaxRate(reqTrbRate)
            .subscribe(res => {
              if (res) {
                currentItem['maxRating'] = res.toFixed(2);
              }
            });
        }
      });

      this.selectedPcInfoCtrl.setValue('');
    }
    this.powercurveList = this.powercurveFullList;
  }

  public pvalChange($eve, pcInfo: any) {
    const pval = $eve.value;
    if (pval) {
      const uncertain = this.pvalues.filter(item => item.pvalue === pval);
      if (uncertain.length > 0) {
        this.selectedPCList.filter(item => {
          if (item && item.selectedPCId === pcInfo.selectedPCId) {
            item.uncertainty = uncertain[0].uncertainty || 0;
            return item;
          }
        });
      }
    }
  }

  public removePcListInfo(pcInfo) {
    if (pcInfo.selectedPCId) {
      const removePcInfo = {
        windSelectId: this.selectedSession,
        windselectTurbineInputsId: pcInfo.selectedPCId
      };
      const dynCapReq = {
        windselectId: this.selectedSession
      };
      this.deletePCInfoSubscribe = this.dataService
        .deletePCInfo(removePcInfo)
        .subscribe(delResp => {
          if (delResp) {
            this.toaster.success(delResp.message);
            this.getDynamicCostsSubscribe = this.dataService
              .getDynamicCosts(dynCapReq)
              .subscribe(dynCapResp => {
                if (dynCapResp) {
                  this.economicDetails = this.economicDetails.map(item => {
                    if (item.id === this.parkId) {
                      dynCapResp['parkDataList'].map(calc => {
                        if (item.id === calc['parkId']) {
                          item = { ...item };
                          item['wtgPrice'] = calc['wtgPrice'] || 0;
                          item['transportation'] =
                            calc['transportationCost'] || 0;
                          item['installCommCost'] =
                            calc['installCommCost'] || 0;
                          item['bopCost'] = calc['bopCost'] || 0;
                          item['otherCapitalCost'] =
                            calc['otherCapitalCost'] || 0;
                          item['omDuring'] = calc['omDuring'] || 0;
                          item['omPost'] = calc['omPost'] || 0;
                        }
                      });
                    }
                    return item;
                  });
                }
                this.globals.changeProjEconomics(this.economicDetails);
              });
          }
        });
      this.selectedPCList = this.selectedPCList.filter(
        item => item.selectedPCId !== pcInfo.selectedPCId
      );
    }
  }

  public close() {
    const constructedDate = {
      ...this.data.turbineInfo,
      selectedPCList: this.selectedPCList
    };
    this.economicDetails.map(item => {
      if (item.id === constructedDate.parkId) {
        (constructedDate.bopCost = item.bopCost),
          (constructedDate.omDuring = item.omDuring),
          (constructedDate.omPost = item.omPost),
          (constructedDate.otherCapitalCost = item.otherCapitalCost),
          (constructedDate.transportation = item.transportation),
          (constructedDate.wtgPrice = item.wtgPrice),
          (constructedDate.otherCapitalCost = item.otherCapitalCost);
      }
    });
    let isError = false;
    const instances = this.selectedPCList.map(item => {
      if (item && item.units > 0 && (!item.hubHeight || item.hubHeight <= 0)) {
        this.toaster.error(`Please Enter HubHeight for ${item.turbineName}`);
        isError = true;
      }
    });

    // tslint:disable-next-line:no-unused-expression
    !isError && this.dialogRef.close(constructedDate);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  validateTotalMWUnits(): void {
    let SumTotalUnits = 0;
    let SumTotalMW = 0;
    for (const obj of this.selectedPCList) {
      SumTotalUnits += +obj.units;
      SumTotalMW += +obj.megaWatts;
    }
    const totalUnits = this.marketInfoData['totalUnits'];
    const totalMW = this.marketInfoData['totalMw'];
    if (SumTotalUnits > totalUnits || SumTotalMW > totalMW) {
      let msg = 'Warning: ';
      if (SumTotalUnits > totalUnits) {
        msg += 'Total Units are exceeding!' + ' ' + (SumTotalUnits - totalUnits) + ' ';
      }
      if (SumTotalMW > totalMW) {
        msg += 'and Total MW is exceeding!' + ' ' + (SumTotalMW - totalMW);
      }
      alert(msg);
    }
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();

    if (this.marketInfoDataSubscribe) {
      this.marketInfoDataSubscribe.unsubscribe();
    }
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
    if (this.projEconomicsDataSubscribe) {
      this.projEconomicsDataSubscribe.unsubscribe();
    }
    if (this.getHubHeightsListSubscribe) {
      this.getHubHeightsListSubscribe.unsubscribe();
    }
    if (this.selectedPcInfoFilterCtrlSubscribe) {
      this.selectedPcInfoFilterCtrlSubscribe.unsubscribe();
    }
    if (this.filteredPCListSubscribe) {
      this.filteredPCListSubscribe.unsubscribe();
    }
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.getMaxRateSubscribe) {
      this.getMaxRateSubscribe.unsubscribe();
    }
    if (this.deletePCInfoSubscribe) {
      this.deletePCInfoSubscribe.unsubscribe();
    }
    if (this.getDynamicCostsSubscribe) {
      this.getDynamicCostsSubscribe.unsubscribe();
    }
  }
}
