import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TurbineDetailsComponent } from './turbine-details.component';

describe('TurbineDetailsComponent', () => {
  let component: TurbineDetailsComponent;
  let fixture: ComponentFixture<TurbineDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TurbineDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TurbineDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
