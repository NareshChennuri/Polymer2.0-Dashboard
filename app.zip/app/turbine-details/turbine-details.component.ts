import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { MatDialog } from '@angular/material';
import { take } from 'rxjs/operators';
import { FormControl } from '@angular/forms';
import { Observable, combineLatest, Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { DataService } from '../shared/api/data.service';
import { GlobalsService } from '../shared/api/globals.service';
import { PcInfoEditComponent } from './pc-info-edit/pc-info-edit.component';
import { CompareParkPCComponent } from './compare-park-pc/compare-park-pc.component';

@Component({
  selector: 'app-turbine-details',
  templateUrl: './turbine-details.component.html',
  styleUrls: ['./turbine-details.component.css']
})
export class TurbineDetailsComponent implements OnInit, OnDestroy {
  private combinedSubscribe: Subscription;
  private listOfCasesSubscribe: Subscription;
  private combinedTrbSubscribe: Subscription;
  private marketInfoDataSubscribe: Subscription;
  private goalSeekDataSubscribe: Subscription;
  private getManufacturers2Subscribe: Subscription;
  private sessionSaveInfoSubscribe: Subscription;
  private getTurbinesSubscribe: Subscription;
  private getTurbinesListSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  private getTurbinesList2Subscribe: Subscription;
  private getWindfarmIdSubscribe: Subscription;
  private getWindfarmId2Subscribe: Subscription;
  private trbSeqSubscribe: Subscription;
  private compareParksSubscribe: Subscription;
  private afterClosed2Subscribe: Subscription;
  private projEconomicsDataSubscribe: Subscription;
  private windParkDataSubscribe: Subscription;
  turbineDetails: any[];
  manufacturers: any[];
  selectedCountry: any;
  selectedState: any;
  currentUser: any;
  pvalues: any[] = [];
  windselectId: any;
  turbineDetailsList: any[] = [];
  casesList: any[];
  cod: any;
  marketCaseValid: boolean;
  @Output() turbineAdded = new EventEmitter<{}>();
  @Output() turbineDeleted = new EventEmitter<{}>();
  @Output() openUpdateBOP = new EventEmitter<{}>();
  @Output() updateParkDetails = new EventEmitter<{}>();
  parkTitle: string;
  loadCaseReqList: any = [];
  buttonDisable = true;
  parkCompareList: any = [];
  goalSeekDetails: any = [];
  turbineInputsId: any = [];
  economicDetails = [];
  windParkData: any[];
  constructor(
    private dataService: DataService,
    private globals: GlobalsService,
    private dialog: MatDialog,
    private toaster: ToastrService
  ) {}
  financialModelling = new FormControl();
  capitalOptions: Observable<string[]>;

  ngOnInit() {
    const sessionDtls$ = this.globals.currentSession;
    const manufacturersList$ = this.dataService.getManufacturers();
    const getPvalues$ = this.dataService.getPValues();
    const getTurbines$ = this.dataService.getTurbines();
    const curretCountry$ = this.globals.currentCountry;
    const curretState$ = this.globals.currentState;
    const curretCases$ = this.globals.listOfCases;
    const curretUser$ = this.globals.currentUser;
    const combined = combineLatest(
      sessionDtls$,
      curretCountry$,
      curretState$,
      manufacturersList$
    );

    this.combinedSubscribe = combined.subscribe(
      ([sessionDtls, country, state, manufacturers]) => {
        this.windselectId = sessionDtls;
        this.selectedCountry = country;
        this.selectedState = state;
        this.manufacturers = manufacturers;
        this.processPadding();
      }
    );

    this.listOfCasesSubscribe = curretCases$.subscribe(caseList => {
      if (caseList.length) {
        this.casesList = caseList;
      } else {
        this.casesList = [];
      }
    });

    const combinedTrb = combineLatest(curretUser$, getPvalues$, getTurbines$);
    this.combinedTrbSubscribe = combinedTrb.subscribe(
      ([userInfo, pvalues, turbinesList]) => {
        this.currentUser = userInfo;
        this.turbineDetails = turbinesList;
        const curentVlaues = pvalues.sort((a, b) => a.id - b.id);
        this.pvalues = curentVlaues;
        this.turbineDetails = this.turbineDetails.map(item => {
          item.pvalues = pvalues;
          return item;
        });
        this.globals.changeparkTitle('Park Name');
        this.getSessionDetails();
        this.processPadding();
      }
    );

    // Start: bind scroll for all the turbine sections
    const scrollers = document.getElementsByClassName('pc-mod');
    const scrollerDivs = Array.prototype.filter.call(scrollers, function(
      testElement
    ) {
      return testElement.nodeName === 'DIV';
    });

    function scrollAll(scrollLeft) {
      scrollerDivs.forEach(function(element) {
        element.scrollLeft = scrollLeft;
      });
    }

    scrollerDivs.forEach(function(element) {
      element.addEventListener('scroll', function(e) {
        scrollAll(e.target.scrollLeft);
      });
    });
    // End: bind scroll for all the trubine sections

    this.marketInfoDataSubscribe = this.globals.marketInfoData.subscribe(
      data => {
        this.cod = data.cod;
        if (
          this.cod &&
          !(typeof this.cod === 'string' || this.cod instanceof String)
        ) {
          this.cod = this.cod.format('YYYY-MM-DD');
        }
      }
    );
    this.goalSeekDataSubscribe = this.globals.goalSeekData.subscribe(goal => {
      if (goal) {
        this.goalSeekDetails = goal;
      }
    });
    this.projEconomicsDataSubscribe = this.globals.projEconomicsData.subscribe(
      res => {
        this.economicDetails = res;
      }
    );
    this.windParkDataSubscribe = this.globals.windParkData.subscribe(res => {
      this.windParkData = res;
    });
  }

  getManufactureList() {
    this.getManufacturers2Subscribe = this.dataService
      .getManufacturers()
      .subscribe(manufacturers => {
        this.manufacturers = manufacturers;
      });
  }

  parkTitleChange($event) {
    if ($event) {
      this.globals.changeparkTitle($event);
    }
  }

  getSessionDetails() {
    this.sessionSaveInfoSubscribe = this.globals.sessionSaveInfo.subscribe(
      turbineInfo => {
        if (turbineInfo && turbineInfo.windFarmInputs) {
          const trbData = turbineInfo.windFarmInputs.map(trbItem => {
            const selectedPCList = trbItem.windselectTurbineInputs.map(
              (pcDtls, i) => {
                const aepInfoFilter = trbItem.windselectTurbineResults.filter(
                  aepItem =>
                    aepItem.windselectTurbineInputsId ===
                    pcDtls.windselectTurbineInputsId
                );
                const aepInfo =
                  aepInfoFilter.length > 0 ? aepInfoFilter[0] : {};
                const pc = {
                  ...pcDtls,
                  ...aepInfo,
                  selectedPCId: pcDtls.windselectTurbineInputsId
                };
                return pc;
              }
            );

            const trb = {
              ...trbItem.windselectParkData,
              id: trbItem.windselectParkData.parkId,
              pvalues: this.pvalues,
              selectedPCList
            };
            return trb;
          });

          this.turbineDetails = trbData.map(trb => {
            this.getTurbinesListSubscribe = this.dataService
              .getTurbinesList(trb.manufacturerId, this.currentUser.roleId)
              .subscribe(detatils => {
                if (detatils) {
                  trbData.filter(pcinfo => {
                    detatils.filter(details => {
                      pcinfo.selectedPCList.filter(pcinfoDtls => {
                        if (details[0] === pcinfoDtls.turbineId) {
                          pcinfoDtls.turbineName = details[1];
                        }
                        return pcinfoDtls;
                      });
                      return details;
                    });
                    return (pcinfo.powercurveList = detatils);
                  });
                }
              });
            trb.primary1 = trb.primary1.toLowerCase() == 'true' ? true : false;
            trb.winner = trb.winner.toLowerCase() == 'true' ? true : false;
            trb.reliable = trb.reliable.toLowerCase() == 'true' ? true : false;
            return trb;
          });
          this.processPadding();
          this.updateWindParkData();
        } else {
          this.updateWindParkData();
        }
      }
    );
  }

  openDialog(turbine: any): void {
    const status = this.getDisbaledStatus(turbine);
    if (!status) {
      const trbString = JSON.stringify(turbine);
      const turbObj = JSON.parse(trbString);
      const dialogRef = this.dialog.open(PcInfoEditComponent, {
        width: '1000px',
        height: '550px',
        data: { turbineInfo: turbObj }
      });

      this.afterClosedSubscribe = dialogRef
        .afterClosed()
        .pipe(take(1))
        .subscribe(result => {
          this.turbineDetails = this.turbineDetails.map(item => {
            if (result && item.id === result.id) {
              if (result.selectedPCList.length === 1) {
                item.ncf = result.selectedPCList[0].ncf;
                item.vavghh = result.selectedPCList[0].vavghh;
                result.ncf = result.selectedPCList[0].ncf;
                result.vavghh = result.selectedPCList[0].vavghh;
              }
              item = {
                ...item,
                ...result
              };
            }
            return item;
          });
          this.updateWindParkData();
          this.processPadding();
          this.updateBOP();
        });
    } else {
      this.toaster.error(`please select manufacturer`);
    }
  }

  onWinnerChange(trb) {
    this.turbineDetails = this.turbineDetails.filter(parkData => {
      if (parkData.id !== trb) {
        parkData.winner = false;
      }
      return parkData;
    });
    this.updateWindParkData();
  }

  updateWindParkData() {
    this.globals.changeWindParkData(this.turbineDetails);
    this.loadCaseReqList = [];
    this.updateParkDetails.emit();
  }

  getDisbaledStatus(trb) {
    return trb.powercurveList.length === 0;
  }

  manufacturerChange($event, trbId) {
    const manufacturer = $event.value;
    if (manufacturer) {
      this.getTurbinesList2Subscribe = this.dataService
        .getTurbinesList(manufacturer, this.currentUser.roleId)
        .subscribe(items => {
          this.turbineDetails.filter(item => {
            if (item.id === trbId) {
              item.powercurveList = items;
              item.selectedPCList = [];
              return item;
            }
          });
        });
    }
  }

  getTotalCount(trb): any {
    if (trb && trb.selectedPCList && trb.selectedPCList.length > 0) {
      let totalCount: any = 0;
      let totalMW: any = 0;

      for (let i = 0; i < trb.selectedPCList.length; i++) {
        const totalUnits = trb.selectedPCList[i].units;
        totalCount += parseInt(totalUnits, 10);
        totalMW += parseFloat(trb.selectedPCList[i].megaWatts);
      }
      totalMW = totalMW.toFixed(0);
      return `Total Turbines: ${totalCount} Total MW: ${totalMW}`;
    } else {
      return ``;
    }
  }

  addTurbine() {
    this.getWindfarmIdSubscribe = this.dataService
      .getWindfarmId()
      .subscribe(trbData => {
        const turbine = {
          id: trbData.windfarmId,
          parkId: trbData.windfarmId, // changed the name of windfarmId to parkId
          powercurveList: [],
          selectedPCList: [],
          powercurve: '',
          pvalues: this.pvalues,
          uncertainty: '',
          projGrossAep: '',
          projNetAep: '',
          NCF: '',
          vavg: '',
          parkComments: ''
        };
        this.turbineDetails.push(turbine);
        this.turbineAdded.emit({ trbData });
        this.updateWindParkData();
        this.processPadding();
        const goal = {
          windParkId: trbData.windfarmId,
          windselectId: this.windselectId,
          wtgPrice: ''
        };
        this.goalSeekDetails.push(goal);
        this.globals.updateGoalSeekDetails(this.goalSeekDetails);
      });
  }

  cloneTurbine(trb) {
    this.turbineInputsId = [];
    this.getWindfarmId2Subscribe = this.dataService
      .getWindfarmId()
      .subscribe(trbData => {
        // Get windselectTurbineInputsId, and add to selectedPCList Iteration
        // const trbSeq$ = this.dataServeice.getTurbineSequence();
        const trbString = JSON.stringify(trb);
        const turbine = JSON.parse(trbString);
        // set Project Economics data to '0'
        turbine.wtgPrice = 0;
        turbine.transportation = 0;
        turbine.installCommCost = 0;
        turbine.bopCost = 0;
        turbine.otherCapitalCost = 0;
        turbine.omDuring = 0;
        turbine.omPost = 0;
        if (turbine.selectedPCList.length) {
          const trList = turbine.selectedPCList.map((trItem, i) => {
            const trbSeq$ = this.dataService.getTurbineSequence();
            this.trbSeqSubscribe = trbSeq$.subscribe(trbSeq => {
              trItem['windselectTurbineInputsId'] =
                trbSeq.windselectTurbineInputsId;
              trItem['selectedPCId'] = trbSeq.windselectTurbineInputsId;
              // console.log('Compare :', i, turbine.selectedPCList.length);
              this.turbineInputsId.push(trbSeq.windselectTurbineInputsId);
              if (i + 1 === turbine.selectedPCList.length) {
                turbine.id = trbData.windfarmId;
                turbine.parkId = trbData.windfarmId;
                turbine.parkName = turbine.parkName+' '+turbine.parkName;
                this.turbineDetails.push(turbine);
                this.updateWindParkData();
                this.processPadding();
                const cloneParkEcoReq = {
                  'turbineInputsId': this.turbineInputsId,
                   'windselectId': this.windselectId,
                   'newParkId': trbData.windfarmId,
                   'cloneParkId': trb.parkId
                };
                const dynReq = {
                'windselectId': this.windselectId
                };
                this.dataService.cloneEconomicsForPark(cloneParkEcoReq).subscribe(result => {
                   if (result) {
                     this.dataService.getDynamicCosts(dynReq).subscribe(dynResult => {
                       console.log('capitals ****', dynResult);
                       console.log('global capitals ****', this.economicDetails);
                      // update economics and windpark objects

                      this.economicDetails = this.economicDetails.map(item => {
                        if (dynResult.parkDataList.length === 0) {
                          item['wtgPrice'] = 0;
                          item['transportation'] = 0;
                          item['installCommCost'] = 0;
                          item['bopCost'] = 0;
                          item['otherCapitalCost'] = 0;
                          item['omDuring'] = 0;
                          item['omPost'] = 0;
                          item['case'] = item.case;
                          item['id'] = item.id;
                          item['parkName'] = item.parkName;
                          item['windfarmId'] = item.windfarmId;
                        } else {
                          dynResult['parkDataList'].map(calc => {
                            if (item.id === calc['parkId']) {
                              item = { ...item };
                              item['wtgPrice'] = calc['wtgPrice'] || 0;
                              item['transportation'] = calc['transportationCost'] || 0;
                              item['installCommCost'] = calc['installCommCost'] || 0;
                              item['bopCost'] = calc['bopCost'] || 0;
                              item['otherCapitalCost'] = calc['otherCapitalCost'] || 0;
                              item['omDuring'] = calc['omDuring'] || 0;
                              item['omPost'] = calc['omPost'] || 0;
                              item['case'] = item.case;
                              item['id'] = item.id;
                              item['parkName'] = item.parkName;
                              item['windfarmId'] = item.windfarmId;
                            }
                            this.windParkData.map(res => {
                              if (res.parkId === item.id) {
                                res.wtgPrice = item.wtgPrice;
                                res.transportation = item.transportation;
                                res.installCommCost = item.installCommCost;
                                res.bopCost = item.bopCost;
                                res.otherCapitalCost = item.otherCapitalCost;
                                res.omDuring = item.omDuring;
                                res.omPost = item.omPost;
                              }
                            });
                          });
                      } // else {
                        //   item = { ...item };
                        //   this.windParkData.map(res => {
                        //     if (res.parkId === item.id) {
                        //       res.wtgPrice = item.wtgPrice;
                        //       res.transportation = item.transportation;
                        //       res.installCommCost = item.installCommCost;
                        //       res.bopCost = item.bopCost;
                        //       res.otherCapitalCost = item.otherCapitalCost;
                        //       res.omDuring = item.omDuring;
                        //       res.omPost = item.omPost;
                        //     }
                        //   });
                        // }
                        return item;
                      });
                      this.globals.changeProjEconomics(this.economicDetails);
                     });
                   }

                });
              }
            });
          });

        } else {
          turbine.id = trbData.windfarmId;
          turbine.parkId = trbData.windfarmId;
          this.turbineDetails.push(turbine);
          this.updateWindParkData();
          this.processPadding();
        }
        this.globals.updateParkComment({
          id: trbData.windfarmId,
          parkComments: turbine.parkComments
        });
        this.globals.updateProjectResults({ windfarmId: trbData.windfarmId });
        const clonedGoal = this.goalSeekDetails.filter(
          data => trb.id === data.windParkId
        );
        const goal = {
          windParkId: trbData.windfarmId,
          windselectId: this.windselectId
          // wtgPrice: clonedGoal[0].wtgPrice || 0
        };
        this.goalSeekDetails.push(goal);
        this.globals.updateGoalSeekDetails(this.goalSeekDetails);
      });
  }

  getNewTrbId() {
    const trbSeq$ = this.dataService.getTurbineSequence();
    return 1;
  }

  removeTurbine(trb) {
    this.turbineDetails = this.turbineDetails.filter(
      item => item.id !== trb.id
    );
    this.turbineDeleted.emit({ trb });
    this.updateWindParkData();
    this.processPadding();
    if (this.goalSeekDetails.length > 0) {
      this.goalSeekDetails = this.goalSeekDetails.filter(
        data => data.windParkId !== trb.id
      );
      this.globals.updateGoalSeekDetails(this.goalSeekDetails);
    }
  }

  saveTurbine() {
    console.log('process save turbine');
  }

  processPadding() {
    setTimeout(() => {
      const trbContentDOM = document.getElementsByClassName(
        'mat-trb-content'
      ) as HTMLCollectionOf<HTMLElement>;
      for (let i = 0; i < trbContentDOM.length; i++) {
        const child = <HTMLElement[]>(
          (<any>trbContentDOM[i].querySelectorAll('.mat-form-field-infix'))
        );
        const child2 = <HTMLElement[]>(
          (<any>(
            trbContentDOM[i].querySelectorAll(
              '.mat-form-field-appearance-legacy .mat-form-field-infix'
            )
          ))
        );
        for (let j = 0; j < child.length; j++) {
          child[j].style.border = '0';
          child[j].style.padding = '0';
        }
        for (let k = 0; k < child2.length; k++) {
          child2[k].style.border = '0';
          child2[k].style.padding = '0';
        }
      }

      this.updateCSS('trb-mat-card');
      this.updateCSS('eco-mat-card');
      this.updateCSS('proj-results-mat-card');
      this.updateCSS('park-comments-mat-card');
    }, 200);
  }

  updateCSS(matClass: string) {
    const trbCardsDOM = document.getElementsByClassName(
      matClass
    ) as HTMLCollectionOf<HTMLElement>;
    if (trbCardsDOM.length > 4) {
      for (let i = 0; i < trbCardsDOM.length; i++) {
        trbCardsDOM[i].classList.add('flex-cls');
      }
    } else {
      for (let j = 0; j < trbCardsDOM.length; j++) {
        trbCardsDOM[j].classList.remove('flex-cls');
      }
    }
  }

  updateBOP() {
    this.openUpdateBOP.emit({});
  }

  comparePark() {
    const isPrimarySize = this.turbineDetails.filter(
      turb => turb.comparePowerCurve === true
    ).length;
    if (isPrimarySize > 1) {
      this.buttonDisable = false;
    } else {
      this.buttonDisable = true;
    }
  }

  compareParkDiaRef() {
    const turbineDetails = this.turbineDetails.filter(
      turb => turb.comparePowerCurve === true
    );
    this.parkCompareList = [];
    turbineDetails.map((turbines, index) => {
      const powerCurveList = {
        powerCurve: turbines.selectedPCList[0].turbineName,
        tower: turbines.selectedPCList[0].hubHeight,
        totalMw: turbines.totalMw,
        quantity: turbines.selectedPCList[0].units,
        grossCapacityFactor: ' ',
        losses: turbines.lossFactor,
        netCapacityFactor: turbines.ncf,
        vavghh: turbines.vavghh
      };
      this.parkCompareList.push({ powerCurveList, turbines });
      if (index === turbineDetails.length - 1) {
        this.compareParksSubscribe = this.dataService
          .compareParks(this.parkCompareList)
          .subscribe(data => {
            if (data) {
              const dialogRef = this.dialog.open(CompareParkPCComponent, {
                data: { turbineInfo: data }
              });

              this.afterClosed2Subscribe = dialogRef
                .afterClosed()
                .subscribe(result => {});
            }
          });
      }
    });
  }

  ngOnDestroy() {
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.listOfCasesSubscribe) {
      this.listOfCasesSubscribe.unsubscribe();
    }
    if (this.combinedTrbSubscribe) {
      this.combinedTrbSubscribe.unsubscribe();
    }
    if (this.marketInfoDataSubscribe) {
      this.marketInfoDataSubscribe.unsubscribe();
    }
    if (this.goalSeekDataSubscribe) {
      this.goalSeekDataSubscribe.unsubscribe();
    }
    if (this.getManufacturers2Subscribe) {
      this.getManufacturers2Subscribe.unsubscribe();
    }
    if (this.sessionSaveInfoSubscribe) {
      this.sessionSaveInfoSubscribe.unsubscribe();
    }
    if (this.getTurbinesSubscribe) {
      this.getTurbinesSubscribe.unsubscribe();
    }
    if (this.getTurbinesListSubscribe) {
      this.getTurbinesListSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
    if (this.getTurbinesList2Subscribe) {
      this.getTurbinesList2Subscribe.unsubscribe();
    }
    if (this.getWindfarmIdSubscribe) {
      this.getWindfarmIdSubscribe.unsubscribe();
    }
    if (this.getWindfarmId2Subscribe) {
      this.getWindfarmId2Subscribe.unsubscribe();
    }
    if (this.trbSeqSubscribe) {
      this.trbSeqSubscribe.unsubscribe();
    }
    if (this.compareParksSubscribe) {
      this.compareParksSubscribe.unsubscribe();
    }
    if (this.afterClosed2Subscribe) {
      this.afterClosed2Subscribe.unsubscribe();
    }
    if (this.projEconomicsDataSubscribe) {
      this.projEconomicsDataSubscribe.unsubscribe();
    }
    if (this.windParkDataSubscribe) {
      this.windParkDataSubscribe.unsubscribe();
    }
  }
}
