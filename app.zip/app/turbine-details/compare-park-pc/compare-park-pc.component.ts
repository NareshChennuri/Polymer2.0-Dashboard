import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TurbineDetailsComponent } from '../turbine-details.component';
import { DataService } from 'src/app/shared/api/data.service';
import { GlobalsService } from 'src/app/shared/api/globals.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-compare-park-pc',
  templateUrl: './compare-park-pc.component.html',
  styleUrls: ['./compare-park-pc.component.css']
})
export class CompareParkPCComponent implements OnInit {

  dataSource:any;
  tabWidth:number = 562;
  variancePercent:any = {};

  constructor(public dialogRef: MatDialogRef<TurbineDetailsComponent>,
    private dataService: DataService,
    private globals: GlobalsService,
    private toaster: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      if(!(data.turbineInfo.turbinePowerCurve.length>2)){
      for (const key in data.turbineInfo) {
        if (data.turbineInfo.hasOwnProperty(key)) {
          if(key!=='turbinePowerCurve'){
          this.variancePercent[key] = data.turbineInfo[key][3];
          data.turbineInfo[key] = data.turbineInfo[key].filter((result,index) =>index!==3);
          }
        }
      }
    }
      this.dataSource = {...data};
      if(this.dataSource.turbineInfo.turbinePowerCurve.length>4){
        this.tabWidth = this.tabWidth + (this.dataSource.turbineInfo.turbinePowerCurve.length-4)*106;
      }
     }

  ngOnInit() {
  }

}
