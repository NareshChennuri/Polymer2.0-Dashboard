import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompareParkPCComponent } from './compare-park-pc.component';

describe('CompareParkPCComponent', () => {
  let component: CompareParkPCComponent;
  let fixture: ComponentFixture<CompareParkPCComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompareParkPCComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompareParkPCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
