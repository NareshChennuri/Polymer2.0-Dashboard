import { NgModule } from '@angular/core';
import {
  MatCheckboxModule,
  MatTabsModule,
  MatTableModule,
  MatPaginatorModule,
  MatSortModule,
  MatFormFieldModule,
  MatInputModule,
  MatSelectModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatMenuModule,
  MatIconModule,
  MatGridListModule,
  MatDialogModule,
  MatButtonModule,
  MatDividerModule,
  MatRadioModule,
  MatToolbarModule,
  MatCardModule,
  MatListModule,
  MatExpansionModule,
  MatAutocompleteModule,
  MatTreeModule,
  MatTooltipModule
} from '@angular/material';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

@NgModule({
  exports: [
    MatCheckboxModule,
    MatTabsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMenuModule,
    MatIconModule,
    MatGridListModule,
    MatDialogModule,
    MatButtonModule,
    MatDividerModule,
    MatRadioModule,
    MatToolbarModule,
    MatCardModule,
    MatListModule,
    NgxMatSelectSearchModule,
    MatExpansionModule,
    MatAutocompleteModule,
    MatTreeModule,
    MatTooltipModule
  ]
})
export class MatComponentsModule {}
