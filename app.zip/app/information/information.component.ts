import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { combineLatest, Subscription } from 'rxjs';
import { DataService } from '../shared/api/data.service';
import { GlobalsService } from '../shared/api/globals.service';

export interface InformationData {
  opportunityNumber: number;
  opportunityName: string;
  country: number;
  state: number;
  latitude: number;
  longitude: number;
  projectScope: string;
  mw: number;
  elevation: number;
  targetirr: number;
  ppa: number;
  cod: object;
  vavg: number;
  kfactor: number;
  airDensity: number;
  measuredHeight: number;
  shear: number;
  cti: number;
  averageWaterDepth: number;
  constructionStartDate: object;
}
@Component({
  selector: 'app-information',
  templateUrl: './information.component.html',
  styleUrls: ['./information.component.css']
})
export class InformationComponent implements OnInit, OnDestroy {
  private getDropDownValuesSubscribe: Subscription;
  private combinedSubscribe: Subscription;
  private callSearchSubscribe: Subscription;
  private sessionSaveInfoSubscribe: Subscription;
  private currentCountryNameSubscribe: Subscription;
  private cloneSessionEmitterSubscribe: Subscription;
  private getSessionDataSubscribe: Subscription;
  private getUserDetailsSubscribe: Subscription;
  private getLockSessionSubscribe: Subscription;
  private getStatesListSubscribe: Subscription;
  dataSource: any = [];
  InformationData: any = [];
  windselectId: number;
  countryListItems: any[] = [{ id: 0, countryName: 'Select' }];
  stateListItems: any[] = [{ stateId: 0, fullName: 'Select' }];
  projectScopeListItems: object = [];
  isCountryOffShore: boolean;
  defaultOption: Number = 0;

  opportunityNumber: FormControl = new FormControl(
    this.dataSource.opportunityNumber,
    [Validators.required]
  );
  country: FormControl = new FormControl(this.dataSource.country, [
    Validators.required
  ]);
  selectedCountry: any;
  selectedState: any;
  windparkDetails: any;
  currentSessionId: any;
  currentUser: any;
  sessionDetails: any;

  constructor(
    private dataService: DataService,
    private globals: GlobalsService
  ) {
    this.getDropDownValuesByKey('proj_scope');
  }

  getDropDownValuesByKey(key: string) {
    const postData = {
      key
    };
    this.getDropDownValuesSubscribe = this.dataService
      .getDropDownValues(postData)
      .subscribe(dropdownList => {
        const projScopeList = [];
        if (dropdownList.length) {
          for (const data of dropdownList) {
            projScopeList.push({ id: data.value, name: data.displayName });
          }
        }

        this.projectScopeListItems = projScopeList;
      });
  }

  ngOnInit() {
    // this.windselectId = +(document.location.hash.split('/')[2]);
    // this.windselectId = 1001113;

    const countriesList$ = this.dataService.getCountriesList();
    const sessionInfo$ = this.globals.currentSession;
    const countryInfo$ = this.globals.currentCountry;
    const stateInfo$ = this.globals.currentState;
    const userInfo$ = this.globals.currentUser;

    const combined = combineLatest(
      countriesList$,
      countryInfo$,
      stateInfo$,
      userInfo$
    );
    this.combinedSubscribe = combined.subscribe(
      ([countries, countryId, stateId, userInfo]) => {
        countries.sort((a, b) =>
          a.countryName !== b.countryName
            ? a.countryName < b.countryName
              ? -1
              : 1
            : 0
        );
        this.countryListItems = [
          { id: 0, countryName: 'Select' },
          ...countries
        ];
        this.selectedCountry = countryId;
        this.selectedState = stateId;
        this.currentUser = userInfo;
      }
    );

    let count = 0;
    sessionInfo$.subscribe(sessionId => {
      this.currentSessionId = sessionId;
      if (count === 0) {
        count++;
        this.getSessionDetails({ windselectId: sessionId });
      }
    });

    this.globals.changeCodDate(new Date());

    this.callSearchSubscribe = this.globals.callSearch.subscribe(() => {
      this.getSessionDetails({ windselectId: this.currentSessionId });
    });

    this.sessionSaveInfoSubscribe = this.globals.sessionSaveInfo.subscribe(
      sessionDetails => {
        this.sessionDetails = sessionDetails;
      }
    );

    this.currentCountryNameSubscribe = this.globals.currentCountryName.subscribe(
      currentCountryName => {
        if (currentCountryName && currentCountryName.split('-').length > 1) {
          this.isCountryOffShore = true;
        } else {
          this.isCountryOffShore = false;
          this.dataSource.averageWaterDepth = '';
        }
      }
    );

    this.cloneSessionEmitterSubscribe = this.globals.cloneSessionEmitter.subscribe(
      session => {
        this.getSessionDetails({ windselectId: session });
      }
    );
  }

  updateMarketData() {
    // tslint:disable-next-line:no-unused-expression
    this.dataSource && this.globals.changeMarketInfoData(this.dataSource);
  }

  getSessionDetails(sessionDtls) {
    this.getSessionDataSubscribe = this.dataService
      .getSessionData(sessionDtls)
      .subscribe(sessionInfo => {
        if (sessionInfo) {
          this.globals.updateSessionInfo(sessionInfo);
          if (
            sessionInfo.windselectMainInputs &&
            sessionInfo.windselectMainInputs.countryId
          ) {
            this.globals.changeCountry(
              sessionInfo.windselectMainInputs.countryId
            );
          }
          if (
            sessionInfo.windselectMainInputs &&
            sessionInfo.windselectMainInputs.stateId
          ) {
            this.globals.changeState(sessionInfo.windselectMainInputs.stateId);
            this.globals.updateOpportunityNoData(
              sessionInfo.windselectMainInputs.opportunityNo || ''
            );
            this.globals.updateOpportunityNameData(
              sessionInfo.windselectMainInputs.opportunityName || ''
            );
          }
          if (sessionInfo.windselectMainInputs) {
            const sessionData = sessionInfo.windselectMainInputs
              ? sessionInfo.windselectMainInputs
              : [];
            this.dataSource = sessionData;
            this.dataSource.cod = this.globals.returnFormattedDate(
              sessionData.cod
            );
            this.dataSource.constructionStartDate = this.globals.returnFormattedDate(
              this.dataSource.constructionStartDate
            )
              ? this.globals.returnFormattedDate(
                  this.dataSource.constructionStartDate
                )
              : new Date(
                  new Date(this.dataSource.cod).getTime() -
                    180 * 24 * 60 * 60 * 1000
                ).toISOString();
            this.globals.changeConstructionStartDate(
              this.globals.returnFormattedDate(
                this.dataSource.constructionStartDate
              )
            );
            this.globals.changeCodDate(
              this.globals.returnFormattedDate(sessionData.cod)
            );
          }

          // this.opportunityNumber = sessionData.opportunityNumber;
          // this.InformationData = sessionData;
          this.dataSource.projectScopeListItems = this.projectScopeListItems;
          this.updateMarketData();
        }

        if (
          this.sessionDetails &&
          this.sessionDetails.windselectMainInputs &&
          this.currentUser
        ) {
          if (
            this.sessionDetails.windselectMainInputs.lockstatus ===
              'UnLocked' ||
            this.sessionDetails.windselectMainInputs.lockstatus == null
          ) {
            const userDtls = {
              userId: this.sessionDetails.windselectMainInputs.createdBy
            };
            this.getUserDetailsSubscribe = this.dataService
              .getUserDetails(userDtls)
              .subscribe(userDetails => {
                if (
                  this.currentUser.roleId === 1 ||
                  (userDetails.user && userDetails.user.roleId !== 1)
                ) {
                  const lockSession = {
                    sessionId: this.sessionDetails.windselectMainInputs
                      .windselectId,
                    sso: this.currentUser.userId,
                    lockStatus: false
                  };
                  this.getLockSessionSubscribe = this.dataService
                    .getLockSession(lockSession)
                    .subscribe(lock => {
                      this.globals.updateLockSession(lock);
                      this.globals.onLockStatus();
                    });
                }
              });
          }
        }
      });
  }

  countryChange($event) {
    const countryId = parseInt($event.value, 10);
    if (countryId > 0) {
      this.globals.changeCountry(countryId);
      this.getStatesListSubscribe = this.dataService
        .getStatesList(countryId)
        .subscribe(statesList => {
          statesList.sort((a, b) =>
            a.fullName !== b.fullName ? (a.fullName < b.fullName ? -1 : 1) : 0
          );
          this.stateListItems = [
            { stateId: 0, fullName: 'Select' },
            ...statesList
          ];
        });
    }
  }

  stateChange($event) {
    const stateId = parseInt($event.value, 10);
    if (stateId > 0) {
      this.globals.changeState(stateId);
    }
  }

  codDateChange($event) {
    if ($event) {
      this.globals.changeCodDate($event);
      this.dataSource.constructionStartDate = new Date(
        new Date(this.dataSource.cod).getTime() - 180 * 24 * 60 * 60 * 1000
      ).toISOString();
      this.globals.changeConstructionStartDate(
        this.dataSource.constructionStartDate
      );
      this.updateMarketData();
    }
  }

  getErrorMessage(field: string) {
    let errorMessage = '';
    switch (field) {
      case 'opportunityNumber': {
        errorMessage = this.opportunityNumber.hasError('required')
          ? 'required *'
          : '';
        break;
      }
      case 'country': {
        errorMessage = this.country.hasError('required') ? 'required *' : '';
        break;
      }
    }
    return errorMessage;
  }
  onConstructionDateChange(event) {
    if (event) {
      this.globals.changeConstructionStartDate(
        new Date(event._d).toISOString()
      );
    }
  }
  ngOnDestroy() {
    if (this.getDropDownValuesSubscribe) {
      this.getDropDownValuesSubscribe.unsubscribe();
    }
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.callSearchSubscribe) {
      this.callSearchSubscribe.unsubscribe();
    }
    if (this.sessionSaveInfoSubscribe) {
      this.sessionSaveInfoSubscribe.unsubscribe();
    }
    if (this.currentCountryNameSubscribe) {
      this.currentCountryNameSubscribe.unsubscribe();
    }
    if (this.cloneSessionEmitterSubscribe) {
      this.cloneSessionEmitterSubscribe.unsubscribe();
    }
    if (this.getSessionDataSubscribe) {
      this.getSessionDataSubscribe.unsubscribe();
    }
    if (this.getUserDetailsSubscribe) {
      this.getUserDetailsSubscribe.unsubscribe();
    }
    if (this.getLockSessionSubscribe) {
      this.getLockSessionSubscribe.unsubscribe();
    }
    if (this.getStatesListSubscribe) {
      this.getStatesListSubscribe.unsubscribe();
    }
  }
}
