import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from './../../../environments/environment';
import {
  cacheAPI,
  roleId,
  basicAPI,
  userAPI,
  catalogURI,
  turbineDetails,
  finalcialModels,
  calcAEPAPI,
  projEcoAPI,
  bopServiceAPI,
  headerAccessToken
} from '../app-constants';
// import { turbinesWithHub } from './service-mock';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: headerAccessToken
    })
  };
  private finalcialModels = finalcialModels;
  private turbineDetails = turbineDetails;

  constructor(private http: HttpClient) {
    if (environment.devEnv === 'dev') {
      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: sessionStorage.getItem('headerAccessToken')
        })
      };
    }
  }

  getCountriesList(): Observable<any> {
    const endPoint = `${cacheAPI}/getCountries`;
    return this.http.post<any>(endPoint, {}, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getCountriesList'))
    );
  }

  getStatesList(countryId): Observable<any> {
    const endPoint = `${cacheAPI}/getStates?countryId=${countryId}`;
    return this.http.post<any>(endPoint, {}, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getCountriesList'))
    );
  }

  getTurbines(): Observable<any> {
    // return of(this.turbineDetails);
    return of([]);
  }

  getManufacturers(): Observable<any> {
    const endPoint = `${cacheAPI}/getManufacturers?roleId=${roleId}`;
    return this.http.post<any>(endPoint, {}, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getManufacturers'))
    );
  }

  getTurbineMasterDetails(id: Number): Observable<any> {
    const endPoint = `${catalogURI}/findByTurbinePowerMasterDetailsByTurbineId`;
    // return of(turbinesWithHub);
    return this.http.post<any>(endPoint, { id }, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getManufacturers'))
    );
  }

  getHubHeightsList(turbineId: Number): Observable<any> {
    const endPoint = `${catalogURI}/findHubHeightsByTurbineId`;
    // return of(turbinesWithHub);
    return this.http.post<any>(endPoint, { turbineId }, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getManufacturers'))
    );
  }

  getTurbinesList(manifatureId: Number, roleInfo: any): Observable<any> {
    const endPoint = `${cacheAPI}/getTurbines?manufacturerId=${manifatureId}&roleId=${roleInfo}`;
    // return of(turbinesWithHub);
    return this.http.post<any>(endPoint, {}, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getTurbinesList'))
    );
  }

  getTurbinesPCList(manifatureId: Number, roleInfo: any): Observable<any> {
    const endPoint = `${catalogURI}/getTurbinesList?manufacturerId=${manifatureId}&roleId=${roleInfo}`;
    // return of(turbinesWithHub);
    return this.http.post<any>(endPoint, {}, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getTurbinesList'))
    );
  }

  getTurbinesListWithHub(manifatureId: Number, roleInfo: any): Observable<any> {
    const endPoint = `${cacheAPI}/getTurbinesWithHub?manufacturerId=${manifatureId}&roleId=${roleInfo}`;
    // return of(turbinesWithHub);
    return this.http.post<any>(endPoint, {}, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getTurbinesListWithHub'))
    );
  }

  getWindfarmId(): Observable<any> {
    const endPoint = `${catalogURI}/getWindfarmId`;
    return this.http.get<any>(endPoint, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getWindfarmId'))
    );
  }

  getTurbineSequence(): Observable<any> {
    const endPoint = `${basicAPI}/getTurbineInputsSequence`;
    return this.http.get<any>(endPoint, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getWindfarmId'))
    );
  }

  getPValues(): Observable<any> {
    const endPoint = `${cacheAPI}/getPvalues`;
    return this.http.post<any>(endPoint, {}, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getPValues'))
    );
  }

  saveSession(saveData: any): Observable<any> {
    const endPoint = `${basicAPI}/save`;
    return this.http.put<any>(endPoint, saveData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('basic save'))
    );
  }
  calculateAEP(calculateAEPData: any): Observable<any> {
    const endPoint = `${calcAEPAPI}/grossAEP`;
    return this.http
      .post<any>(endPoint, calculateAEPData, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(this.handleError<any>('Calculate AEP'))
      );
  }
  calculateNetAEP(calculateNetAEPData: any): Observable<any> {
    const endPoint = `${calcAEPAPI}/netAEP`;
    return this.http
      .post<any>(endPoint, calculateNetAEPData, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(this.handleError<any>('Calculate Net AEP'))
      );
  }
  calculateNcf(calculateNcfData: any): Observable<any> {
    const endPoint = `${calcAEPAPI}/ncf`;
    return this.http
      .post<any>(endPoint, calculateNcfData, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(this.handleError<any>('Calculate NCF'))
      );
  }
  calculateVavg(calculateVavgData: any): Observable<any> {
    const endPoint = `${calcAEPAPI}/vavgHH`;
    return this.http
      .post<any>(endPoint, calculateVavgData, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(this.handleError<any>('Calculate Vavg'))
      );
  }
  cloneSession(cloneSessionData: any): Observable<any> {
    const endPoint = `${basicAPI}/clone`;
    return this.http
      .post<any>(endPoint, cloneSessionData, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(this.handleError<any>('Clone Session'))
      );
  }
  getUserId() {
    const endPoint = `/userinfodetails`;
    return this.http.get<any>(endPoint, this.httpOptions).pipe(
      tap(result => {
        return result;
      }),
      catchError(this.handleError<any>('getNewSessionId'))
    );
  }

  getUserDetails(userId): Observable<any> {
    // const endPoint = `/ws/findUserDetailsByUserId`;
    const endPoint = `${userAPI}/findUserDetailsByUserId`;
    return this.http.post<any>(endPoint, userId, this.httpOptions).pipe(
      tap(result => {
        return result;
      }),
      catchError(this.handleError<any>('getCountriesList'))
    );
  }

  getNewSessionId(): Observable<any> {
    const endPoint = `${basicAPI}/getSessionSequence`;
    return this.http.get<any>(endPoint, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getNewSessionId'))
    );
  }

  getRecentSessions(userData: any): Observable<any> {
    const endPoint = `${userAPI}/dashboardbyrecent`;
    return this.http.post<any>(endPoint, userData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('recent sessions'))
    );
  }

  getMySessions(userData: any): Observable<any> {
    const endPoint = `${userAPI}/dashboardbyuser`;
    return this.http.post<any>(endPoint, userData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('my sessions'))
    );
  }

  getRevenueStreamsList(sessionData: any): Observable<any> {
    const endPoint = `${catalogURI}/findAllRevenueStreamsBySessionId`;
    return this.http.post<any>(endPoint, sessionData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('revenue streams'))
    );
  }

  getFinanceList(sessionData: any): Observable<any> {
    const endPoint = `${catalogURI}/findAllFinanceDetailsBySessionId`;
    return this.http.post<any>(endPoint, sessionData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('revenue streams'))
    );
  }

  getDropDownValues(key: any): Observable<any> {
    const endPoint = `${cacheAPI}/findAllDropDownsByKey`;
    return this.http.post<any>(endPoint, key, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('findAllDropDownsByKey'))
    );
  }

  saveRevenueStream(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/saveRevenueStream`;
    return this.http.put<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('Revenue Strem Save Error'))
    );
  }

  deleteRevenueStream(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/deleteRevenueStreamsById`;
    return this.http.post<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('Revenue Strem Delete Error'))
    );
  }

  saveFinanceRecord(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/saveFinanceDetails`;
    return this.http.put<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => {
        return 'success';
      }),
      catchError(this.handleError<any>('Finance Record Save Error'))
    );
  }

  deleteFinanceRecord(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/deleteFinanceDetailsByFinanceId`;
    return this.http.post<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => {
        return 'success';
      }),
      catchError(this.handleError<any>('Finance Record Delete Error'))
    );
  }

  getTaxRecordList(sessionData: any): Observable<any> {
    const endPoint = `${catalogURI}/findAllTaxDeprDetailsBySessionId`;
    return this.http.post<any>(endPoint, sessionData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('Tax List Error'))
    );
  }

  saveTaxDepreciation(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/saveTaxDeprDetails`;
    return this.http.put<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => {
        return 'success';
      }),
      catchError(this.handleError<any>('Tax Save Error'))
    );
  }

  deleteTaxDepreciation(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/deleteTaxDetailsByTaxId`;
    return this.http.post<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => {
        return 'success';
      }),
      catchError(this.handleError<any>('Tax Delete Error'))
    );
  }

  getProjectOperatingCostList(sessionData: any): Observable<any> {
    const endPoint = `${catalogURI}/findAllProjectOperatingCostsBySessionId`;
    return this.http.post<any>(endPoint, sessionData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('operation costs'))
    );
  }

  saveProjectOperatingCostRecord(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/saveProjectOperatingCost`;
    return this.http.put<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => {
        return 'success';
      }),
      catchError(
        this.handleError<any>('Project Operation cost Record Save Error')
      )
    );
  }

  deleteProjectOperatingCostRecord(inputData: any): Observable<any> {
    const endPoint = `${catalogURI}/deleteProjectOperatingCostByProjectoPeratingcostId`;
    return this.http.post<any>(endPoint, inputData, this.httpOptions).pipe(
      tap(result => {
        return 'success';
      }),
      catchError(
        this.handleError<any>('Project Operation cost Record Delete Error')
      )
    );
  }

  /* Case List related API's */
  getCasesList(requestData: any): Observable<[]> {
    const endPoint = `${catalogURI}/fetchCases`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('case list'))
    );
  }

  saveCases(requestData: any): Observable<[]> {
    const endPoint = `${catalogURI}/saveCases`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('case list'))
    );
  }

  cloneMarketDataCase(requestData: any): Observable<[]> {
    const endPoint = `${catalogURI}/cloneMarketDataCase`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('case list'))
    );
  }

  loadCase(requestData: any): Observable<[]> {
    const endPoint = `${catalogURI}/loadCase`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('case list'))
    );
  }

  loadAllCase(requestData: any): Observable<[]> {
    const endPoint = `${catalogURI}/loadAllCase`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('case list'))
    );
  }

  deleteCase(requestData: any): Observable<[]> {
    const endPoint = `${catalogURI}/deleteCase`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('case list'))
    );
  }

  getSessionData(windselectId: any): Observable<any> {
    const endPoint = `${basicAPI}/search`;
    return this.http.post<any>(endPoint, windselectId, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('search session returned with error'))
    );
  }

  getSessionSeq(): Observable<any> {
    const endPoint = `${basicAPI}/getSessionSequence`;
    return this.http.post<any>(endPoint, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('session sequence returned with error'))
    );
  }

  getConfigSequence(): Observable<any> {
    const endPoint = `${basicAPI}/getConfigIdSequence`;
    return this.http.get<any>(endPoint, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getProjectEconomicsEditConfigId'))
    );
  }

  // getParentURL(): Observable<any> {
  //   const endPoint = `/getParentUrl`;
  //   return this.http.get<any>(endPoint, this.httpOptions).pipe(
  //     tap(result => result),
  //     catchError(this.handleError<any>('getParentUrl'))
  //   );
  // }

  getEconomicConfigurations(windselectId: any): Observable<any> {
    const endPoint = `${basicAPI}/findEconomicConfigurations`;
    return this.http.post<any>(endPoint, windselectId, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>('getEconomicConfigurations returned with error')
      )
    );
  }

  saveEconomicConfigurations(saveData: any): Observable<any> {
    const endPoint = `${basicAPI}/saveEconomicConfigurations`;
    return this.http.put<any>(endPoint, saveData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('save Economic Configuration'))
    );
  }

  deleteProjEconomincConfiguration(requestData: any): Observable<[]> {
    const endPoint = `${basicAPI}/deleteEconomicConfigurationByConfigId`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>(
          'deleteProjEconomincConfiguration returned with error'
        )
      )
    );
  }

  getTotalWTGPricePerMW(windselectId: any): Observable<any> {
    const endPoint = `${projEcoAPI}/getTotalWtgPricePerMw`;
    return this.http.post<any>(endPoint, windselectId, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>('getTotalWTGPricePerMW returned with error')
      )
    );
  }

  getTotalWTGPricePerMWH(windselectId: any): Observable<any> {
    const endPoint = `${projEcoAPI}/getTotalWtgPricePerMwh`;
    return this.http.post<any>(endPoint, windselectId, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>('getTotalWTGPricePerMW returned with error')
      )
    );
  }

  getAllCosts(requestData: any): Observable<any> {
    const endPoint = `${projEcoAPI}/getAllCosts`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getAllCosts returned with error'))
    );
  }

  getDynamicCosts(requestData: any): Observable<any> {
    const endPoint = `${projEcoAPI}/getDynamicCapitalCost`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>('Dynamic Capital Cost returned with error')
      )
    );
  }

  getConsolidatedProforma(requestData: any): Observable<any> {
    const endPoint = `${basicAPI}/getConsolidatedFinancials`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>('getConsolidatedProforma returned with error')
      )
    );
  }

  downloadProformaReports(requestData: any): Observable<any> {
    const endPoint = `${basicAPI}/proforma`;
    let accessToken = headerAccessToken;
    if (environment.devEnv === 'dev') {
      accessToken = sessionStorage.getItem('headerAccessToken');
    }
    return new Observable(obs => {
      const oReq = new XMLHttpRequest();
      oReq.open('POST', endPoint, true);
      oReq.setRequestHeader('Content-Type', 'application/json');
      oReq.setRequestHeader('Authorization', accessToken);
      oReq.responseType = 'arraybuffer';

      oReq.onload = function(oEvent) {
        const arrayBuffer = oReq.response;
        const byteArray = new Uint8Array(arrayBuffer);
        obs.next(byteArray);
      };

      const body = JSON.stringify(requestData);
      oReq.send(body);
    });
  }

  calculateProjResults(requestData: any): Observable<any> {
    const endPoint = `${projEcoAPI}/getProjectResults`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('Proj Results returned with error'))
    );
  }

  calculateAll(requestData: any): Observable<any> {
    const endPoint = `${projEcoAPI}/calculateall`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('Proj Results returned with error'))
    );
  }

  fetchDefaultCountryCases(requestData): Observable<any> {
    const endPoint = `${catalogURI}/fetchCases`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('Fetch Cases For Country error'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }

  getLockSession(lockSession): Observable<any> {
    const endPoint = `${basicAPI}/lockSession`;
    return this.http.post<any>(endPoint, lockSession, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('Lock session returned with error'))
    );
  }

  getMaxRate(requestData: any): Observable<any> {
    const endPoint = `${projEcoAPI}/getMaxPower`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>('get max power for turbine returned with error')
      )
    );
  }

  clonePublicCase(requestData: any): Observable<any> {
    const endPoint = `${catalogURI}/clonePublicCase`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('clonePublicCase returned with error'))
    );
  }

  deletePCInfo(requestData: any): Observable<any> {
    const endPoint = `${basicAPI}/turbineAndConfigurationAutoSave`;
    return this.http.post<any>(endPoint, requestData, this.httpOptions).pipe(
      tap(result => result),
      catchError(
        this.handleError<any>(
          'Turbine Configuration auto save returned with error'
        )
      )
    );
  }

  callErrorMsgAPI(calculateAEPData: any): Observable<any> {
    const endPoint = `${basicAPI}/errorMessages`;
    return this.http
      .post<any>(endPoint, calculateAEPData, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(
          this.handleError<any>('/errorMessages API returned with error')
        )
      );
  }

  compareParks(turbines): Observable<any> {
    const endPoint = `${basicAPI}/compareParks`;
    return this.http
      .post<any>(endPoint, turbines, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(
          this.handleError<any>('/compareParks API returned with error')
        )
      );
  }

  getGoalSeek(req){
    const endPoint = `${projEcoAPI}/goalSeek`;
    return this.http
      .post<any>(endPoint, req, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(
          this.handleError<any>('/GoalSeek API returned with error')
           )
      );
  }

  getPowerCurveDetails(turbineId: any): Observable<any> {
    const endPoint = `${catalogURI}/searchPowerCurve`;
    return this.http
      .post<any>(endPoint, turbineId, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(
          this.handleError<any>('/Get Power Curve Details  API returned with error')
        )
      );
  }
  savePowerCurveDetails(requestBody: any): Observable<any> {
    const endPoint = `${catalogURI}/savePowerCurve`;
    return this.http
      .put<any>(endPoint, requestBody, this.httpOptions)
      .pipe(
        tap(result => result),
        catchError(
          this.handleError<any>('/Save Power Curve  API returned with error')
        )
      );
  }

  uploadPCFile(requestBody: any): Observable<any> {
    const endPoint = `${catalogURI}/uploadPCData`;
    const  httpXLSXOptions = {
      headers: new HttpHeaders({
        Authorization: sessionStorage.getItem('headerAccessToken')
      })
    };
    return this.http
      .post<any>(endPoint, requestBody, httpXLSXOptions)
      .pipe(
        tap(result => result),
        catchError(
          this.handleError<any>('/Upload XLS returned with error')
        )
      );
  }

  pushToSalesForce(sfdcReq: any): Observable<any> {
    const endPoint = `${basicAPI}/pushToOppty`;
    return this.http.post<any>(endPoint, sfdcReq, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('SFDC api Returned with error'))
    );
  }

  findOmDuringEsc(req: any): Observable<any> {
    const endPoint = `${basicAPI}/findOmDuring`;
    return this.http.post<any>(endPoint, req, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('O&M During escalation returned with error'))
    );
  }

  getBopConfigurationElements(countryId:any): Observable<any> {
    const endPoint = `${bopServiceAPI}/getBopConfigueElementsforTurbineLevel`;
    return this.http.post<any>(endPoint,countryId,this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getBopConfigueElementsforTurbineLevel API returned with error')));
  }

  getBopConfigurationDefaluts(request:any): Observable<any> {
    const endPoint = `${bopServiceAPI}/getBopDefaults`;
    return this.http.post<any>(endPoint,request,this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getBopConfigueDefaultsforTurbineLevel API returned with error')));
  }

  getBopParkElements(countryId:any): Observable<any> {
    const endPoint = `${bopServiceAPI}/getBopConfigueElementsforParkLevel`;
    return this.http.post<any>(endPoint,countryId,this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('getBopConfigueElementsforParkLevel API returned with error')));
  }
  cloneEconomicsForPark(request: any): Observable<any> {
    const endPoint = `${basicAPI}/cloneEconomicsWithPark`;
    return this.http.post<any>(endPoint, request, this.httpOptions).pipe(
      tap(result => result),
      catchError(this.handleError<any>('clone economics error'))
    );
  }
}
