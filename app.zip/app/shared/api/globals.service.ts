import { Injectable, Output, EventEmitter, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class GlobalsService implements OnDestroy {
  private currentCountrySubscribe: Subscription;
  private getCountriesListSubscribe: Subscription;

  @Output() callSearch = new EventEmitter<{}>();
  @Output() parkMaxArea = new EventEmitter<{}>();
  @Output() invokeLockStatus = new EventEmitter();
  @Output() parkComments = new EventEmitter();
  @Output() projectResults = new EventEmitter();
  @Output() cloneSessionEmitter = new EventEmitter();
  @Output() parkTurbineSelectEmitter = new EventEmitter();
  @Output() countryChangeEmitter = new EventEmitter();

  selectedCountry = '';
  private countrySource = new BehaviorSubject('');
  public currentCountry = this.countrySource.asObservable();

  private countryNameSource = new BehaviorSubject('');
  public currentCountryName = this.countryNameSource.asObservable();

  private stateSource = new BehaviorSubject('');
  public currentState = this.stateSource.asObservable();

  private codSource = new BehaviorSubject('');
  public codDate = this.codSource.asObservable();

  private constructionStartDateSource = new BehaviorSubject('');
  public constructionStartDateGlobal = this.constructionStartDateSource.asObservable();

  private bopSource = new BehaviorSubject('');
  public bopValue = this.bopSource.asObservable();

  private sessionSource = new BehaviorSubject('');
  public currentSession = this.sessionSource.asObservable();

  private userDtlsSource: BehaviorSubject<any> = new BehaviorSubject<any>({});
  public currentUser = this.userDtlsSource.asObservable();

  private parkTitleSource = new BehaviorSubject('');
  public parkTitle = this.parkTitleSource.asObservable();

  private selectedCaseIdSource = new BehaviorSubject('');
  public selectedCaseId = this.selectedCaseIdSource.asObservable();

  private selectedCaseInfoSource = new BehaviorSubject('');
  public selectedCaseInfo = this.selectedCaseInfoSource.asObservable();

  private windParkDataSource = new BehaviorSubject<any>({});
  public windParkData = this.windParkDataSource.asObservable();

  private marketInfoDataSource = new BehaviorSubject<any>({});
  public marketInfoData = this.marketInfoDataSource.asObservable();

  private casesListSource = new BehaviorSubject<any>([]);
  public listOfCases = this.casesListSource.asObservable();

  private loadedCasesDataSource = new BehaviorSubject<any>({});
  public loadedCaseData = this.loadedCasesDataSource.asObservable();

  private projEconomicsSource = new BehaviorSubject<any>([]);
  public projEconomicsData = this.projEconomicsSource.asObservable();

  private projResultsSource = new BehaviorSubject<any>([]);
  public projResultsData = this.projResultsSource.asObservable();

  private sessionSaveSource = new BehaviorSubject<any>({});
  public sessionSaveInfo = this.sessionSaveSource.asObservable();

  private opportunityNoSource = new BehaviorSubject('');
  public opportunityNo = this.opportunityNoSource.asObservable();

  private opportunityNameSource = new BehaviorSubject('');
  public opportunityName = this.opportunityNameSource.asObservable();

  private proformaReportsSource = new BehaviorSubject([]);
  public allProformaReports = this.proformaReportsSource.asObservable();

  private lockSession = new BehaviorSubject([]);
  public lockStatus = this.lockSession.asObservable();

  private goalSeekDataSubject = new BehaviorSubject([]);
  public goalSeekData = this.goalSeekDataSubject.asObservable();

  private goalSeekDataLabel = new BehaviorSubject([]);
  public goalSeekLabel = this.goalSeekDataLabel.asObservable();

  private bopParkInfoDataSource = new BehaviorSubject([]);
  public bopParkInfoData = this.bopParkInfoDataSource.asObservable();

  private bopTurbineDefaultDataSource = new BehaviorSubject([]);
  public bopTurbineDefaultData = this.bopTurbineDefaultDataSource.asObservable();

  constructor(private _service: DataService) {}
  changeCountry(country: any) {
    this.countrySource.next(country);
    this.currentCountrySubscribe = this.currentCountry.subscribe(countryId => {
      this.selectedCountry = countryId;
    });
    this.getCountriesListSubscribe = this._service
      .getCountriesList()
      .subscribe(countries => {
        countries.sort((a, b) =>
          a.countryName !== b.countryName
            ? a.countryName < b.countryName
              ? -1
              : 1
            : 0
        );
        const countryListItems = [
          { id: 0, countryName: 'Select' },
          ...countries
        ];
        const countryName = countryListItems.find(
          countryObj => countryObj.id === (this.selectedCountry || 0)
        ).countryName;
        this.countryNameSource.next(countryName);
      });
  }
  changeState(state: any) {
    this.stateSource.next(state);
  }
  changeCodDate(date: any) {
    this.codSource.next(date);
  }
  changeConstructionStartDate(date: any) {
    this.constructionStartDateSource.next(date);
  }
  changeBopValue(value: any) {
    this.bopSource.next(value);
  }
  changeSesssion(sessionInfo: any) {
    this.sessionSource.next(sessionInfo);
  }
  changeUser(userInfo: any) {
    this.userDtlsSource.next(userInfo);
  }
  changeparkTitle(title: any) {
    this.parkTitleSource.next(title);
  }
  changeSelectedCaseId(caseInfo: any) {
    this.selectedCaseIdSource.next(caseInfo);
  }
  changeSelectedCaseInfo(caseInfo: any) {
    this.selectedCaseInfoSource.next(caseInfo);
  }
  changeWindParkData(wpData: any) {
    this.windParkDataSource.next(wpData);
  }
  changeMarketInfoData(mkData: any) {
    this.marketInfoDataSource.next(mkData);
  }
  changeCasesList(cases: any) {
    if (cases.length) {
      // cases = this.returnSortedCasesList(cases);
    }
    this.casesListSource.next(cases);
  }
  changeProjEconomics(peData: any) {
    this.projEconomicsSource.next(peData);
  }
  changeProjResults(prData: any) {
    this.projResultsSource.next(prData);
  }
  updateSessionInfo(sessData: any) {
    this.sessionSaveSource.next(sessData);
  }
  updateLoadedCaseData(caseData: any) {
    this.loadedCasesDataSource.next(caseData);
  }
  updateOpportunityNoData(oppNo: any) {
    this.opportunityNoSource.next(oppNo);
  }
  updateOpportunityNameData(oppName: any) {
    this.opportunityNameSource.next(oppName);
  }
  updateProformaReportsData(reports: any) {
    this.proformaReportsSource.next(reports);
  }
  updateBopParkInfoDetails(data: any) {
    this.bopParkInfoDataSource.next(data);
  }
  updateLockSession(reports: any) {
    this.lockSession.next(reports);
  }

  updateGoalSeekDetails(response: any[]) {
    this.goalSeekDataSubject.next(response);
  }

  updateGoalSeekLable(request: any) {
    this.goalSeekDataLabel.next(request);
  }

  onLockStatus() {
    this.invokeLockStatus.emit();
  }

  updateParkComment(trb) {
    this.parkComments.emit(trb);
  }
  updateParkMaxArea(trb) {
    console.log('bb', trb);
    this.parkMaxArea.emit(trb);
  }

  updateProjectResults(trb) {
    this.projectResults.emit(trb);
  }

  onCountryChange() {
    this.countryChangeEmitter.emit();
  }

  UpdateBopTurbineDefaultData(res) {
    this.bopTurbineDefaultDataSource.next(res);
  }

  returnFormattedDate(dateObj) {
    let codDate = '';
    if (dateObj) {
      codDate =
        new Date(dateObj).getUTCFullYear() +
        '-' +
        ('0' + (new Date(dateObj).getUTCMonth() + 1)).slice(-2) +
        '-' +
        ('0' + new Date(dateObj).getUTCDate()).slice(-2) +
        ' 0:00:00 PM GMT';
    } else {
      codDate =
        new Date().getUTCFullYear() +
        '-' +
        ('0' + (new Date().getUTCMonth() + 1)).slice(-2) +
        '-' +
        ('0' + new Date().getUTCDate()).slice(-2) +
        ' 0:00:00 PM GMT';
    }
    return new Date(codDate).toISOString();
  }

  removeTimeZone(dateObj) {
    let codDate = '';
    if (dateObj) {
      codDate =
        new Date(dateObj).getFullYear() +
        '-' +
        ('0' + (new Date(dateObj).getMonth() + 1)).slice(-2) +
        '-' +
        ('0' + new Date(dateObj).getDate()).slice(-2) +
        'T00:00:00.000Z';
    } else {
      codDate =
        new Date().getFullYear() +
        '-' +
        ('0' + (new Date().getMonth() + 1)).slice(-2) +
        '-' +
        ('0' + new Date().getDate()).slice(-2) +
        'T00:00:00.000Z';
    }
    return codDate;
  }

  callSearchAPI() {
    this.callSearch.emit();
  }

  cloneSessionEmit(session) {
    this.cloneSessionEmitter.emit(session);
  }

  parkTurbineSelectEmit() {
    this.parkTurbineSelectEmitter.emit();
  }

  returnSortedCasesList(sessionCases) {
    if (sessionCases.length) {
      sessionCases.sort((a, b) =>
        a.name !== b.name ? (a.name < b.name ? -1 : 1) : 0
      );
      return sessionCases;
    }
  }

  ngOnDestroy() {
    if (this.currentCountrySubscribe) {
      this.currentCountrySubscribe.unsubscribe();
    }
    if (this.getCountriesListSubscribe) {
      this.getCountriesListSubscribe.unsubscribe();
    }
  }
}
