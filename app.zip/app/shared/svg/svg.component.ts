export const svgIcons = {
logo : `
<svg viewBox="0 0 65 65" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;">
<g class="style-scope iron-icon">
    <circle class="cls-1 style-scope iron-icon" cx="32.5" cy="32.5" r="32" ></circle>
    <path class="cls-2 style-scope iron-icon" d="M35.77,12.79A20,20,0,0,1,51.44,38.9M17.5,45.7A20,20,0,0,0,48,
            45.19M28.57,12.89A20,20,0,0,0,13.79,39.53"></path>
    <path class="cls-3 style-scope iron-icon" d="M28.47,36.93l-4.12,2.49L9.83,47.82a.72.72,0,0,1-1-.26h0a.73.73,0,0,
            1,.2-.94L19.94,37.2,23.45,37,27,34.89A6,6,0,0,0,28.47,36.93Zm2.21-10.14a5.74,5.74,0,0,1,
            1.82-.29c.23,0,.46,0,.68,0V22.43l1.54-3.15L32,5.14a.72.72,0,0,0-.71-.64h0a.71.71,0,0,
            0-.71.71V22ZM57.1,44.47,42.57,36.09l-4.21-2.31a5.92,5.92,0,0,1-1,2.29l3.57,2,2,2.91,13.6,
            4.7a.7.7,0,0,0,.91-.29h0A.71.71,0,0,0,57.1,44.47Zm-20.6-12a4,4,0,1,1-4-4A4,4,0,0,1,36.5,
            32.5Z"></path>
    <circle class="cls-4 style-scope iron-icon" cx="15.92" cy="21.32" r="4"></circle>
</g></svg>`,
appsIcons: {
  rects:`  <svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;"><g class="style-scope iron-icon">
              <rect class="cls-32 style-scope iron-icon" x="15" y="6" width="7" height="7"></rect>
              <rect class="cls-31 style-scope iron-icon" x="6" y="6" width="7" height="7"></rect>
              <rect class="cls-33 style-scope iron-icon" x="6" y="15" width="7" height="7"></rect>
              <rect class="cls-34 style-scope iron-icon" x="15" y="15" width="7" height="7"></rect>
          </g></svg>`,
},
appOptions: {
  question:`<svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;"><g class="style-scope iron-icon">
    <path d="M14,6a8,8,0,1,0,8,8A8,8,0,0,0,14,6Zm0,15.5A7.5,7.5,0,1,1,21.5,14,7.5,
    7.5,0,0,1,14,21.5Zm-.58-5.81c-.63,0-.3-1.52-.14-1.83.41-.78,1.31-1.1,1.8-1.8a1.35,1.35,0,0,
    0-.27-1.93,2.36,2.36,0,0,0-2.27.14c-.3.17-.5.49-.8.25a.53.53,0,0,1-.21-.59c.29-.65,
    1.6-.9,2.21-.93a2.78,2.78,0,0,1,2.3.81,2.2,2.2,0,0,1,.3,2.17c-.37.89-1.23,1.28-1.87,1.93A2.37,2.37,
    0,0,0,13.83,15C13.77,15.3,13.81,15.75,13.42,15.69ZM14.54,18a1,1,0,0,1-1.93,0A1,1,0,0,1,14.54,18Z" class="style-scope iron-icon"></path>
  </g></svg>`,
  info:`<svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;"><g class="style-scope iron-icon">
    <path d="M20,6H8A2,2,0,0,0,6,8v8a2,2,0,0,0,2,2v4l4-4h8a2,2,0,0,0,2-2V8A2,2,0,0,0,20,6ZM13.94,
            8a1,1,0,1,1-1,1A1,1,0,0,1,13.94,8ZM16,16H12V15h1.58V12H12.44V11h2.64v4H16Z" class="style-scope iron-icon"></path>
    </g></svg>`,
  credits: `<svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;"><g class="style-scope iron-icon">
    <path d="M22,14a8,8,0,1,0-2.71,6l2,2,.71-.71-2-2A7.94,7.94,0,0,0,22,14ZM6.5,14A7.5,7.5,0,1,1,14,21.5,
        7.5,7.5,0,0,1,6.5,14ZM18.24,9.76a6,6,0,1,0,0,8.48A6,6,0,0,0,18.24,9.76Zm-7.78,2.83a1.51,1.51,0,1,1,
        2.13,0A1.52,1.52,0,0,1,10.46,12.59Zm0,4.95a1.51,1.51,0,1,1,2.13,0A1.52,1.52,0,0,1,10.46,
        17.54Zm2.83-4.25a1,1,0,1,1,0,1.42A1,1,0,0,1,13.29,13.29Zm2.12-.7a1.51,1.51,0,1,1,2.13,0A1.52,1.52,
        0,0,1,15.41,12.59Zm0,4.95a1.51,1.51,0,1,1,2.13,0A1.52,1.52,0,0,1,15.41,17.54Z" class="style-scope iron-icon"></path>
    </g></svg>`

},
globalNav:{
  dashboard:`<svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;"><g class="style-scope iron-icon">
  <path d="M14,22H7a1,1,0,0,1-1-1V12h8ZM14,6H7A1,1,0,0,0,6,7v3h8Zm2,10h6V7a1,1,0,0,0-1-1H16Zm0,6h5a1,1,0,0,
  0,1-1V18H16Z" class="style-scope iron-icon"></path>
</g></svg>`,
  projects:`<svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;"><g class="style-scope iron-icon">
  <path d="M22,13.25v7.42a.5.5,0,0,1-.39.49A33.15,33.15,0,0,1,14,22a30.63,30.63,0,0,1-7.62-.84A.5.5,0,0,1,
  6,20.67V13.25ZM21.49,6H16.75a.54.54,0,0,0-.43.23L15.1,8.12l0,0A2.21,2.21,0,0,1,13.23,9H6.51A.51.51,0,0,
  0,6,9.46v1.83H22v0h0V6.51A.51.51,0,0,0,21.49,6Z" class="style-scope iron-icon"></path>
</g></svg>`,
},
userIcon: `<svg viewBox="0 0 22 22" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none;display: block;width: 100%;height: 100%;"><g class="style-scope iron-icon"><path stroke-linejoin="round" d="M16.17 12l4.33 3v6.5h-19V15l4.33-3" class="style-scope iron-icon"></path><rect x="6.5" y=".5" width="9" height="11" rx="4.5" ry="4.5" stroke-linejoin="round" class="style-scope iron-icon"></rect></g></svg>`,
downArrow:`<svg viewBox="0 0 16 16" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope iron-icon" style="pointer-events: none; display: block; width: 100%; height: 100%;"><g class="style-scope iron-icon"><path stroke-linejoin="round" d="M2.4 6.2l5.5 5.5 5.5-5.5" class="style-scope iron-icon"></path></g></svg>`

};

