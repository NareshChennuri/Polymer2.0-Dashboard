const styleClasses = {
    class1: ` fill: #fff;stroke-miterlimit: 10;stroke: #00b5e2; `,
    class2: ` fill: none;stroke-linecap: round;stroke-linejoin: round;stroke: #00b5e2 `,
    class3: ` fill: #989898; `,
    class4: ` fill: #00b5e2; `,
    class11: ` opacity: 0.64; `,
    class12: ` opacity: 0.8; `,
    class14: ` fill-rule: evenodd; `,
    
}
const svgIcons = {
    logo: `<svg viewBox="0 0 65 65">
    <defs>
        <g id="logo">
            <circle class="cls-1" cx="32.5" cy="32.5" r="32" style="${styleClasses.class1}"/>
            <path class="cls-2" d="M35.77,12.79A20,20,0,0,1,51.44,38.9M17.5,45.7A20,20,0,0,0,48,
                    45.19M28.57,12.89A20,20,0,0,0,13.79,39.53" style="${styleClasses.class2}" />
            <path class="cls-3" d="M28.47,36.93l-4.12,2.49L9.83,47.82a.72.72,0,0,1-1-.26h0a.73.73,0,0,
                    1,.2-.94L19.94,37.2,23.45,37,27,34.89A6,6,0,0,0,28.47,36.93Zm2.21-10.14a5.74,5.74,0,0,1,
                    1.82-.29c.23,0,.46,0,.68,0V22.43l1.54-3.15L32,5.14a.72.72,0,0,0-.71-.64h0a.71.71,0,0,
                    0-.71.71V22ZM57.1,44.47,42.57,36.09l-4.21-2.31a5.92,5.92,0,0,1-1,2.29l3.57,2,2,2.91,13.6,
                    4.7a.7.7,0,0,0,.91-.29h0A.71.71,0,0,0,57.1,44.47Zm-20.6-12a4,4,0,1,1-4-4A4,4,0,0,1,36.5,
                    32.5Z" style="${styleClasses.class3}" />
            <circle class="cls-4" cx="15.92" cy="21.32" r="4" style="${styleClasses.class4}" />
        </g>
    </defs>
</svg>`
};


export {svgIcons}