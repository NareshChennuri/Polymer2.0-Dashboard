import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalsService } from '../../shared/api/globals.service';
import { combineLatest, Subscription } from 'rxjs';
import { DataService } from '../../shared/api/data.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-routes',
  templateUrl: './select-routes.component.html',
  styleUrls: ['./select-routes.component.css']
})
export class SelectRoutesComponent implements OnInit, OnDestroy {
  private combinedSubscribe: Subscription;
  private pushToSalesForceSubscribe: Subscription;

  searchSession: string;
  currentSessionId: any;
  currentUser: any;
  constructor(
    private router: Router,
    private globals: GlobalsService,
    private dataService: DataService,
    private toaster: ToastrService
  ) {}

  ngOnInit() {
    const sessionDtls$ = this.globals.currentSession;
    const userInfo$ = this.globals.currentUser;

    const combined = combineLatest(sessionDtls$, userInfo$);

    this.combinedSubscribe = combined.subscribe(([sessionId, userInfo]) => {
      this.currentSessionId = sessionId;
      this.currentUser = userInfo;
    });
  }
  gotoAction() {
    this.globals.changeSesssion(this.searchSession);
    this.globals.callSearchAPI();
    this.globals.updateGoalSeekDetails([]);
    this.router.navigate(['/actions/', this.searchSession]);
  }
  onSessionClick() {
    this.searchSession = '';
    this.globals.updateGoalSeekDetails([]);
  }

  PushToOppty() {
    const pushOpyReq = {
      windselectId: this.currentSessionId
    };
    this.pushToSalesForceSubscribe = this.dataService
      .pushToSalesForce(pushOpyReq)
      .subscribe(resp => {
        if (resp) {
          this.toaster.success(resp.message);
        }
      });
  }

  ngOnDestroy() {
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.pushToSalesForceSubscribe) {
      this.pushToSalesForceSubscribe.unsubscribe();
    }
  }
}
