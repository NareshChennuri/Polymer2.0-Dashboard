import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectRoutesComponent } from './select-routes.component';

describe('SelectRoutesComponent', () => {
  let component: SelectRoutesComponent;
  let fixture: ComponentFixture<SelectRoutesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectRoutesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectRoutesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
