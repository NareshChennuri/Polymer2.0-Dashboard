import { Component, OnInit, OnDestroy } from '@angular/core';
import { SvgIconRegistryService } from 'angular-svg-icon';
import { svgIcons } from '../svg/svg.component';
import { userRoles, getAccessToken } from '../../shared/app-constants';
import { DataService } from '../api/data.service';
import { GlobalsService } from '../api/globals.service';
import { Router } from '@angular/router';
import { environment } from './../../../environments/environment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  private getUserIdSubscribe: Subscription;
  private getUserDetailsSubscribe: Subscription;
  private currentSessionSubscribe: Subscription;
  private currentUserSubscribe: Subscription;

  svgIcons: any = svgIcons;
  userDetails: any;
  selectedSession: any;
  currentUser: any;
  userRolesList: any = userRoles;
  userRole: any;
  environmentType = environment.devEnv;

  constructor(
    private iconReg: SvgIconRegistryService,
    private dataService: DataService,
    private globals: GlobalsService,
    private router: Router
  ) {}

  ngOnInit() {
    this.iconReg.addSvg('logo', `${this.svgIcons.logo}`);
    this.iconReg.addSvg('userIcon', `${this.svgIcons.userIcon}`);
    this.iconReg.addSvg('downArrow', `${this.svgIcons.downArrow}`);
    this.iconReg.addSvg('rects', `${this.svgIcons.appsIcons.rects}`);
    this.iconReg.addSvg('question', `${this.svgIcons.appOptions.question}`);
    this.iconReg.addSvg('info', `${this.svgIcons.appOptions.info}`);
    this.iconReg.addSvg('credits', `${this.svgIcons.appOptions.credits}`);
    this.iconReg.addSvg('dashboard', `${this.svgIcons.globalNav.dashboard}`);
    this.iconReg.addSvg('projects', `${this.svgIcons.globalNav.projects}`);

    this.getUserIdSubscribe = this.dataService.getUserId().subscribe(resp => {
      console.log('User Results 2 ===>', resp); // 503091474
      let userReq = { userId: 502777047 };
      if (resp && resp.details) {
        userReq = { userId: resp.details.user_name };
      }

      this.getUserDetailsSubscribe = this.dataService
        .getUserDetails(userReq)
        .subscribe(userInfo => {
          console.log('userInfo', userInfo);
          if (userInfo && userInfo.user) {
            this.userDetails = userInfo.user;
            this.globals.changeUser(userInfo.user);
          }
        });
    });

    this.currentSessionSubscribe = this.globals.currentSession.subscribe(
      sessionDetails => {
        this.selectedSession = sessionDetails;
      }
    );

    this.currentUserSubscribe = this.globals.currentUser.subscribe(userDtls => {
      this.currentUser = userDtls;
      console.log('userDtls', userDtls);
      const filteredRole = this.userRolesList.filter(
        role => role.roleId === userDtls.roleId
      );
      if (filteredRole.length > 0) {
        this.userRole = filteredRole[0].roleName;
      }
    });
  }

  refreshAccessToken() {
    getAccessToken().then(token => {
      sessionStorage.setItem('headerAccessToken', `Bearer ${token}`);
      window.location.reload();
    });
  }

  ngOnDestroy() {
    if (this.getUserIdSubscribe) {
      this.getUserIdSubscribe.unsubscribe();
    }
    if (this.getUserDetailsSubscribe) {
      this.getUserDetailsSubscribe.unsubscribe();
    }
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
    if (this.currentUserSubscribe) {
      this.currentUserSubscribe.unsubscribe();
    }
  }
}
