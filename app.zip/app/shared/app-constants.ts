import { environment } from './../../environments/environment';

const devEnv = environment.devEnv;
let catalogURI,
  cacheAPI,
  basicAPI,
  userAPI,
  calcAEPAPI,
  bopServiceAPI,
  headerAccessToken,
  projEcoAPI;
if (devEnv === 'dev') {
  catalogURI = `https://windselect-catalogservice.run.aws-usw02-pr.ice.predix.io/catalog`;
  cacheAPI = `https://windselect-cacheservice.run.aws-usw02-pr.ice.predix.io/cache`;
  basicAPI = `https://windselect-basicservice.run.aws-usw02-pr.ice.predix.io/basic`;
  userAPI = `https://windselect-userservice.run.aws-usw02-pr.ice.predix.io/user`;
  calcAEPAPI = `https://windselect-aepcalculationservice.run.aws-usw02-pr.ice.predix.io/aepcalc/aep`;
  projEcoAPI = `https://windselect-projecteconomics-dynamicCapital.run.aws-usw02-pr.ice.predix.io/projecteconomics`;
  bopServiceAPI = `https://ren-ws-bop-service-dev.run.aws-usw02-pr.ice.predix.io`;     
  // tslint:disable-next-line:max-line-length
  headerAccessToken = `Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI0NGRjYmQ5NDFhNWE0NjY2ODUzN2UzY2E1MzJhNTk3OSIsInN1YiI6InJlbmV3YWJsZWVuZXJneV9XaW5kU2VsZWN0X2RldiIsInNjb3BlIjpbInVhYS5yZXNvdXJjZSIsIm9wZW5pZCJdLCJjbGllbnRfaWQiOiJyZW5ld2FibGVlbmVyZ3lfV2luZFNlbGVjdF9kZXYiLCJjaWQiOiJyZW5ld2FibGVlbmVyZ3lfV2luZFNlbGVjdF9kZXYiLCJhenAiOiJyZW5ld2FibGVlbmVyZ3lfV2luZFNlbGVjdF9kZXYiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImRhMjY4M2UiLCJpYXQiOjE1NTkwMzI3MzcsImV4cCI6MTU1OTAzOTkzNiwiaXNzIjoiaHR0cHM6Ly9hOGEyZmZjNC1iMDRlLTRlYzEtYmZlZC03YTUxZGQ0MDg3MjUucHJlZGl4LXVhYS5ydW4uYXdzLXVzdzAyLXByLmljZS5wcmVkaXguaW8vb2F1dGgvdG9rZW4iLCJ6aWQiOiJhOGEyZmZjNC1iMDRlLTRlYzEtYmZlZC03YTUxZGQ0MDg3MjUiLCJhdWQiOlsidWFhIiwib3BlbmlkIiwicmVuZXdhYmxlZW5lcmd5X1dpbmRTZWxlY3RfZGV2Il19.UYmd1xBriCisPYtLWLaWx-0M838ssJHhNyxTu-zPaNk_GFpJpP2xui6lWFOgJCw1m3s7X4fMqi_g3DQla7PX1iomCYWej_2hfzVqtAcnBx2rEywRH1OrVUGku9RwSdP0ogypHsBCIlLAhlxGDoKvQPkOr5NI48JDDrKc9KL1Vfjngs_qoG6PQLDCPA9rw2iUwXfm_jx1cFfAtnC_jtY4YD8L5bWEUN2rxZIA4VBg6oqg1YvYUEy73AlcOIRLHvdlR1LNtyfgIp6LAxJhZSHWKVbPgyYdbsuCPpysL_Yxco02qrwJ1_MGChfqOwoPeeTAlai3MIsNw3iMMPTBMJnyCg`;
} else if (devEnv === 'build') {
  catalogURI = `/ws-catalog/catalog`;
  cacheAPI = `/ws-cache/cache`;
  basicAPI = `/ws-basic/basic`;
  userAPI = `/ws-user/user`;
  calcAEPAPI = `/ws-aep/aepcalc/aep`;
  projEcoAPI = `/ws-projeco/projecteconomics`;
  bopServiceAPI = `/ws-bop`;
  headerAccessToken = ``;
}

const getAccessToken = () => {
  return new Promise(function(resolve, reject) {
    const clientID = 'renewableenergy_WindSelect_dev'; // app clientID
    const clientSecret = 'ToHlenb0tvJHhsN4'; // app clientSecret
    const url =
      'https://a8a2ffc4-b04e-4ec1-bfed-7a51dd408725.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token';
    const request = new XMLHttpRequest();
    request.open('POST', url, true);
    request.setRequestHeader(
      'content-type',
      'application/x-www-form-urlencoded'
    );
    request.send(
      'grant_type=client_credentials&client_id=' +
        clientID +
        '&' +
        'client_secret=' +
        clientSecret
    ); // specify the credentials to receive the token on request
    request.onreadystatechange = function() {
      if (request.readyState === request.DONE) {
        const response = request.responseText;
        const obj = JSON.parse(response);
        resolve(obj.access_token); // store the value of the accesstoken
      }
    };
  });
};

const roleId = 1;

const turbineDetails = [
  {
    id: 1,
    powercurveList: [],
    selectedPCList: [],
    powercurve: '',
    pValues: [],
    uncertainty: ''
  },
  {
    id: 2,
    powercurveList: [],
    selectedPCList: [],
    powercurve: '',
    pValues: [],
    uncertainty: ''
  }
];

const finalcialModels = [
  { value: 'baseCase', viewValue: 'Base Case' },
  { value: 'midCase', viewValue: 'Mid Case' },
  { value: 'highEnd', viewValue: 'High End' }
];

const userRoles = [
  {
    roleId: 0,
    roleName: 'Guest',
    roleDesc: 'Guest Role for Non Approvall',
    isActive: true
  },
  {
    roleId: 1,
    roleName: 'Admin',
    roleDesc: 'admin permissions',
    isActive: true
  },
  {
    roleId: 2,
    roleName: 'Super User',
    roleDesc: 'super user',
    isActive: true
  },
  {
    roleId: 3,
    roleName: 'Sales Executive',
    roleDesc: 'normal user',
    isActive: true
  },
  {
    roleId: 4,
    roleName: 'AE',
    roleDesc: 'Account Engineer',
    isActive: true
  },
  {
    roleId: 5,
    roleName: 'Known Customer',
    roleDesc: 'Familiar customer',
    isActive: true
  }
];

export {
  catalogURI,
  cacheAPI,
  basicAPI,
  userAPI,
  projEcoAPI,
  calcAEPAPI,
  bopServiceAPI,
  headerAccessToken,
  roleId,
  turbineDetails,
  finalcialModels,
  userRoles,
  getAccessToken
};
