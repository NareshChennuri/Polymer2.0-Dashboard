export const LANG_ZH_NAME = 'zh';

export const LANG_ZH_TRANS = {
  Information: '信息',
  'Market Data': '市场数据',
  'MARKET INPUTS' : '市场输入',
};
