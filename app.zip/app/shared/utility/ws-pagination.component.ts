import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnChanges,
  SimpleChanges,
  OnDestroy
} from '@angular/core';
import { Subject, Subscription } from 'rxjs';

@Component({
  moduleId: module.id,
  selector: 'app-pagination',
  template: `
    <div class="total-parks">{{ totalPagesCount }}</div>
    <ul *ngIf="pager.pages && pager.pages.length" class="pagination">
      <li
        [ngClass]="{ disabled: pager.currentPage === 1 }"
        class="page-item first-item"
        title="First"
      >
        <a (click)="setPage(1)" class="page-link"><<</a>
      </li>
      <li
        [ngClass]="{ disabled: pager.currentPage === 1 }"
        class="page-item previous-item"
        style="flex-direction:row;"
        title="Prev"
      >
        <a (click)="setPage(pager.currentPage - 1)" class="page-link"><</a>
      </li>
      <li
        *ngFor="let page of pager.pages"
        [ngClass]="{ active: pager.currentPage === page }"
        class="page-item number-item"
        style="flex-direction:row;"
      >
        <a (click)="setPage(page)" class="page-link">{{ page }}</a>
      </li>
      <li
        [ngClass]="{ disabled: pager.currentPage === pager.totalPages }"
        class="page-item next-item"
        style="flex-direction:row;"
        title="Next"
      >
        <a (click)="setPage(pager.currentPage + 1)" class="page-link">></a>
      </li>
      <li
        [ngClass]="{ disabled: pager.currentPage === pager.totalPages }"
        class="page-item last-item"
        title="Last"
      >
        <a (click)="setPage(pager.totalPages)" class="page-link">>></a>
      </li>
    </ul>
  `
})
export class WsPaginationComponent implements OnInit, OnChanges, OnDestroy {
  private gotoPageSubscribe: Subscription;
  @Input() items: Array<any>;
  @Output() changePage = new EventEmitter<any>(true);
  @Input() initialPage = 1;
  @Input() pageSize = 1;
  @Input() maxPages = 5;
  pager: any = {};
  totalPagesCount: string;
  @Input() gotoPage: Subject<any>;

  ngOnInit() {
    this.gotoPageSubscribe = this.gotoPage.subscribe(pageId => {
      this.setPage(pageId);
    });
    // set page if items array isn't empty
    if (this.items && this.items.length) {
      this.setPage(this.initialPage);
      this.totalPagesCount = `Total Parks: ${this.items.length + 1}`;
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    // reset page if items array has changed
    if (changes.items.currentValue !== changes.items.previousValue) {
      this.setPage(this.initialPage);
    }
  }

  private setPage(page: number) {
    // get new pager object for specified page
    this.pager = this.paginate(
      this.items.length,
      page,
      this.pageSize,
      this.maxPages
    );

    // get new page of items from items array
    const pageOfItems = this.items.slice(
      this.pager.startIndex,
      this.pager.endIndex + 1
    );

    // call change page function in parent component
    this.changePage.emit(pageOfItems);
  }

  paginate(totalItems, currentPage, pageSize, maxPages) {
    if (currentPage === void 0) {
      currentPage = 1;
    }
    if (pageSize === void 0) {
      pageSize = 10;
    }
    if (maxPages === void 0) {
      maxPages = 10;
    }
    // calculate total pages
    const totalPages = Math.ceil(totalItems / pageSize);
    // ensure current page isn't out of range
    if (currentPage < 1) {
      currentPage = 1;
    } else if (currentPage > totalPages) {
      currentPage = totalPages;
    }
    let startPage, endPage;
    if (totalPages <= maxPages) {
      // total pages less than max so show all pages
      startPage = 1;
      endPage = totalPages;
    } else {
      // total pages more than max so calculate start and end pages
      const maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
      const maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
      if (currentPage <= maxPagesBeforeCurrentPage) {
        // current page near the start
        startPage = 1;
        endPage = maxPages;
      } else if (currentPage + maxPagesAfterCurrentPage >= totalPages) {
        // current page near the end
        startPage = totalPages - maxPages + 1;
        endPage = totalPages;
      } else {
        // current page somewhere in the middle
        startPage = currentPage - maxPagesBeforeCurrentPage;
        endPage = currentPage + maxPagesAfterCurrentPage;
      }
    }
    // calculate start and end item indexes
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);
    // create an array of pages to ng-repeat in the pager control
    const pages = Array.from(Array(endPage + 1 - startPage).keys()).map(
      function(i) {
        return startPage + i;
      }
    );
    // return object with all pager properties required by the view
    return {
      totalItems: totalItems,
      currentPage: currentPage,
      pageSize: pageSize,
      totalPages: totalPages,
      startPage: startPage,
      endPage: endPage,
      startIndex: startIndex,
      endIndex: endIndex,
      pages: pages
    };
  }

  ngOnDestroy() {
    if (this.gotoPageSubscribe) {
      this.gotoPageSubscribe.unsubscribe();
    }
  }
}
