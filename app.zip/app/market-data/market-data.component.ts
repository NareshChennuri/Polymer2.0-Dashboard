import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { GlobalsService } from '../shared/api/globals.service';

@Component({
  selector: 'app-market-data',
  templateUrl: './market-data.component.html',
  styleUrls: ['./market-data.component.css']
})
export class MarketDataComponent implements OnInit, OnDestroy {
  private currentSessionSubscribe: Subscription;
  selectedSession: any;
  constructor(private _globals: GlobalsService) {}

  ngOnInit() {
    this.currentSessionSubscribe = this._globals.currentSession.subscribe(
      sessionDetails => {
        this.selectedSession = sessionDetails;
      }
    );
  }

  getLabelData() {
    return `Hello`;
  }

  ngOnDestroy() {
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
  }
}
