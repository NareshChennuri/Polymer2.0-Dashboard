import {
  Component,
  Inject,
  OnInit,
  ViewChild,
  ElementRef,
  OnDestroy
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { RevenueStreamComponent } from '../revenue-stream.component';
import { FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { DataService } from '../../../shared/api/data.service';
import { GlobalsService } from '../../../shared/api/globals.service';

@Component({
  selector: 'app-add-revenue-stream-dialog',
  templateUrl: 'add-revenue-stream-dialog.component.html',
  styleUrls: ['./add-revenue-stream-dialog.component.css']
})
export class AddRevenueStreamDialogComponent implements OnInit, OnDestroy {
  private codDateSubscribe: Subscription;
  codDate: Date;
  revenueStream = new FormControl();
  options: string[];
  // revenueStreamOptions: Observable<string[]>;
  @ViewChild('startDate') startDate: ElementRef;
  @ViewChild('picker2') endDatePicker: ElementRef;
  @ViewChild('picker3') startDatePicker: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<RevenueStreamComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _service: DataService,
    private globals: GlobalsService
  ) {}

  ngOnInit() {
    this.codDateSubscribe = this.globals.codDate.subscribe(date => {
      this.codDate = new Date(this.globals.returnFormattedDate(date));
    });
    const year = this.codDate.getUTCFullYear();
    const month = this.codDate.getUTCMonth();
    const day = this.codDate.getUTCDate();
    // this.data.record.endDate = this.globals.returnFormattedDate(
    //   new Date(year + 20, month, day-1)
    // );
    this.data.record.endDate = new Date(year + 20, month, day - 1);
    this.data.record.startDate = this.codDate;
    // this.data.record.tarriffStartDate = this.data.record.startDate;
    this.dateChange();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  dateChange() {
    const startDate = this.data.record.startDate;
    if (startDate) {
      this.endDatePicker['disabled'] = false;
      // if (
      //   this.data.record.tarriffGrowthChange &&
      //   this.data.record.tarriffGrowthChange.trim() !== '-None-'
      // ) {
      //   this.data.record.tarriffStartDate = startDate;
      // } else {
      //   this.data.record.tarriffStartDate = '';
      // }
    }
    const endDate = this.data.record.endDate;
    let period = 0;
    if (startDate && endDate) {
      period = Math.abs(
        new Date(startDate).getTime() - new Date(endDate).getTime()
      );
      this.data.record.periods = (period / (1000 * 3600 * 24) / 365).toFixed(1);
    }
  }

  tarriffFrequencyOnChange(event) {
    if (event.value && event.value.trim() === '-None-') {
      this.startDatePicker['disabled'] = true;
      this.data.record.tarriffStartDate = '';
    } else {
      this.startDatePicker['disabled'] = false;
      this.data.record.tarriffStartDate = this.data.record.startDate;
    }
  }

  tariffDateChange() {
    if (
      this.data.record &&
      this.data.record.tarriffGrowthChange &&
      this.data.record.tarriffGrowthChange.trim() === '-None-'
    ) {
      this.startDatePicker['disabled'] = true;
      this.data.record.tarriffStartDate = '';
    }
  }

  ngOnDestroy() {
    if (this.codDateSubscribe) {
      this.codDateSubscribe.unsubscribe();
    }
  }
}
