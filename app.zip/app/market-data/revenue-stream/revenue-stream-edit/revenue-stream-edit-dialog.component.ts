import {
  Component,
  Inject,
  OnInit,
  AfterViewInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  OnDestroy
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { RevenueStreamComponent } from '../revenue-stream.component';
import { FormControl } from '@angular/forms';
import { DataService } from '../../../shared/api/data.service';
import { GlobalsService } from '../../../shared/api/globals.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-revenue-stream-edit-dialog',
  templateUrl: 'revenue-stream-edit-dialog.component.html',
  styleUrls: ['./revenue-stream-edit-dialog.component.css']
})
export class RevenueStreamEditDialogComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private codDateSubscribe: Subscription;
  codDate: string;
  revenueStream = new FormControl();
  options: string[];
  @ViewChild('startDate') startDate: ElementRef;
  @ViewChild('picker2') endDatePicker: ElementRef;
  @ViewChild('picker3') startDatePicker: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<RevenueStreamComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _service: DataService,
    private globals: GlobalsService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    if (this.data.record) {
      this.codDateSubscribe = this.globals.codDate.subscribe(date => {
        this.codDate = this.globals.returnFormattedDate(date);
      });
      this.data.record.periods = this.data.record.periods;
    }
  }

  ngAfterViewInit(): void {
    this.tariffDateChange();
    this.cdr.detectChanges();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  dateChange() {
    const startDate = this.data.record.startDate;
    if (startDate) {
      this.endDatePicker['disabled'] = false;
    }
    const endDate = this.data.record.endDate;
    let period = 0;
    if (startDate && endDate) {
      period = Math.abs(
        new Date(startDate).getTime() - new Date(endDate).getTime()
      );
      this.data.record.periods = (period / (1000 * 3600 * 24) / 365).toFixed(1);
    }
  }

  tarriffFrequencyOnChange(event) {
    if (event.value && event.value.trim() === '-None-') {
      this.startDatePicker['disabled'] = true;
      this.data.record.tarriffStartDate = '';
    } else {
      this.startDatePicker['disabled'] = false;
      this.data.record.tarriffStartDate = this.data.record.startDate;
    }
  }

  tariffDateChange() {
    if (
      this.data.record &&
      this.data.record.tarriffGrowthChange &&
      this.data.record.tarriffGrowthChange.trim() === '-None-'
    ) {
      this.startDatePicker['disabled'] = true;
      this.data.record.tarriffStartDate = '';
    }
  }
  ngOnDestroy() {
    if (this.codDateSubscribe) {
      this.codDateSubscribe.unsubscribe();
    }
  }
}
