import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { combineLatest, Subscription } from 'rxjs';
import { RevenueStreamEditDialogComponent } from './revenue-stream-edit/revenue-stream-edit-dialog.component';
import { AddRevenueStreamDialogComponent } from './add-revenue-stream/add-revenue-stream-dialog.component';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';

export interface RevenueStreamData {
  id: number;
  name: string;
  startDate: object;
  endDate: object;
  periods: number;
  ppa: number;
  applyUnit: string;
  frequency: string;
  limitValue: number;
  limitOn: string;
  limitOnName: string;
  tarriffGrowthValue: number;
  tarriffGrowthChange: string;
  tarriffGrowthChangeName: string;
  tarriffStartDate: object;
  debtSizing: any;
  actions: string;
}

@Component({
  selector: 'app-revenue-stream',
  templateUrl: './revenue-stream.component.html',
  styleUrls: ['./revenue-stream.component.css']
})
export class RevenueStreamComponent implements OnInit, OnDestroy {
  private combinedSubscribe: Subscription;
  private combinedCasesSubscribe: Subscription;
  private loadedCaseDataSubscribe: Subscription;
  private countryChangeEmitterSubscribe: Subscription;
  private nameFilterSubscribe: Subscription;
  private startDateFilterSubscribe: Subscription;
  private endDateFilterSubscribe: Subscription;
  private periodsFilterSubscribe: Subscription;
  private ppaFilterSubscribe: Subscription;
  private applyUnitFilterSubscribe: Subscription;
  private frequencyFilterSubscribe: Subscription;
  private limitOnNameFilterSubscribe: Subscription;
  private limitValueFilterSubscribe: Subscription;
  private tarriffGrowthValueFilterSubscribe: Subscription;
  private tarriffGrowthChangeNameFilterSubscribe: Subscription;
  private tarriffStartDateFilterSubscribe: Subscription;
  private debtSizingFilterSubscribe: Subscription;
  private loadCaseSubscribe: Subscription;
  private selectedCaseInfoSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  private saveRevenueStreamSubscribe: Subscription;
  private selectedCaseInfo2Subscribe: Subscription;
  private afterClosed2Subscribe: Subscription;
  private saveRevenueStream2Subscribe: Subscription;
  private afterClosed3Subscribe: Subscription;
  private deleteRevenueStreamSubscribe: Subscription;
  caseData: any;
  selectedRowId: number;
  sessionId: any;
  userDetails: any;
  marketDataCaseId: any;
  marketDataSessionId: any;
  frequencyListItems: object = [];
  applyUnitListItems: object = [];
  limitOnListItems = [];
  tarriffGrowthChangeListItems = [];
  defaultOption = 1;
  selectedRecord: RevenueStreamData;
  displayedColumns: string[] = [
    'name',
    'startDate',
    'endDate',
    'periods',
    'ppa',
    'applyUnit',
    'frequency',
    'tarriffGrowthValue',
    'tarriffGrowthChangeName',
    'tarriffStartDate',
    'actions'
  ];
  dataSource = new MatTableDataSource<any>([]);

  nameFilter = new FormControl('');
  startDateFilter = new FormControl('');
  endDateFilter = new FormControl('');
  periodsFilter = new FormControl('');
  ppaFilter = new FormControl('');
  applyUnitFilter = new FormControl('');
  frequencyFilter = new FormControl('');
  limitOnNameFilter = new FormControl('');
  limitValueFilter = new FormControl('');
  tarriffGrowthValueFilter = new FormControl('');
  tarriffGrowthChangeNameFilter = new FormControl('');
  tarriffStartDateFilter = new FormControl('');
  debtSizingFilter = new FormControl('');

  filterValues = {
    name: '',
    startDate: '',
    endDate: '',
    periods: '',
    ppa: '',
    applyUnit: '',
    frequency: '',
    limitOnName: '',
    limitValue: '',
    tarriffGrowthValue: '',
    tarriffGrowthChangeName: '',
    tarriffStartDate: '',
    debtSizing: ''
  };

  @ViewChild(MatSort) sort: MatSort;

  constructor(
    public dialog: MatDialog,
    private dataService: DataService,
    private globals: GlobalsService,
    private toastr: ToastrService
  ) {
    this.getDropDownValuesByKey('revenue_stream_name');
  }
  getDropDownValuesByKey(key: string) {
    this.tarriffGrowthChangeListItems = [
      { id: '-None-', name: '-None-(default)' },
      { id: 'Yearly', name: 'Yearly' }
    ];
    this.applyUnitListItems = [{ id: 'cents-kwh', name: 'Cents/Kwh' }];
    this.frequencyListItems = [{ id: 'yearly', name: 'Yearly(default)' }];
  }
  ngOnInit() {
    this.dataSource.filterPredicate = this.createFilter();
    this.dataSource.sort = this.sort;
    this.processFilters();

    const currentUser$ = this.globals.currentUser;
    const curretSession$ = this.globals.currentSession;
    const loadedCaseData$ = this.globals.loadedCaseData;
    const selectedCaseId$ = this.globals.selectedCaseId;
    const casesList$ = this.globals.listOfCases;
    const combined = combineLatest(currentUser$, curretSession$);
    const combinedCases = combineLatest(casesList$, selectedCaseId$);

    this.combinedSubscribe  = combined.subscribe(([userDtls, sessionId]) => {
      this.userDetails = userDtls;
        this.sessionId = sessionId;
      // this.getRevenueStreamsList();
    });

    this.combinedCasesSubscribe = combinedCases.subscribe(([caseList, caseId]) => {
        this.marketDataCaseId = caseId;
      if (caseList && Array.isArray(caseList)) {
        const filterdList = caseList.filter(cs => cs.id === caseId);
        if (filterdList.length) {
          this.marketDataSessionId = filterdList[0].sessionId;
        }
      }
    });

    this.loadedCaseDataSubscribe = loadedCaseData$.subscribe(
      caseData => {
        if (caseData && caseData.revenueStream) {
          this.processRevenuStream(caseData.revenueStream);
        }
      }
    );

    this.countryChangeEmitterSubscribe = this.globals.countryChangeEmitter.subscribe(
      () => {
        this.dataSource = new MatTableDataSource<any>([]);
      }
    );
  }

  processFilters() {
    this.nameFilterSubscribe = this.nameFilter.valueChanges.subscribe(name => {
      this.filterValues.name = name;
      this.dataSource.filter = JSON.stringify(this.filterValues);
    });
    this.startDateFilterSubscribe = this.startDateFilter.valueChanges.subscribe(
      startDate => {
        this.filterValues.startDate = startDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.endDateFilterSubscribe = this.endDateFilter.valueChanges.subscribe(
      endDate => {
        this.filterValues.endDate = endDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.periodsFilterSubscribe = this.periodsFilter.valueChanges.subscribe(
      periods => {
        this.filterValues.periods = periods;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.ppaFilterSubscribe = this.ppaFilter.valueChanges.subscribe(ppa => {
      this.filterValues.ppa = ppa;
      this.dataSource.filter = JSON.stringify(this.filterValues);
    });
    this.applyUnitFilterSubscribe = this.applyUnitFilter.valueChanges.subscribe(
      applyUnit => {
        this.filterValues.applyUnit = applyUnit;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.frequencyFilterSubscribe = this.frequencyFilter.valueChanges.subscribe(
      frequency => {
        this.filterValues.frequency = frequency;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.limitOnNameFilterSubscribe = this.limitOnNameFilter.valueChanges.subscribe(
      limitOnName => {
        this.filterValues.limitOnName = limitOnName;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.limitValueFilterSubscribe = this.limitValueFilter.valueChanges.subscribe(
      limitValue => {
        this.filterValues.limitValue = limitValue;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.tarriffGrowthValueFilterSubscribe = this.tarriffGrowthValueFilter.valueChanges.subscribe(
      tarriffGrowthValue => {
        this.filterValues.tarriffGrowthValue = tarriffGrowthValue;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.tarriffGrowthChangeNameFilterSubscribe = this.tarriffGrowthChangeNameFilter.valueChanges.subscribe(
      tarriffGrowthChangeName => {
        this.filterValues.tarriffGrowthChangeName = tarriffGrowthChangeName;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.tarriffStartDateFilterSubscribe = this.tarriffStartDateFilter.valueChanges.subscribe(
      tarriffStartDate => {
        this.filterValues.tarriffStartDate = tarriffStartDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.debtSizingFilterSubscribe = this.debtSizingFilter.valueChanges.subscribe(
      debtSizing => {
        this.filterValues.debtSizing = debtSizing;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
  }

  getRevenueStreamsList() {
    const loadCaseReq = {
      caseId: this.caseData.id,
      sessionId: this.caseData.sessionId
    };
    this.loadCaseSubscribe = this.dataService
      .loadCase(loadCaseReq)
      .subscribe(result => {
        if (result) {
          this.globals.updateLoadedCaseData(result);
        }
      });
  }

  processRevenuStream(streamsInfo) {
    const revenueData = streamsInfo.map(item => {
      let limitOnName = '';
      for (const obj of this.limitOnListItems) {
        if (obj.id === item.limitOn) {
          limitOnName = obj.name;
        }
      }

      let tarriffGrowthChangeName = '';
      for (const obj of this.tarriffGrowthChangeListItems) {
        if (obj.id === item.tarriffGrowthChange) {
          tarriffGrowthChangeName = obj.name;
        }
      }
      item = {
        ...item,
        id: item.id,
        ppa: item.ppa,
        name: item.name,
        applyUnit: item.applyUnit,
        frequency: item.frequency,
        startDate: item.startDate ? item.startDate : '',
        endDate: item.endDate ? item.endDate : '',
        periods: item.periods,
        tarriffGrowthValue: item.tarriffGrowthValue,
        tarriffGrowthChange: item.tarriffGrowthChange,
        tarriffGrowthChangeName: tarriffGrowthChangeName,
        tarriffStartDate: item.tarriffStartDate ? item.tarriffStartDate : '',
        debtSizing: item.debtSizing === 'Y' ? 'Yes' : 'No',
        limitValue: item.limitValue,
        limitOn: item.limitOn,
        limitOnName: limitOnName,
        marketDataCaseId: item.marketDataCaseId,
        revenueStreamDelete: false,
        actions: ''
      };
      return item;
    });
    this.dataSource.data = revenueData;
  }

  createFilter(): (data: any, filter: string) => boolean {
    const filterFunction = function(data, filter): boolean {
      const searchTerms = JSON.parse(filter);
      return (
        data.name.toLowerCase().indexOf(searchTerms.name) !== -1 &&
        data.startDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.startDate) !== -1 &&
        data.endDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.endDate) !== -1 &&
        data.periods
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.periods) !== -1 &&
        data.ppa
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.ppa) !== -1 &&
        data.applyUnit
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.applyUnit) !== -1 &&
        data.frequency
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.frequency) !== -1 &&
        data.limitOnName
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.limitOnName) !== -1 &&
        data.limitValue
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.limitValue) !== -1 &&
        data.tarriffGrowthValue
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.tarriffGrowthValue) !== -1 &&
        data.tarriffGrowthChangeName
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.tarriffGrowthChangeName) !== -1 &&
        data.tarriffStartDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.tarriffStartDate) !== -1 &&
        data.debtSizing
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.debtSizing) !== -1
      );
    };
    return filterFunction;
  }

  addRevenueStream(dataSource) {
    if (!this.marketDataCaseId) {
      this.toastr.error(`Please Select/Create Case Item to Proceed. `);
      return false;
    }
    this.selectedCaseInfoSubscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );
    if (
      this.caseData.accessMode &&
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted.`);
      return false;
    }

    const data = {};
    const record = {
      name: '',
      startDate: '',
      endDate: '',
      periods: '',
      ppa: '',
      applyUnit: 'cents-kwh',
      frequency: 'yearly',
      limitOn: 'none',
      limitValue: '',
      tarriffGrowthValue: '',
      tarriffGrowthChange: '-None-',
      tarriffStartDate: '',
      debtSizing: ''
    };
    data['record'] = record;
    data['frequencyListItems'] = this.frequencyListItems;
    data['applyUnitListItems'] = this.applyUnitListItems;
    data['tarriffGrowthChangeListItems'] = this.tarriffGrowthChangeListItems;
    data['limitOnListItems'] = this.limitOnListItems;

    const dialogRef = this.dialog.open(AddRevenueStreamDialogComponent, {
      width: '900px',
      data: data
    });
    this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
      this.selectedRowId = null;
      if (result) {
        result.record['createdBy'] = this.userDetails.userId;
        result.record['createdDate'] = '';
        result.record['updatedBy'] = this.userDetails.userId;
        result.record['updatedDate'] = new Date();
        result.record['marketDataCaseId'] = this.marketDataCaseId;
        result.record['caseId'] = this.marketDataCaseId;
        result.record['sessionId'] = this.marketDataSessionId;
        result.record['debtSizing'] = result.record['debtSizing'] ? 'Y' : 'N';
        result.record['id'] = 0;
        result.record['startDate'] = this.globals.removeTimeZone(
          result.record['startDate']
        );
        result.record['endDate'] = this.globals.removeTimeZone(
          result.record['endDate']
        );
        this.saveRevenueStreamSubscribe = this.dataService
          .saveRevenueStream(result.record)
          .subscribe(saveStatus => {
            if (saveStatus) {
              this.toastr.success(`${saveStatus.message} !!`);
              this.getRevenueStreamsList();
            }
          });
      }
    });
  }

  openActionDialog(id: number, flag: string) {
    this.selectedCaseInfo2Subscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );

    if (
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted. `);
      return false;
    }

    this.selectedRowId = id;
    if (flag === 'edit') {
      const record = this.dataSource.data.filter(obj => {
        return obj.id === id;
      })[0];

      this.selectedRecord = { ...record };
      const originalRecord = { ...record };

      const data = {};
      data['record'] = originalRecord;
      data['record']['startDate'] = this.globals.returnFormattedDate(
        record.startDate
      );
      data['record']['endDate'] = this.globals.returnFormattedDate(
        record.endDate
      );
      data['record']['tarriffStartDate'] = this.globals.returnFormattedDate(
        record.tarriffStartDate
      );
      data['action'] = flag;
      data['frequencyListItems'] = this.frequencyListItems;
      data['applyUnitListItems'] = this.applyUnitListItems;
      data['tarriffGrowthChangeListItems'] = this.tarriffGrowthChangeListItems;
      data['limitOnListItems'] = this.limitOnListItems;
      data['record']['debtSizing'] = record.debtSizing === 'Yes' ? true : false;
      const dialogRef = this.dialog.open(RevenueStreamEditDialogComponent, {
        width: '900px',
        data: data
      });
      this.afterClosed2Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          result.record['createdBy'] = this.userDetails.userId;
          result.record['updatedBy'] = this.userDetails.userId;
          result.record['updatedDate'] = new Date();
          result.record['marketDataCaseId'] = this.marketDataCaseId;
          result.record['caseId'] = this.marketDataCaseId;
          result.record['sessionId'] = this.marketDataSessionId;
          result.record['id'] = result.record.id;
          result.record['debtSizing'] = result.record['debtSizing'] ? 'Y' : 'N';
          this.saveRevenueStream2Subscribe = this.dataService
            .saveRevenueStream(result.record)
            .subscribe(editStatus => {
              if (editStatus) {
                this.toastr.success(`${editStatus.message} !!`);
                this.getRevenueStreamsList();
              } else {
                this.toastr.error(`Error in editing the record!!`);
              }
            });
        }
        if (!result) {
          const dataSource = this.dataSource.data.map(obj => {
            if (obj.id === id) {
              obj = this.selectedRecord;
            }
            return obj;
          });
          this.dataSource.data = dataSource;
        }
      });
    }
    if (flag === 'delete') {
      const record = { id, action: flag };
      const dialogRef = this.dialog.open(RevenueStreamEditDialogComponent, {
        width: '300px',
        data: record
      });
      this.afterClosed3Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          this.deleteRevenueStreamSubscribe = this.dataService
            .deleteRevenueStream({ id: id })
            .subscribe(deleteStatus => {
              this.toastr.success(`Item deleted successfully!!`);
              if (deleteStatus) {
                this.getRevenueStreamsList();
              } else {
                this.toastr.error(`Error in deletion of record!!`);
              }
            });
        }
      });
    }
  }

  ngOnDestroy() {
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.combinedCasesSubscribe) {
      this.combinedCasesSubscribe.unsubscribe();
    }
    if (this.loadedCaseDataSubscribe) {
      this.loadedCaseDataSubscribe.unsubscribe();
    }
    if (this.countryChangeEmitterSubscribe) {
      this.countryChangeEmitterSubscribe.unsubscribe();
    }
    if (this.nameFilterSubscribe) {
      this.nameFilterSubscribe.unsubscribe();
    }
    if (this.startDateFilterSubscribe) {
      this.startDateFilterSubscribe.unsubscribe();
    }
    if (this.endDateFilterSubscribe) {
      this.endDateFilterSubscribe.unsubscribe();
    }
    if (this.periodsFilterSubscribe) {
      this.periodsFilterSubscribe.unsubscribe();
    }
    if (this.ppaFilterSubscribe) {
      this.ppaFilterSubscribe.unsubscribe();
    }
    if (this.applyUnitFilterSubscribe) {
      this.applyUnitFilterSubscribe.unsubscribe();
    }
    if (this.frequencyFilterSubscribe) {
      this.frequencyFilterSubscribe.unsubscribe();
    }
    if (this.limitOnNameFilterSubscribe) {
      this.limitOnNameFilterSubscribe.unsubscribe();
    }
    if (this.limitValueFilterSubscribe) {
      this.limitValueFilterSubscribe.unsubscribe();
    }
    if (this.tarriffGrowthValueFilterSubscribe) {
      this.tarriffGrowthValueFilterSubscribe.unsubscribe();
    }
    if (this.tarriffGrowthChangeNameFilterSubscribe) {
      this.tarriffGrowthChangeNameFilterSubscribe.unsubscribe();
    }
    if (this.tarriffStartDateFilterSubscribe) {
      this.tarriffStartDateFilterSubscribe.unsubscribe();
    }
    if (this.debtSizingFilterSubscribe) {
      this.debtSizingFilterSubscribe.unsubscribe();
    }
    if (this.loadCaseSubscribe) {
      this.loadCaseSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfoSubscribe) {
      this.selectedCaseInfoSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
    if (this.saveRevenueStreamSubscribe) {
      this.saveRevenueStreamSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfo2Subscribe) {
      this.selectedCaseInfo2Subscribe.unsubscribe();
    }
    if (this.afterClosed2Subscribe) {
      this.afterClosed2Subscribe.unsubscribe();
    }
    if (this.saveRevenueStream2Subscribe) {
      this.saveRevenueStream2Subscribe.unsubscribe();
    }
    if (this.afterClosed3Subscribe) {
      this.afterClosed3Subscribe.unsubscribe();
    }
    if (this.deleteRevenueStreamSubscribe) {
      this.deleteRevenueStreamSubscribe.unsubscribe();
    }
  }
}
