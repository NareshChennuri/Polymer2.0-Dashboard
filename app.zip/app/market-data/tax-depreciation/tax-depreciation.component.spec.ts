import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxDepreciationComponent } from './tax-depreciation.component';

describe('TaxDepreciationComponent', () => {
  let component: TaxDepreciationComponent;
  let fixture: ComponentFixture<TaxDepreciationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaxDepreciationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxDepreciationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
