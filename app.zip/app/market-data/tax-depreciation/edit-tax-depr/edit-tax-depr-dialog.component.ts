import {
  Component,
  Inject,
  OnInit,
  ViewChild,
  ElementRef,
  OnDestroy
} from '@angular/core'; 
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TaxDepreciationComponent } from '../tax-depreciation.component';
import { GlobalsService } from '../../../shared/api/globals.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-edit-tax-depr-dialog',
  templateUrl: 'edit-tax-depr-dialog.component.html',
  styleUrls: ['./edit-tax-depr-dialog.component.css']
})
export class EditTaxDeprDialogComponent implements OnInit, OnDestroy {
  private codDateSubscribe: Subscription;
  private currentCountryNameSubscribe: Subscription;
  codDate: string;
  country: string;
  descriptionList: object[];
  @ViewChild('startDate') startDate: ElementRef;
  @ViewChild('picker2') endDate: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<TaxDepreciationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private globals: GlobalsService
  ) {
    if (this.data.record) {
      this.codDateSubscribe = this.globals.codDate.subscribe(
        date => {
        this.codDate = this.globals.returnFormattedDate(date);
        // this.data.record.startDate = new Date(this.codDate);
      });
    }
  }
  ngOnInit() {
    if (this.data.record) {
      this.currentCountryNameSubscribe = this.globals.currentCountryName.subscribe(
        country => {
        this.country = country;
      });
      if (this.country === 'US' || this.country === 'US-Offshore') {
        this.data.taxListItems = [
          { id: 'ptc', name: 'PTC' },
          { id: 'corporate tax', name: 'corporate tax' }
        ];
      } else {
        this.data.taxListItems = [
          { id: 'corporate tax', name: 'corporate tax' }
        ];
      }
      if (this.country === 'India' || this.country === 'IndiaNoAMT') {
        this.data.taxSelectorListItems = [
          { id: 'tax', name: 'Tax' },
          { id: 'depreciation', name: 'Depreciation' },
          { id: 'Book Depreciation', name: 'Book Depreciation' }
        ];
      } else {
        this.data.taxSelectorListItems = [{ id: 'tax', name: 'Tax' },
        { id: 'depreciation', name: 'Depreciation' }];
      }
      if (this.data.record.type === 'tax') {
        this.descriptionList = this.data.taxListItems;
      } else {
        this.descriptionList = this.data.deprListItems;
      }
      this.data.record.years = Math.round(this.data.record.years);
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  typeChange(event) {
    const type = event.value;
    if (type === 'tax') {
      this.descriptionList = this.data.taxListItems;
    } else {
      this.descriptionList = this.data.deprListItems;
    }
    this.data.record.description = '';
  }

  dateChange() {
    const startDate = this.data.record.startDate;
    const endDate = this.data.record.endDate;
    let period = 0;
    if (startDate && endDate) {
      period = Math.abs(
        new Date(startDate).getTime() - new Date(endDate).getTime()
      );
      this.data.record.years = Math.round(
        Math.ceil(period / (1000 * 3600 * 24) + 1) / 365
      );
    }
  }

  ngOnDestroy() {
    if (this.codDateSubscribe) {
      this.codDateSubscribe.unsubscribe();
    }
    if (this.currentCountryNameSubscribe) {
      this.currentCountryNameSubscribe.unsubscribe();
    }
  }
}
