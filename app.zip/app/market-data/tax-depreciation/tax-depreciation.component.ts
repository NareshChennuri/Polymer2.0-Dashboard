import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { combineLatest, Subscription } from 'rxjs';
import { AddTaxDeprDialogComponent } from './add-tax-depr/add-tax-depr-dialog.component';
import { EditTaxDeprDialogComponent } from './edit-tax-depr/edit-tax-depr-dialog.component';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';

export interface TaxDeprData {
  id: number;
  type: number;
  description: number;
  rate: number;
  escalation: number;
  startDate: object;
  endDate: object;
  years: number;
  lossCarryForward: number;
  PTC: number;
  recoveryMethod: string;
  actions: string;
}

@Component({
  selector: 'app-tax-depreciation',
  templateUrl: './tax-depreciation.component.html',
  styleUrls: ['./tax-depreciation.component.css']
})
export class TaxDepreciationComponent implements OnInit, OnDestroy {
  private getDropDownValuesSubscribe: Subscription;
  private combinedSubscribe: Subscription;
  private combinedCasesSubscribe: Subscription;
  private loadedCaseDataSubscribe: Subscription;
  private currentCountryNameSubscribe: Subscription;
  private countryChangeEmitterSubscribe: Subscription;
  private typeFilterSubscribe: Subscription;
  private descriptionFilterSubscribe: Subscription;
  private rateFilterSubscribe: Subscription;
  private escalationFilterSubscribe: Subscription;
  private startDateFilterSubscribe: Subscription;
  private endDateFilterSubscribe: Subscription;
  private yearsFilterSubscribe: Subscription;
  private lossCarryForwardFilterSubscribe: Subscription;
  private ptcFilterSubscribe: Subscription;
  private recoveryMethodFilterSubscribe: Subscription;
  private loadCaseSubscribe: Subscription;
  private selectedCaseInfoSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  private saveTaxDepreciationSubscribe: Subscription;
  private selectedCaseInfo2Subscribe: Subscription;
  private afterClosed2Subscribe: Subscription;
  private saveTaxDepreciation2Subscribe: Subscription;
  private afterClosed3Subscribe: Subscription;
  private deleteTaxDepreciationSubscribe: Subscription;
  country: string;
  caseData: any;
  selectedRowId: number;
  sessionId: any;
  userDetails: any;
  marketDataCaseId: any;
  marketDataSessionId: any;
  caseId: number;
  taxSelectorListItems: object = [];
  typeListItems = [];
  taxListItems = [];
  deprListItems = [];
  ptcListItems = [
    { id: '100', name: '100' },
    { id: '80', name: '80' },
    { id: '60', name: '60' },
    { id: '40', name: '40' },
    { id: '20', name: '20' },
    { id: '0', name: '0' }
  ];
  lossCarryForwardListItems = [
    { id: 'No', name: 'No' },
    { id: 'Yes', name: 'Yes' }
  ];
  defaultOption = 1;
  selectedRecord: TaxDeprData;
  displayedColumns: string[] = [
    'type',
    'description',
    'rate',
    'escalation',
    'startDate',
    'endDate',
    'years',
    'lossCarryForward',
    'ptc',
    'actions'
  ];
  dataSource = new MatTableDataSource<any>([]);

  typeFilter = new FormControl('');
  descriptionFilter = new FormControl('');
  rateFilter = new FormControl('');
  escalationFilter = new FormControl('');
  startDateFilter = new FormControl('');
  endDateFilter = new FormControl('');
  yearsFilter = new FormControl('');
  lossCarryForwardFilter = new FormControl('');
  ptcFilter = new FormControl('');
  recoveryMethodFilter = new FormControl('');

  filterValues = {
    type: '',
    description: '',
    rate: '',
    escalation: '',
    startDate: '',
    endDate: '',
    years: '',
    lossCarryForward: '',
    ptc: '',
    recoveryMethod: ''
  };

  @ViewChild(MatSort) sort: MatSort;

  constructor(
    public dialog: MatDialog,
    private dataService: DataService,
    private globals: GlobalsService,
    private toastr: ToastrService
  ) {
    this.getDropDownValuesByKey('tax_description');
    this.getDropDownValuesByKey('depr_description');
    this.getDropDownValuesByKey('tax_depr_details_type');
  }

  getDropDownValuesByKey(key: string) {
    const postData = {
      key
    };
    this.getDropDownValuesSubscribe = this.dataService
      .getDropDownValues(postData)
      .subscribe(dropdownList => {
        const dataList = [];
        if (dropdownList.length) {
          for (const data of dropdownList) {
            dataList.push({ id: data.value, name: data.displayName });
          }
        }
        if (key === 'tax_description') {
          this.taxListItems = dataList;
          this.typeListItems = this.taxListItems.concat(this.deprListItems);
        }
        if (key === 'depr_description') {
          this.deprListItems = dataList;
          this.typeListItems = this.taxListItems.concat(this.deprListItems);
        }
        if (key === 'tax_depr_details_type') {
          this.taxSelectorListItems = dataList;
        }
      });
  }

  ngOnInit() {
    this.dataSource.sort = this.sort;
    this.processFilter();
    const currentUser$ = this.globals.currentUser;
    const curretSession$ = this.globals.currentSession;
    const loadedCaseData$ = this.globals.loadedCaseData;
    const selectedCaseId$ = this.globals.selectedCaseId;
    const casesList$ = this.globals.listOfCases;
    const combined = combineLatest(currentUser$, curretSession$);
    const combinedCases = combineLatest(casesList$, selectedCaseId$);

    this.combinedSubscribe = combined.subscribe(([userDtls, sessionId]) => {
      this.userDetails = userDtls;
      this.sessionId = sessionId;
      // this.getTaxList();
    });

    this.combinedCasesSubscribe = combinedCases.subscribe(([caseList, caseId]) => {
      this.marketDataCaseId = caseId;
      if (caseList && Array.isArray(caseList)) {
        const filterdList = caseList.filter(cs => cs.id === caseId);
        if (filterdList.length) {
          this.marketDataSessionId = filterdList[0].sessionId;
        }
      }
    });

    this.loadedCaseDataSubscribe = loadedCaseData$.subscribe(caseData => {
      if (caseData && caseData.taxDeprDetails) {
        this.processTaxInfo(caseData.taxDeprDetails);
      }
    });

    this.currentCountryNameSubscribe = this.globals.currentCountryName.subscribe(
      country => {
        this.country = country;
      }
    );

    this.countryChangeEmitterSubscribe = this.globals.countryChangeEmitter.subscribe(
      () => {
        this.dataSource = new MatTableDataSource<any>([]);
      }
    );
  }

  processFilter() {
    this.dataSource.filterPredicate = this.createFilter();
    this.dataSource.sort = this.sort;

    this.typeFilterSubscribe = this.typeFilter.valueChanges.subscribe(type => {
      this.filterValues.type = type;
      this.dataSource.filter = JSON.stringify(this.filterValues);
    });

    this.descriptionFilterSubscribe = this.descriptionFilter.valueChanges.subscribe(
      description => {
        this.filterValues.description = description;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.rateFilterSubscribe = this.rateFilter.valueChanges.subscribe(rate => {
      this.filterValues.rate = rate;
      this.dataSource.filter = JSON.stringify(this.filterValues);
    });

    this.escalationFilterSubscribe = this.escalationFilter.valueChanges.subscribe(
      escalation => {
        this.filterValues.escalation = escalation;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.startDateFilterSubscribe = this.startDateFilter.valueChanges.subscribe(
      startDate => {
        this.filterValues.startDate = startDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.endDateFilterSubscribe = this.endDateFilter.valueChanges.subscribe(
      endDate => {
        this.filterValues.endDate = endDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.yearsFilterSubscribe = this.yearsFilter.valueChanges.subscribe(
      years => {
        this.filterValues.years = years;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.lossCarryForwardFilterSubscribe = this.lossCarryForwardFilter.valueChanges.subscribe(
      lossCarryForward => {
        this.filterValues.lossCarryForward = lossCarryForward;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.ptcFilterSubscribe = this.ptcFilter.valueChanges.subscribe(ptc => {
      this.filterValues.ptc = ptc;
      this.dataSource.filter = JSON.stringify(this.filterValues);
    });

    this.recoveryMethodFilterSubscribe = this.recoveryMethodFilter.valueChanges.subscribe(
      recoveryMethod => {
        this.filterValues.recoveryMethod = recoveryMethod;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
  }

  createFilter(): (data: any, filter: string) => boolean {
    const filterFunction = function(data, filter): boolean {
      const searchTerms = JSON.parse(filter);
      return (
        data.type
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.type) !== -1 &&
        data.description
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.description) !== -1 &&
        data.rate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.rate) !== -1 &&
        data.escalation
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.escalation) !== -1 &&
        data.startDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.startDate) !== -1 &&
        data.endDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.endDate) !== -1 &&
        data.years
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.years) !== -1 &&
        data.lossCarryForward
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.lossCarryForward) !== -1 &&
        data.ptc
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.ptc) !== -1 &&
        data.recoveryMethod
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.recoveryMethod) !== -1
      );
    };
    return filterFunction;
  }

  getTaxList() {
    const loadCaseReq = {
      caseId: this.caseData.id,
      sessionId: this.caseData.sessionId
    };
    this.loadCaseSubscribe = this.dataService
      .loadCase(loadCaseReq)
      .subscribe(result => {
        if (result) {
          this.globals.updateLoadedCaseData(result);
        }
      });
  }
  processTaxInfo(taxInfo) {
    const taxData = taxInfo.map(item => {
      item = {
        ...item,
        id: item.taxId || 0,
        type: item.type || '',
        description: item.description || '',
        rate: item.rate || 0,
        escalation: item.escalation || '',
        startDate: item.startDate ? item.startDate : '',
        endDate: item.endDate ? item.endDate : '',
        years: item.years || 0,
        lossCarryForward: item.lossCarryForward || '',
        ptc: item.ptc || '',
        recoveryMethod: item.recoveryMethod || '',
        actions: ''
      };
      return item;
    });
    this.dataSource.data = taxData;
  }

  addTaxDepreciation(dataSource) {
    if (!this.marketDataCaseId) {
      this.toastr.error(`Please Select/Create Case Item to proceed.`);
      return false;
    }
    this.selectedCaseInfoSubscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );
    if (
      this.caseData.accessMode &&
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted.`);
      return false;
    }
    const data = {};
    const record = {
      type: '',
      description: '',
      rate: '',
      escalation: '',
      startDate: '',
      endDate: '',
      years: '',
      lossCarryForward: '',
      ptc: '',
      recoveryMethod: ''
    };
    data['record'] = record;
    data['taxSelectorListItems'] = this.taxSelectorListItems;
    data['taxListItems'] = this.taxListItems;
    data['deprListItems'] = this.deprListItems;
    data['ptcListItems'] = this.ptcListItems;
    data['lossCarryForwardListItems'] = this.lossCarryForwardListItems;
    data['defaultOption'] = this.defaultOption;
    const dialogRef = this.dialog.open(AddTaxDeprDialogComponent, {
      width: '1100px',
      data: data
    });
    this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
      this.selectedRowId = null;
      if (result) {
        if (result.record.description === 'ptc') {
          result.record.lossCarryForward = '';
        } else {
          result.record.ptc = '';
          result.record.escalation = '';
        }
        if (result.record.type === 'depreciation') {
          result.record.escalation = '';
          result.record.lossCarryForward = '';
          result.record.ptc = '';
          result.record.rate = result.record.type === 'depreciation' && result.record.description === 'Declining Balance' ? result.record['rate'] : 0;
          result.record.recoveryMethod = '';
        }
        result.record['createdBy'] = this.userDetails.userId;
        result.record['createdDate'] = new Date();
        result.record['updatedBy'] = this.userDetails.userId;
        result.record['marketDataCaseId'] = this.marketDataCaseId;
        result.record['updatedDate'] = new Date();
        result.record['caseId'] = this.marketDataCaseId;
        result.record['sessionId'] = this.marketDataSessionId;
        result.record['taxId'] = 0;
        result.record['startDate'] = this.globals.removeTimeZone(
          result.record['startDate']
        );
        result.record['endDate'] = this.globals.removeTimeZone(
          result.record['endDate']
        );
        result.record['ptcPercentage'] = result.record['ptc'];
        this.saveTaxDepreciationSubscribe = this.dataService
          .saveTaxDepreciation(result.record)
          .subscribe(saveStatus => {
            if (saveStatus.message) {
              this.toastr.success(`${saveStatus.message} !!`);
            }
            this.getTaxList();
          });
      }
    });
  }

  openActionDialog(id: number, flag: string) {
    this.selectedCaseInfo2Subscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );
    if (
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted. `);
      return false;
    }
    this.selectedRowId = id;
    if (flag === 'edit') {
      const data = {};
      const record = this.dataSource.data.filter(obj => {
        return obj.id === id;
      })[0];
      this.selectedRecord = { ...record };
      record.ptc = record.ptc + '';
      data['record'] = record;
      data['record']['startDate'] = this.globals.returnFormattedDate(
        record.startDate
      );
      data['record']['endDate'] = this.globals.returnFormattedDate(
        record.endDate
      );
      data['action'] = flag;
      data['taxSelectorListItems'] = this.taxSelectorListItems;
      data['taxListItems'] = this.taxListItems;
      data['deprListItems'] = this.deprListItems;
      data['ptcListItems'] = this.ptcListItems;
      data['lossCarryForwardListItems'] = this.lossCarryForwardListItems;
      data['record']['escalation'] = record.escalation || 0;
      const dialogRef = this.dialog.open(EditTaxDeprDialogComponent, {
        width: '1100px',
        data: data
      });
      this.afterClosed2Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          if (result.record.description === 'ptc') {
            result.record.lossCarryForward = '';
          } else {
            result.record.ptc = '';
            result.record.escalation = '';
          }
          if (result.record.type === 'depreciation') {
            result.record.escalation = '';
            result.record.lossCarryForward = '';
            result.record.ptc = '';
            result.record.rate = result.record.type === 'depreciation' && result.record.description === 'Declining Balance' ? result.record['rate'] : 0;
            result.record.recoveryMethod = '';
          }
          result.record['createdBy'] = this.userDetails.userId;
          result.record['updatedBy'] = this.userDetails.userId;
          result.record['marketDataCaseId'] = this.marketDataCaseId;
          result.record['updatedDate'] = new Date();
          result.record['caseId'] = this.marketDataCaseId;
          result.record['sessionId'] = this.marketDataSessionId;
          result.record['finanaceId'] = result.record.id;
          result.record['ptcPercentage'] = result.record['ptc'];
          this.saveTaxDepreciation2Subscribe = this.dataService
            .saveTaxDepreciation(result.record)
            .subscribe(editStatus => {
              if (editStatus.message) {
                this.toastr.success(`${editStatus.message} !!`);
              }
              this.getTaxList();
            });
        }
        if (!result) {
          const dataSource = this.dataSource.data.map(obj => {
            if (obj.id === id) {
              obj = this.selectedRecord;
            }
            return obj;
          });
          this.dataSource.data = dataSource;
        }
      });
    }
    if (flag === 'delete') {
      const record = { id, action: flag };
      const dialogRef = this.dialog.open(EditTaxDeprDialogComponent, {
        width: '300px',
        data: record
      });
      this.afterClosed3Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          this.deleteTaxDepreciationSubscribe = this.dataService
            .deleteTaxDepreciation({ taxId: id })
            .subscribe(deleteStatus => {
              if (deleteStatus.taxId) {
                this.toastr.success(`Item deleted successfully!!`);
              }
              this.getTaxList();
            });
        }
      });
    }
  }
  ngOnDestroy() {
    if (this.getDropDownValuesSubscribe) {
      this.getDropDownValuesSubscribe.unsubscribe();
    }
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.combinedCasesSubscribe) {
      this.combinedCasesSubscribe.unsubscribe();
    }
    if (this.loadedCaseDataSubscribe) {
      this.loadedCaseDataSubscribe.unsubscribe();
    }
    if (this.currentCountryNameSubscribe) {
      this.currentCountryNameSubscribe.unsubscribe();
    }
    if (this.countryChangeEmitterSubscribe) {
      this.countryChangeEmitterSubscribe.unsubscribe();
    }
    if (this.typeFilterSubscribe) {
      this.typeFilterSubscribe.unsubscribe();
    }
    if (this.descriptionFilterSubscribe) {
      this.descriptionFilterSubscribe.unsubscribe();
    }
    if (this.rateFilterSubscribe) {
      this.rateFilterSubscribe.unsubscribe();
    }
    if (this.escalationFilterSubscribe) {
      this.escalationFilterSubscribe.unsubscribe();
    }
    if (this.startDateFilterSubscribe) {
      this.startDateFilterSubscribe.unsubscribe();
    }
    if (this.endDateFilterSubscribe) {
      this.endDateFilterSubscribe.unsubscribe();
    }
    if (this.yearsFilterSubscribe) {
      this.yearsFilterSubscribe.unsubscribe();
    }
    if (this.lossCarryForwardFilterSubscribe) {
      this.lossCarryForwardFilterSubscribe.unsubscribe();
    }
    if (this.ptcFilterSubscribe) {
      this.ptcFilterSubscribe.unsubscribe();
    }
    if (this.recoveryMethodFilterSubscribe) {
      this.recoveryMethodFilterSubscribe.unsubscribe();
    }
    if (this.loadCaseSubscribe) {
      this.loadCaseSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfoSubscribe) {
      this.selectedCaseInfoSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
    if (this.saveTaxDepreciationSubscribe) {
      this.saveTaxDepreciationSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfo2Subscribe) {
      this.selectedCaseInfo2Subscribe.unsubscribe();
    }
    if (this.afterClosed2Subscribe) {
      this.afterClosed2Subscribe.unsubscribe();
    }
    if (this.saveTaxDepreciation2Subscribe) {
      this.saveTaxDepreciation2Subscribe.unsubscribe();
    }
    if (this.afterClosed3Subscribe) {
      this.afterClosed3Subscribe.unsubscribe();
    }
    if (this.deleteTaxDepreciationSubscribe) {
      this.deleteTaxDepreciationSubscribe.unsubscribe();
    }
  }
}
