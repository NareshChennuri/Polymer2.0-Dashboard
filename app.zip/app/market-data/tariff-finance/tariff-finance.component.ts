import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TariffFinanceEditDialogComponent } from './tariff-finance-edit/tariff-finance-edit-dialog.component';
import { AddTariffFinanceDialogComponent } from './add-tariff-finance/add-tariff-finance-dialog.component';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';
import { combineLatest, Subscription } from 'rxjs';

export interface TariffFinanceData {
  id: number;
  debtOption: string;
  startDate: object;
  endDate: object;
  financeSelector: string;
  uomSelector: string;
  debtTenor: number;
  rateOfInterest: number;
  actions: string;
}

@Component({
  selector: 'app-tariff-finance',
  templateUrl: './tariff-finance.component.html',
  styleUrls: ['./tariff-finance.component.css']
})
export class TariffFinanceComponent implements OnInit, OnDestroy {
  private combinedSubscribe: Subscription;
  private combinedCasesSubscribe: Subscription;
  private loadedCaseDataSubscribe: Subscription;
  private countryChangeEmitterSubscribe: Subscription;
  private debtOptionFilterSubscribe: Subscription;
  private startDateFilterSubscribe: Subscription;
  private endDateFilterSubscribe: Subscription;
  private financeSelectorFilterSubscribe: Subscription;
  private uomSelectorFilterSubscribe: Subscription;
  private debtTenorFilterSubscribe: Subscription;
  private rateOfInterestFilterSubscribe: Subscription;
  private loadCaseSubscribe: Subscription;
  private selectedCaseInfoSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  private saveFinanceRecordSubscribe: Subscription;
  private selectedCaseInfo2Subscribe: Subscription;
  private afterClosed2Subscribe: Subscription;
  private saveFinanceRecord2Subscribe: Subscription;
  private afterClosed3Subscribe: Subscription;
  private deleteFinanceRecordSubscribe: Subscription;
  caseData: any;
  sessionId: any;
  userDetails: any;
  caseId: any;
  marketDataCaseId: any;
  marketDataSessionId: any;
  selectedRowId: number;
  financeSelectorListItems: object[] = [];
  uomSelectorListItems: object = [];
  defaultOption = 1;
  selectedRecord: TariffFinanceData;
  displayedColumns: string[] = [
    'debtOption',
    'startDate',
    'endDate',
    'financeSelector',
    'uomSelector',
    'debtTenor',
    'rateOfInterest',
    'actions'
  ];
  dataSource = new MatTableDataSource<any>([]);
  @ViewChild(MatSort) sort: MatSort;

  debtOptionFilter = new FormControl('');
  startDateFilter = new FormControl('');
  endDateFilter = new FormControl('');
  financeSelectorFilter = new FormControl('');
  uomSelectorFilter = new FormControl('');
  debtTenorFilter = new FormControl('');
  rateOfInterestFilter = new FormControl('');

  filterValues = {
    debtOption: '',
    startDate: '',
    endDate: '',
    financeSelector: '',
    uomSelector: '',
    debtTenor: '',
    rateOfInterest: ''
  };

  constructor(
    public dialog: MatDialog,
    private dataService: DataService,
    private globals: GlobalsService,
    private toastr: ToastrService
  ) {
    this.caseId = 1;
    this.getDropDownValuesByKey('finance_details_finance_selector');
    this.getDropDownValuesByKey('finance_details_uom_selector');
  }

  getDropDownValuesByKey(key: string) {
    let dropdownList = [];
    const dataList = [];
    if (key === 'finance_details_finance_selector') {
      dropdownList = [
        {
          referenceId: 13,
          key: 'finance_details_finance_selector',
          value: 'mortage',
          displayName: 'Mortage',
          active: true,
          createdBy: 503106665,
          createdDate: null,
          updatedBy: null,
          updatedDate: null
        },
        {
          referenceId: 13,
          key: 'finance_details_finance_selector',
          value: 'buildersRiskInsurance',
          displayName: 'Builders Risk Insurance',
          active: true,
          createdBy: 503106665,
          createdDate: null,
          updatedBy: null,
          updatedDate: null
        }
      ];
    }
    if (key === 'finance_details_uom_selector') {
      dropdownList = [
        {
          referenceId: 67,
          key: 'finance_details_uom_selector',
          value: 'perc',
          displayName: '% Per',
          active: true,
          createdBy: 503106665,
          createdDate: null,
          updatedBy: null,
          updatedDate: null
        }
      ];
    }
    if (dropdownList.length) {
      for (const data of dropdownList) {
        dataList.push({ id: data.value, name: data.displayName });
      }
    }
    if (key === 'finance_details_finance_selector') {
      this.financeSelectorListItems = dataList;
    }
    if (key === 'finance_details_uom_selector') {
      this.uomSelectorListItems = dataList;
    }
  }

  ngOnInit() {
    this.processFilters();
    const currentUser$ = this.globals.currentUser;
    const curretSession$ = this.globals.currentSession;
    const loadedCaseData$ = this.globals.loadedCaseData;
    const selectedCaseId$ = this.globals.selectedCaseId;
    const casesList$ = this.globals.listOfCases;
    const combined = combineLatest(currentUser$, curretSession$);
    const combinedCases = combineLatest(casesList$, selectedCaseId$);

    this.combinedSubscribe = combined.subscribe(([userDtls, sessionId]) => {
      this.userDetails = userDtls;
      this.sessionId = sessionId;
      // this.getFinanceRecordList();
    });
    this.combinedCasesSubscribe = combinedCases.subscribe(([caseList, caseId]) => {
      this.marketDataCaseId = caseId;
      if (caseList && Array.isArray(caseList)) {
        const filterdList = caseList.filter(cs => cs.id === caseId);
        if (filterdList.length) {
          this.marketDataSessionId = filterdList[0].sessionId;
        }
      }
    });
    this.loadedCaseDataSubscribe = loadedCaseData$.subscribe(caseData => {
      if (caseData && caseData.financeDetails) {
        this.processRevenueInfo(caseData.financeDetails);
      }
    });

    this.countryChangeEmitterSubscribe = this.globals.countryChangeEmitter.subscribe(
      () => {
        this.dataSource = new MatTableDataSource<any>([]);
      }
    );
  }

  processFilters() {
    this.dataSource.filterPredicate = this.createFilter();
    this.dataSource.sort = this.sort;
    this.debtOptionFilterSubscribe = this.debtOptionFilter.valueChanges.subscribe(
      debtOption => {
        this.filterValues.debtOption = debtOption;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.startDateFilterSubscribe = this.startDateFilter.valueChanges.subscribe(
      startDate => {
        this.filterValues.startDate = startDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.endDateFilterSubscribe = this.endDateFilter.valueChanges.subscribe(
      endDate => {
        this.filterValues.endDate = endDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.financeSelectorFilterSubscribe = this.financeSelectorFilter.valueChanges.subscribe(
      financeSelector => {
        this.filterValues.financeSelector = financeSelector;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.uomSelectorFilterSubscribe = this.uomSelectorFilter.valueChanges.subscribe(
      uomSelector => {
        this.filterValues.uomSelector = uomSelector;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.debtTenorFilterSubscribe = this.debtTenorFilter.valueChanges.subscribe(
      debtTenor => {
        this.filterValues.debtTenor = debtTenor;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.rateOfInterestFilterSubscribe = this.rateOfInterestFilter.valueChanges.subscribe(
      rateOfInterest => {
        this.filterValues.rateOfInterest = rateOfInterest;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
  }

  createFilter(): (data: any, filter: string) => boolean {
    const filterFunction = function(data, filter): boolean {
      const searchTerms = JSON.parse(filter);
      return (
        data.debtOption
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.debtOption) !== -1 &&
        data.startDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.startDate) !== -1 &&
        data.endDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.endDate) !== -1 &&
        data.financeSelector
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.financeSelector) !== -1 &&
        data.uomSelector
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.uomSelector) !== -1 &&
        data.debtTenor
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.debtTenor) !== -1 &&
        data.rateOfInterest
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.rateOfInterest) !== -1
      );
    };
    return filterFunction;
  }

  getFinanceRecordList() {
    const loadCaseReq = {
      caseId: this.caseData.id,
      sessionId: this.caseData.sessionId
    };
    this.loadCaseSubscribe = this.dataService
      .loadCase(loadCaseReq)
      .subscribe(result => {
        if (result) {
          this.globals.updateLoadedCaseData(result);
        }
      });
  }
  processRevenueInfo(revenueInfo) {
    const revenueData = revenueInfo.map(item => {
      item = {
        ...item,
        id: item.financeId || 0,
        debtOption: item.debtOption || '',
        startDate: item.startDate ? item.startDate : '',
        endDate: item.endDate ? item.endDate : '',
        financeSelector: item.financeSelector || '',
        uomSelector: item.uomSelector || '',
        debtTenor: item.debtTenor || '',
        rateOfInterest: item.rateOfInterest || '',
        actions: ''
      };
      return item;
    });
    this.dataSource.data = revenueData;
  }

  addTariffFinance(dataSource) {
    if (!this.marketDataCaseId) {
      this.toastr.error(`Please Select/Create Case Item to Proceed. `);
      return false;
    }
    this.selectedCaseInfoSubscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );
    if (
      this.caseData.accessMode &&
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted.`);
      return false;
    }
    const data = {};
    const record = {
      debtOption: '',
      startDate: '',
      endDate: '',
      financeSelector: '',
      uomSelector: '',
      debtTenor: '',
      rateOfInterest: ''
    };
    data['record'] = record;
    const buildersSelectorLength = this.dataSource.data.filter(
      fin => fin.financeSelector === 'buildersRiskInsurance'
    ).length;
    if (buildersSelectorLength > 0) {
      data['financeSelectorListItems'] = this.financeSelectorListItems.filter(
        finSelect => finSelect['id'] !== 'buildersRiskInsurance'
      );
    } else {
      data['financeSelectorListItems'] = this.financeSelectorListItems;
    }
    data['uomSelectorListItems'] = this.uomSelectorListItems;
    data['defaultOption'] = this.defaultOption;
    const dialogRef = this.dialog.open(AddTariffFinanceDialogComponent, {
      width: '1100px',
      data: data
    });
    this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
      this.selectedRowId = null;
      if (result) {
        result.record['uomValue'] = 0;
        result.record['createdDate'] = '';
        result.record['createdBy'] = this.userDetails.userId;
        result.record['updatedBy'] = this.userDetails.userId;
        result.record['marketDataCaseId'] = this.marketDataCaseId;
        result.record['updatedDate'] = new Date();
        result.record['caseId'] = this.marketDataCaseId;
        result.record['sessionId'] = this.marketDataSessionId;
        result.record['financeId'] = 0;
        result.record['startDate'] = this.globals.removeTimeZone(
          result.record['startDate']
        );
        result.record['endDate'] = this.globals.removeTimeZone(
          result.record['endDate']
        );

        this.saveFinanceRecordSubscribe = this.dataService
          .saveFinanceRecord(result.record)
          .subscribe(saveStatus => {
            if (saveStatus.message) {
              this.toastr.success(`${saveStatus.message} !!`);
            }
            this.getFinanceRecordList();
          });
      }
    });
  }

  openActionDialog(id: number, flag: string) {
    this.selectedCaseInfo2Subscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );
    if (
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted. `);
      return false;
    }
    this.selectedRowId = id;
    if (flag === 'edit') {
      const data = {};
      const record = this.dataSource.data.filter(obj => {
        return obj.id === id;
      })[0];
      this.selectedRecord = { ...record };
      data['record'] = record;
      data['record']['startDate'] = this.globals.returnFormattedDate(
        record.startDate
      );
      data['record']['endDate'] = this.globals.returnFormattedDate(
        record.endDate
      );
      data['action'] = flag;
      const buildersSelectorLength = this.dataSource.data.filter(
        fin => fin.financeSelector === 'buildersRiskInsurance'
      ).length;
      if (
        buildersSelectorLength > 0 &&
        record.financeSelector !== 'buildersRiskInsurance'
      ) {
        data['financeSelectorListItems'] = this.financeSelectorListItems.filter(
          finSelect => finSelect['id'] !== 'buildersRiskInsurance'
        );
      } else {
        data['financeSelectorListItems'] = this.financeSelectorListItems;
      }
      data['uomSelectorListItems'] = this.uomSelectorListItems;
      data['record']['debtTenor'] = record.debtTenor || 0;
      data['record']['rateOfInterest'] = record.rateOfInterest || 0;
      const dialogRef = this.dialog.open(TariffFinanceEditDialogComponent, {
        width: '1100px',
        data: data
      });
      this.afterClosed2Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          result.record['uomValue'] = 0;
          result.record['createdDate'] = '';
          result.record['createdBy'] = this.userDetails.userId;
          result.record['updatedBy'] = this.userDetails.userId;
          result.record['marketDataCaseId'] = this.marketDataCaseId;
          result.record['updatedDate'] = new Date();
          result.record['caseId'] = this.marketDataCaseId;
          result.record['sessionId'] = this.marketDataSessionId;
          result.record['financeId'] = result.record.id;
          this.saveFinanceRecord2Subscribe = this.dataService
            .saveFinanceRecord(result.record)
            .subscribe(editStatus => {
              if (editStatus.message) {
                this.toastr.success(`${editStatus.message} !!`);
              }
              this.getFinanceRecordList();
            });
        }
        if (!result) {
          const dataSource = this.dataSource.data.map(obj => {
            if (obj.id === id) {
              obj = this.selectedRecord;
            }
            return obj;
          });
          this.dataSource.data = dataSource;
        }
      });
    }
    if (flag === 'delete') {
      const record = { id, action: flag };
      const dialogRef = this.dialog.open(TariffFinanceEditDialogComponent, {
        width: '300px',
        data: record
      });
      this.afterClosed3Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          this.deleteFinanceRecordSubscribe = this.dataService
            .deleteFinanceRecord({ financeId: id })
            .subscribe(deleteStatus => {
              if (deleteStatus.financeId) {
                this.toastr.success(`Item deleted successfully!!`);
              }
              this.getFinanceRecordList();
            });
        }
      });
    }
  }

  ngOnDestroy() {
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.combinedCasesSubscribe) {
      this.combinedCasesSubscribe.unsubscribe();
    }
    if (this.loadedCaseDataSubscribe) {
      this.loadedCaseDataSubscribe.unsubscribe();
    }
    if (this.countryChangeEmitterSubscribe) {
      this.countryChangeEmitterSubscribe.unsubscribe();
    }
    if (this.debtOptionFilterSubscribe) {
      this.debtOptionFilterSubscribe.unsubscribe();
    }
    if (this.startDateFilterSubscribe) {
      this.startDateFilterSubscribe.unsubscribe();
    }
    if (this.endDateFilterSubscribe) {
      this.endDateFilterSubscribe.unsubscribe();
    }
    if (this.financeSelectorFilterSubscribe) {
      this.financeSelectorFilterSubscribe.unsubscribe();
    }
    if (this.uomSelectorFilterSubscribe) {
      this.uomSelectorFilterSubscribe.unsubscribe();
    }
    if (this.debtTenorFilterSubscribe) {
      this.debtTenorFilterSubscribe.unsubscribe();
    }
    if (this.rateOfInterestFilterSubscribe) {
      this.rateOfInterestFilterSubscribe.unsubscribe();
    }
    if (this.loadCaseSubscribe) {
      this.loadCaseSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfoSubscribe) {
      this.selectedCaseInfoSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
    if (this.saveFinanceRecordSubscribe) {
      this.saveFinanceRecordSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfo2Subscribe) {
      this.selectedCaseInfo2Subscribe.unsubscribe();
    }
    if (this.afterClosed2Subscribe) {
      this.afterClosed2Subscribe.unsubscribe();
    }
    if (this.saveFinanceRecord2Subscribe) {
      this.saveFinanceRecord2Subscribe.unsubscribe();
    }
    if (this.afterClosed3Subscribe) {
      this.afterClosed3Subscribe.unsubscribe();
    }
    if (this.deleteFinanceRecordSubscribe) {
      this.deleteFinanceRecordSubscribe.unsubscribe();
    }
  }
}
