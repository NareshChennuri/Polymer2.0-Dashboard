import {
  Component,
  Inject,
  OnInit,
  ViewChild,
  ElementRef,
  OnDestroy
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TariffFinanceComponent } from '../tariff-finance.component';
import { DataService } from '../../../shared/api/data.service';
import { GlobalsService } from '../../../shared/api/globals.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-tariff-finance-edit-dialog',
  templateUrl: 'tariff-finance-edit-dialog.component.html',
  styleUrls: ['./tariff-finance-edit-dialog.component.css']
})
export class TariffFinanceEditDialogComponent implements OnInit, OnDestroy {
  private constructionStartDateGlobalSubscribe: Subscription;
  codDate: string;
  @ViewChild('startDate') startDate: ElementRef;
  @ViewChild('picker2') endDate: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<TariffFinanceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _service: DataService,
    private globals: GlobalsService
  ) {}

  ngOnInit() {
    this.constructionStartDateGlobalSubscribe = this.globals.constructionStartDateGlobal.subscribe(
      date => {
        this.codDate = this.globals.returnFormattedDate(date);
      }
    );
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  dateChange() {
    const startDate = this.data.record.startDate;
    if (startDate) {
      this.endDate['disabled'] = false;
    }
  }

  onFinanceSelector(event) {
    if (event === 'buildersRiskInsurance') {
      this.data.record.debtTenor = 1.5;
    } else {
      this.data.record.debtTenor = '';
    }
  }

  ngOnDestroy() {
    this.constructionStartDateGlobalSubscribe.unsubscribe();
  }
}
