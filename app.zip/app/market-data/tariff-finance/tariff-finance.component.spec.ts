import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TariffFinanceComponent } from './tariff-finance.component';

describe('TariffFinanceComponent', () => {
  let component: TariffFinanceComponent;
  let fixture: ComponentFixture<TariffFinanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TariffFinanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TariffFinanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
