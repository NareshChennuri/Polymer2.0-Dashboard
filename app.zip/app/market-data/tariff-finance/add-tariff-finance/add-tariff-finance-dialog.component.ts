import {
  Component,
  Inject,
  OnInit,
  ViewChild,
  ElementRef,
  OnDestroy
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TariffFinanceComponent } from '../tariff-finance.component';
import { GlobalsService } from '../../../shared/api/globals.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-tariff-finance-dialog',
  templateUrl: 'add-tariff-finance-dialog.component.html',
  styleUrls: ['./add-tariff-finance-dialog.component.css']
})
export class AddTariffFinanceDialogComponent implements OnInit, OnDestroy {
  private constructionStartDateGlobalSubscribe: Subscription;
  codDate: Date;
  @ViewChild('startDate') startDate: ElementRef;
  @ViewChild('picker2') endDate: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<TariffFinanceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private globals: GlobalsService
  ) {}

  ngOnInit() {
    this.constructionStartDateGlobalSubscribe = this.globals.constructionStartDateGlobal.subscribe(
      date => {
        this.codDate = new Date(date);
      }
    );
    const year = this.codDate.getUTCFullYear();
    const month = this.codDate.getUTCMonth();
    const day = this.codDate.getUTCDate();
    this.data.record.endDate = new Date(year + 20, month, day - 1);
    this.data.record.startDate = this.codDate;
    this.dateChange();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  dateChange() {
    const startDate = this.data.record.startDate;
    if (startDate) {
      this.endDate['disabled'] = false;
    }
  }

  onFinanceSelector(event) {
    if (event === 'buildersRiskInsurance') {
      this.data.record.debtTenor = 1.5;
    } else {
      this.data.record.debtTenor = '';
    }
  }

  ngOnDestroy() {
    this.constructionStartDateGlobalSubscribe.unsubscribe();
  }
}
