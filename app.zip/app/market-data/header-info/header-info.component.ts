import {
  Component,
  OnInit,
  HostListener,
  Inject,
  AfterViewInit,
  OnDestroy
} from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { DOCUMENT } from '@angular/common';
import { combineLatest, Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material';
import {
  trigger,
  state,
  transition,
  style,
  animate
} from '@angular/animations';
import { Router } from '@angular/router';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';
import { userRoles } from '../../shared/app-constants';
import { ErrorCalculationDialogComponent } from './error-calculation-dialog/error-calculation-dialog.component';
import { GoalSeekComponent } from './goal-seek/goal-seek.component';

export interface InformationData {
  opportunityNo: number;
  opportunityName: string;
  country: number;
  state: number;
}
const ELEMENT_DATA: InformationData = {
  opportunityNo: 0,
  opportunityName: '',
  country: 0,
  state: 0
};
@Component({
  selector: 'app-header-info',
  templateUrl: './header-info.component.html',
  styleUrls: ['./header-info.component.css'],
  animations: [
    trigger('fade', [
      state('void', style({ opacity: 0 })),
      transition(':enter', [animate(300)]),
      transition(':leave', [animate(500)])
    ])
  ]
})
export class HeaderInfoComponent implements OnInit, AfterViewInit, OnDestroy {
  private combinedWpSubscribe: Subscription;
  private combinedSubscribe: Subscription;
  private countryInfoSubscribe: Subscription;
  private getCountriesListSubscribe: Subscription;
  private currentSessionSubscribe: Subscription;
  private getStatesListSubscribe: Subscription;
  private opportunityNoSubscribe: Subscription;
  private opportunityNameSubscribe: Subscription;
  private selectedCaseIdSubscribe: Subscription;
  private invokeLockStatusSubscribe: Subscription;
  private currentCountryNameSubscribe: Subscription;
  private listOfCasesSubscribe: Subscription;
  private getUserDetailsSubscribe: Subscription;
  private getStatesList2Subscribe: Subscription;
  private getCasesListSubscribe: Subscription;
  private clonePublicCaseSubscribe: Subscription;
  private saveSessionSubscribe: Subscription;
  private calculateAllSubscribe: Subscription;
  private getGoalSeekSubscribe: Subscription;
  private callErrorMsgAPISubscribe: Subscription;
  private cloneSessionSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  dataSource: any = ELEMENT_DATA;
  selectedPCList: any[] = [];
  countryListItems: any[] = [{ id: 0, countryName: 'Select' }];
  stateListItems: any[] = [{ stateId: 0, fullName: 'Select' }];
  opportunityNumber: FormControl = new FormControl(
    this.dataSource.opportunityNo,
    [Validators.required]
  );
  country: FormControl = new FormControl(this.dataSource.country, [
    Validators.required
  ]);
  selectedCountry: any;
  selectedState: any;
  currentUser: any;
  userRolesList: any = userRoles;
  userRole: any;
  windparkDetails: any;
  marketInfoData: any;
  projEconomicsData: any;
  projResultsData: any;
  currentSessionId: any;
  currentCaseId: any;
  sessionCases: any = [];

  saveDisable = false;
  selectedSession: any;
  countryCurrency: any;
  casesList: any;
  windselectId: any;
  calcError = false;
  calcErrorDetails: any = [];
  goalSeekDisable: boolean;
  goalSeekRequest: any = {};
  sessionInfo: any;
  userData: any;
  constructor(
    public dialog: MatDialog,
    private dataService: DataService,
    private globals: GlobalsService,
    private toastr: ToastrService,
    private router: Router,
    @Inject(DOCUMENT) document
  ) {}

  ngOnInit() {
    this.calcErrorDetails = [];
    this.calcError = false;

    this.globals.changeSelectedCaseId('');
    this.getCountriesListSubscribe = this.dataService
      .getCountriesList()
      .subscribe(countries => {
        countries.sort((a, b) =>
          a.countryName !== b.countryName
            ? a.countryName < b.countryName
              ? -1
              : 1
            : 0
        );
        this.countryListItems = [
          { id: 0, countryName: 'Select' },
          ...countries
        ];
      });

    const sessionInfo$ = this.globals.currentSession;
    const countryInfo$ = this.globals.currentCountry;
    const stateInfo$ = this.globals.currentState;
    const userInfo$ = this.globals.currentUser;
    const windParkInfo$ = this.globals.windParkData;
    const marketDataInfo$ = this.globals.marketInfoData;
    const projEconomicsData$ = this.globals.projEconomicsData;
    const projResultsData$ = this.globals.projResultsData;
    const selectedCaseId$ = this.globals.selectedCaseId;
    const opportunityNo$ = this.globals.opportunityNo;
    const opportunityName$ = this.globals.opportunityName;

    const combined = combineLatest(
      sessionInfo$,
      countryInfo$,
      stateInfo$,
      userInfo$
    );

    this.combinedSubscribe = combined.subscribe(
      ([sessionId, countryId, stateId, userInfo]) => {
        this.currentSessionId = sessionId;
        this.selectedCountry = countryId;
        this.selectedState = stateId;
        this.currentUser = userInfo;
        this.dataSource.country = countryId;
        this.dataSource.state = stateId;
        this.calcErrorDetails = [];
        this.calcError = false;

        const filteredRole = this.userRolesList.filter(
          role => role.roleId === userInfo.roleId
        );
        if (filteredRole.length > 0) {
          this.userRole = filteredRole[0].roleName;
        }
      }
    );

    this.countryInfoSubscribe = countryInfo$.subscribe(countryId => {
      this.selectedCountry = countryId;
      if (this.selectedCountry) {
        this.getStatesListSubscribe = this.dataService
          .getStatesList(this.selectedCountry)
          .subscribe(states => {
            states.sort((a, b) =>
              a.fullName !== b.fullName
                ? a.fullName < b.fullName
                  ? -1
                  : 1
                : 0
            );
            this.stateListItems = [{ id: 0, fullName: 'Select' }, ...states];
          });
      }
    });

    this.opportunityNoSubscribe = opportunityNo$.subscribe(opportunityNo => {
      this.dataSource.opportunityNo = opportunityNo;
    });

    this.opportunityNameSubscribe = opportunityName$.subscribe(
      opportunityName => {
        this.dataSource.opportunityName = opportunityName;
      }
    );

    this.selectedCaseIdSubscribe = selectedCaseId$.subscribe(caseId => {
      this.currentCaseId = caseId;
    });

    const combinedWp = combineLatest(
      windParkInfo$,
      marketDataInfo$,
      projResultsData$,
      projEconomicsData$
    );

    this.combinedWpSubscribe = combinedWp.subscribe(
      ([wpData, miData, prData, peData]) => {
        this.windparkDetails = wpData;
        this.marketInfoData = miData;
        this.marketInfoData = miData;
        this.projResultsData = prData;
        this.projEconomicsData = peData;
        this.goalSeekDisable = false;
        if (this.windparkDetails.length > 0) {
          this.windparkDetails.forEach(element => {
            if (element.selectedPCList.length > 1) {
              this.goalSeekDisable = true;
            }
          });
        }
      }
    );

    this.invokeLockStatusSubscribe = this.globals.invokeLockStatus.subscribe(
      () => {
        this.lockProcessing();
      }
    );

    this.currentSessionSubscribe = this.globals.currentSession.subscribe(
      sessionDetails => {
        this.selectedSession = sessionDetails;
        this.windselectId = sessionDetails;
      }
    );

    this.currentCountryNameSubscribe = this.globals.currentCountryName.subscribe(
      countryName => {
        if (countryName) {
          this.countryListItems.filter(result => {
            if (result && result.countryName === countryName) {
              this.countryCurrency = result.currency;
            }
          });
        }
      }
    );

    this.listOfCasesSubscribe = this.globals.listOfCases.subscribe(caseList => {
      if (caseList.length) {
        this.casesList = caseList;
      }
    });
  }

  ngAfterViewInit() {
    this.globals.sessionSaveInfo.subscribe(session => {
      this.sessionInfo = session;
      if (this.sessionInfo && this.sessionInfo.windselectMainInputs) {
        this.lockProcessing();
      }
    });

    this.globals.currentUser.subscribe(user => {
      this.userData = user;
      if (this.userData && this.userData.userId) {
        this.lockProcessing();
      }
    });
  }

  lockProcessing() {
    if (
      this.userData &&
      this.userData.userId &&
      this.sessionInfo &&
      this.sessionInfo.windselectMainInputs
    ) {
      if (
        this.sessionInfo.windselectMainInputs.lockstatus === 'Locked' &&
        this.sessionInfo.windselectMainInputs.lockedBy !== this.userData.userId
      ) {
        this.saveDisable = true;
      } else if (
        (this.sessionInfo.windselectMainInputs.createdBy ===
          this.userData.userId ||
          this.userData.roleId === 1) &&
        (this.sessionInfo.windselectMainInputs.lockedBy ===
          this.userData.userId ||
          this.sessionInfo.windselectMainInputs.lockstatus === 'UnLocked')
      ) {
        this.saveDisable = false;
      } else {
        const userDtls = {
          userId: this.sessionInfo.windselectMainInputs.createdBy
        };
        this.getUserDetailsSubscribe = this.dataService
          .getUserDetails(userDtls)
          .subscribe(userDetails => {
            if (userDetails.user && userDetails.user.roleId === 1) {
              this.saveDisable = true;
            }
          });
      }
    }
  }

  countryChange(cntryId) {
    this.globals.onCountryChange();
    this.selectedCountry = '';
    this.selectedState = '';
    this.globals.changeCountry('');
    this.globals.changeState('');
    this.calcErrorDetails = [];
    this.calcError = false;
    // this.globals.changeSelectedCaseId('');
    const countryId = parseInt(cntryId, 10);
    if (countryId > 0) {
      this.globals.changeCountry(countryId);
      this.getStatesList2Subscribe = this.dataService
        .getStatesList(countryId)
        .subscribe(statesList => {
          statesList.sort((a, b) =>
            a.fullName !== b.fullName ? (a.fullName < b.fullName ? -1 : 1) : 0
          );
          this.stateListItems = [
            { stateId: 0, fullName: 'Select' },
            ...statesList
          ];
        });
      // call defaults API for new sesssions
      const reqInfo = {
        countryId: countryId
      };

      this.countryListItems.filter(result => {
        if (result && result.id === countryId) {
          this.countryCurrency = result.currency;
        }
      });

      this.getCasesListSubscribe = this.dataService
        .getCasesList(reqInfo)
        .subscribe(caseListRes => {
          const caseList: any = caseListRes;
          if (caseListRes && caseListRes.length > 0) {
            this.sessionCases = caseList.map(caseItem => {
              const csItem = {
                ...caseItem,
                accessMode: caseItem.caseStatus
              };
              return csItem;
            });
            this.globals.changeCasesList(this.sessionCases);
          } else {
            this.sessionCases = [];
            this.globals.changeCasesList(this.sessionCases);
          }
        });
    }
  }

  stateChange($event) {
    this.selectedState = '';
    this.globals.changeState('');
    // console.log('Selected State ', $event.value);
    const stateId = parseInt($event.value, 10);
    if (stateId > 0) {
      this.globals.changeState(stateId);
    }
  }
  getErrorMessage(field: string) {
    let errorMessage = '';
    switch (field) {
      case 'opportunityNumber': {
        errorMessage = this.opportunityNumber.hasError('required')
          ? 'required *'
          : '';
        break;
      }
      case 'country': {
        errorMessage = this.country.hasError('required') ? 'required *' : '';
        break;
      }
    }
    return errorMessage;
  }

  saveSession($eve, flag) {
    this.calcErrorDetails = [];
    this.calcError = false;
    if (!this.selectedCountry) {
      this.toastr.error(`Please select Country & State to proceed. `);
      return false;
    }

    // Condition if no Turbines in Park
    let calcValidation = false;
    this.windparkDetails.filter(data => {
      if (data && !data.selectedPCList.length && !calcValidation) {
        calcValidation = true;
      }
    });
    if ((flag === 'calc' || flag === 'goal') && calcValidation) {
      this.toastr.error(`Atleast One Turbine Configuration must be added`);
    } else {
      /* Start: Case Versioning */
      // when clicks on calculate and the user is non admin
      if (
        (flag === 'calc' || flag === 'goal') &&
        this.currentUser.roleId !== 1
      ) {
        // get all the case ids from windPark
        const publicCases = [];
        this.windparkDetails.map(trbData => {
          if (publicCases.indexOf(trbData.caseId) === -1) {
            publicCases.push(trbData.caseId);
          }
        });
        const requestCaseData = [];
        // loop through the case ids and if the case is public send it for cloning
        publicCases.map(caseId => {
          if (caseId) {
            let caseData = {};
            // get the case details by caseId
            this.casesList.filter(item => {
              if (item.id === caseId) {
                caseData = item;
              }
            });
            // if it is a public case, then clone the case
            if (caseData['id'] && caseData['caseStatus'] === '0') {
              // call the api
              const requestData = {};
              requestData['caseId'] = caseData['id'];
              requestData['name'] = caseData['name'];
              requestData['sessionId'] = this.windselectId;
              requestData['createdBy'] = caseData['createdBy'];
              requestData['updatedBy'] = caseData['updatedBy'];
              requestData['roleId'] = this.currentUser.roleId;
              requestData['caseStatus'] = caseData['caseStatus'];
              requestData['countryId'] = this.selectedCountry;
              requestData['caseSessionId'] = caseData['sessionId'];
              requestData['currentSessionId'] = this.windselectId;
              requestData['requestBy'] = this.currentUser.userId;
              requestCaseData.push(requestData);
            }
          }
        });
        if (requestCaseData.length) {
          // call the clone api
          this.clonePublicCaseSubscribe = this.dataService
            .clonePublicCase(requestCaseData)
            .subscribe(caseDetails => {
              if (caseDetails.length) {
                caseDetails.map(caseObj => {
                  if (caseObj['oldCaseId']) {
                    this.windparkDetails = this.windparkDetails.map(
                      trbParkData => {
                        if (
                          trbParkData.caseId &&
                          trbParkData.caseId === +caseObj['oldCaseId']
                        ) {
                          trbParkData.caseId = caseObj['caseId'];
                        }
                        return trbParkData;
                      }
                    );
                  }
                });
                this.globals.changeWindParkData(this.windparkDetails);
                this.callCalcSave(flag);
              }
            });
        } else {
          this.callCalcSave(flag);
        }
      } else {
        this.callCalcSave(flag);
      }
      /* End: Case Versioning */
    }
  }

  removeDuplicates(myArr, prop) {
    return myArr.filter((obj, pos, arr) => {
      return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
  }

  callCalcSave(flag) {
    let windFarmInputs = [];
    const sessionId = this.currentSessionId;
    if (this.windparkDetails.length) {
      windFarmInputs = this.windparkDetails.map(wp => {
        if (!wp.caseId) {
          // this.toastr.error(`Please Select/Create Case Item to proceed.`);
          this.toastr.error(`Please Select Case For a Park to Proceed.`);
          return false;
        }

        const thisProjEconomics = this.projEconomicsData.filter(
          pr => pr.windfarmId === wp.parkId
        );
        const projEco =
          thisProjEconomics.length > 0 ? thisProjEconomics[0] : {};

        const thisProjResults = this.projResultsData.filter(
          pr => pr.windfarmId === wp.parkId
        );
        const projRes = thisProjResults.length > 0 ? thisProjResults[0] : {};
        const windselectParkData = {
          parkId: wp.parkId, // wp.windfarmId,
          windselectId: sessionId,
          parkName: wp.parkName,
          caseId: wp.caseId,
          studyPeriod: wp.studyPeriod,
          manufacturerId: wp.manufacturerId,
          vavghh: wp.vavghh,
          ncf: wp.ncf,
          lossFactor: wp.lossFactor,
          epc: wp.epc,
          parkGrossaep: wp.parkGrossaep,
          parkNetaep: wp.parkNetaep,
          wtgPrice: projEco.wtgPrice,
          siteQuality: wp.siteQuality,
          correctedTarrif: wp.correctedTarrif,
          bidValue: wp.bidValue,
          transportation: projEco.transportation,
          installCommCost: projEco.installCommCost,
          bopCost: projEco.bopCost,
          otherCapitalCost: projEco.otherCapitalCost,
          omDuring: projEco.omDuring,
          omPost: projEco.omPost,
          projectIrr: projRes.projectIrr,
          projectEquityIrr: projRes.projectEquityIrr,
          projectEquityNpv: projRes.projectEquityNpv,
          totalWtgPriceperMw: projRes.totalWtgPriceperMw,
          totalWtgPriceperMwh: projRes.totalWtgPriceperMwh,
          totalCapexperMw: projRes.totalCapexperMw,
          lcoeCentsperKwh: projRes.lcoeCentsperKwh,
          onmNpv: projRes.onmNpv,
          wtgpriceOnmpriceNpv: projRes.wtgpriceOnmpriceNpv,
          totalOnmpriceperMwh: projRes.totalOnmpriceperMwh,
          totalWtgpriceOnmpriceperMwh: projRes.totalWtgpriceOnmpriceperMwh,
          capexOpexperMwh: projRes.capexOpexperMwh,
          primary1: wp.primary1 ? 'true' : 'false',
          winner: wp.winner ? 'true' : 'false',
          reliable: wp.reliable ? 'true' : 'false',
          wtgPriceResults: 0,
          totalMw: parseFloat(
            document
              .getElementById('totalMW_' + wp.parkId)
              .innerHTML.split(':')[2]
              ? document
                  .getElementById('totalMW_' + wp.parkId)
                  .innerHTML.split(':')[2]
                  .trim()
              : ''
          ),
          parkComments: (<HTMLInputElement>(
            document.getElementById('parkComments_' + wp.parkId)
          )).value
        };
        const windselectTurbineInputs = [];
        const windselectTurbineResults = [];
        wp.selectedPCList.map(spc => {
          const wpItem = {
            windselectTurbineInputsId: spc.selectedPCId,
            turbineId: spc.turbineId,
            // parkId: wp.windfarmId,
            parkId: wp.parkId, // wp.windfarmId,
            windSelectId: sessionId,
            hubHeight: spc.hubHeight || 0,
            units: spc.units,
            maxRating: spc.maxRating,
            megaWatts: spc.megaWatts,
            installedCapacity: spc.units * spc.megaWatts,
            lossFactor: spc.lossFactor,
            uncertainty: spc.uncertainty,
            pvalue: spc.pvalue,
            configItemCost: 'wtg',
            configItemVal: 1000,
            configStartDate: '2019-03-04T06:52:09.473+0000',
            configEndDate: '2019-03-04T06:52:09.473+0000',
            unitsOfMeasure: 'MW',
            applyOn: 'perUnit'
          };
          const trbResItem = {
            windselectTurbineInputsId: spc.selectedPCId,
            grossAep: spc.grossAep, // wp.projGrossAep,
            netAep: spc.netAep, // wp.projNetAep,
            parkId: wp.parkId, // wp.windfarmId,
            windselectId: sessionId,
            turbineId: spc.turbineId,
            vavghh: spc.vavghh,
            ncf: spc.ncf
          };
          windselectTurbineInputs.push(wpItem);
          windselectTurbineResults.push(trbResItem);
        });

        return {
          windselectParkData,
          windselectTurbineInputs,
          windselectTurbineResults
        };
      });
    }
    const saveData = {
      windselectId: parseInt(sessionId, 10),
      windselectMainInputs: {
        windselectId: parseInt(sessionId, 10),
        countryId: this.selectedCountry,
        stateId: this.selectedState,
        mw: this.marketInfoData.mw,
        ppa: this.marketInfoData.ppa,
        targetirr: this.marketInfoData.targetirr,
        elevation: this.marketInfoData.elevation,
        vavg: this.marketInfoData.vavg,
        kfactor: this.marketInfoData.kfactor,
        airDensity: this.marketInfoData.airDensity,
        shear: this.marketInfoData.shear,
        measuredHeight: this.marketInfoData.measuredHeight,
        cti: this.marketInfoData.cti,
        longitude: this.marketInfoData.longitude,
        latitude: this.marketInfoData.latitude,
        projectScope: this.marketInfoData.projectScope,
        cod: this.marketInfoData.cod,
        createdBy: this.marketInfoData.createdBy || this.currentUser.userId,
        modifiedBy: this.currentUser.userId,
        groupname: 'fdgh',
        createdDate: this.marketInfoData.createdDate || new Date(),
        updatedDate: new Date(),
        projectYears: this.marketInfoData.projectYears,
        totalUnits: this.marketInfoData.totalUnits,
        totalMw: this.marketInfoData.totalMw,
        // sessionComments: 'Comments',
        opportunityNo: this.dataSource.opportunityNo,
        opportunityName: this.dataSource.opportunityName,
        lockedBy: this.currentUser.userId,
        lockedTime: new Date(),
        lockstatus: 'UnLocked',
        sessionComments: (<HTMLInputElement>(
          document.getElementById('sessionComments')
        )).value,
        averageWaterDepth: parseInt(this.marketInfoData.averageWaterDepth, 10),
        constructionStartDate: this.globals.returnFormattedDate(
          this.marketInfoData.constructionStartDate
        )
      },
      windFarmInputs
    };

    if (this.selectedCountry) {
      this.saveSessionSubscribe = this.dataService
        .saveSession(saveData)
        .subscribe(result => {
          const calculateAEP = {
            windselectId: sessionId
          };
          if (result) {
            this.toastr.success(result.message);
            const errorReq = {
              sessionId: sessionId
            };
            if (flag === 'calc' || flag === 'goal') {
              this.calculateAllSubscribe = this.dataService
                .calculateAll(calculateAEP)
                .subscribe(projResult => {
                  if (projResult) {
                    this.toastr.success(projResult.body);
                    this.globals.callSearchAPI();
                    this.callErrorMsgAPI(calculateAEP);
                    if (flag === 'goal') {
                      this.getGoalSeekSubscribe = this.dataService
                        .getGoalSeek(this.goalSeekRequest)
                        .subscribe(response => {
                          if (response && response.length > 0) {
                            this.globals.updateGoalSeekDetails(response);
                            this.toastr.success('Goal Seek updated');
                          } else {
                            this.toastr.error(
                              'Error in performing Goal Seek calculation'
                            );
                          }
                        });
                    }
                  } else {
                    this.toastr.error('Error in performing calculations..');
                    this.callErrorMsgAPI(calculateAEP);
                  }
                });
            }
          } else {
            this.toastr.error('Error in saving session, Please try again..');
          }
        });
      // this.unlockSession();
    } else {
      if (this.selectedCountry === '') {
        this.toastr.error('Please select Country');
      } else {
        this.toastr.error('Please select State');
      }
    }
  }

  callErrorMsgAPI(calculateAEP) {
    this.callErrorMsgAPISubscribe = this.dataService
      .callErrorMsgAPI(calculateAEP)
      .subscribe(errorResult => {
        if (errorResult && errorResult.length) {
          this.toastr.error('Errors in Calculation');
          this.calcErrorDetails = errorResult;
          this.calcError = true;
        } /* else {
        // TODO: Remove else block (for testing only)
        this.calcErrorDetails = [
          {
            sessionId: this.windselectId,
            errorMsg: 'Generated net AEP is negative',
            moduleKey: 'NET_AEP_TURBINE',
            moduleName: 'TURBINE NET AEP'
          },
          {
            sessionId: this.windselectId,
            errorMsg: 'b Generated net AEP is negative',
            moduleKey: 'NET_AEP_TURBINE',
            moduleName: 'TURBINE NET AEP'
          },
          {
            sessionId: this.windselectId,
            errorMsg: 'v Generated net AEP is negative',
            moduleKey: 'NET_AEP_TURBINE',
            moduleName: 'TURBINE NET AEP'
          }
        ];
        this.calcError = true;
      }*/
      });
  }

  showErrorDialogue() {
    this.dialog.open(ErrorCalculationDialogComponent, {
      width: '850px',
      data: this.calcErrorDetails
    });
  }

  cloneSession() {
    const cloneSession = {
      windselectId: this.currentSessionId,
      createdBy: this.currentUser.userId
    };
    this.cloneSessionSubscribe = this.dataService
      .cloneSession(cloneSession)
      .subscribe(result => {
        if (result) {
          const cloneSessionId =
            result.response.windSelectInputsPojo.windselectId;
          if (cloneSessionId) {
            this.toastr.success(
              `WindSELECT Session id :'${this.currentSessionId} successfully cloned to: ${cloneSessionId}`
            );
            this.globals.changeSesssion(cloneSessionId);
            this.globals.cloneSessionEmit(cloneSessionId);
            this.router.navigate(['/actions/', cloneSessionId]);
          } else {
            this.toastr.error('Error in cloning the session');
          }
        } else {
          this.toastr.error('Error in cloning the session');
        }
      });
    this.saveDisable = false;
  }

  processProforma() {
    const myurl = `/proforma-reports/${this.currentSessionId}`;
    this.router.navigateByUrl(myurl).then(e => {
      if (e) {
        console.log('Navigation is successful!');
      } else {
        console.log('Navigation has failed!');
      }
    });
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e) {
    if (window.pageYOffset > 80) {
      const element = document.getElementById('navbar');
      element.classList.add('sticky');
    } else {
      const element2 = document.getElementById('navbar');
      element2.classList.remove('sticky');
    }
  }

  onGoalSeekClick() {
    let flag = false;
    this.projResultsData.forEach(element => {
      if (
        element.projectIrr === -24.9 ||
        element.projectIrr === 99924 ||
        element.projectEquityIrr === -24.9 ||
        element.projectEquityIrr === 99924
      ) {
        this.toastr.error(
          `There was an error in your inputs. Please recheck Calculations for proper values`
        );
        flag = true;
        return;
      }
    });
    if (flag) {
      return;
    }
    const dialogRef = this.dialog.open(GoalSeekComponent, {
      width: '800px',
      data: 'Goal Seek'
    });
    this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.goalSeekRequest = {
          windselectId: parseInt(this.currentSessionId, 10),
          goalseekText: result.turbinePriceSelect.id,
          expectedOutputVal: result.price
        };
        if (this.goalSeekRequest) {
          this.saveSession(this.goalSeekRequest, 'goal');
          this.globals.updateGoalSeekLable(this.goalSeekRequest);
        }
      }
    });
  }

  ngOnDestroy() {
    if (this.getCountriesListSubscribe) {
      this.getCountriesListSubscribe.unsubscribe();
    }
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.countryInfoSubscribe) {
      this.countryInfoSubscribe.unsubscribe();
    }
    if (this.getStatesListSubscribe) {
      this.getStatesListSubscribe.unsubscribe();
    }
    if (this.combinedWpSubscribe) {
      this.combinedWpSubscribe.unsubscribe();
    }
    if (this.opportunityNoSubscribe) {
      this.opportunityNoSubscribe.unsubscribe();
    }
    if (this.opportunityNameSubscribe) {
      this.opportunityNameSubscribe.unsubscribe();
    }
    if (this.selectedCaseIdSubscribe) {
      this.selectedCaseIdSubscribe.unsubscribe();
    }
    if (this.invokeLockStatusSubscribe) {
      this.invokeLockStatusSubscribe.unsubscribe();
    }
    if (this.currentCountryNameSubscribe) {
      this.currentCountryNameSubscribe.unsubscribe();
    }
    if (this.listOfCasesSubscribe) {
      this.listOfCasesSubscribe.unsubscribe();
    }
    if (this.getUserDetailsSubscribe) {
      this.getUserDetailsSubscribe.unsubscribe();
    }
    if (this.getStatesList2Subscribe) {
      this.getStatesList2Subscribe.unsubscribe();
    }
    if (this.getCasesListSubscribe) {
      this.getCasesListSubscribe.unsubscribe();
    }
    if (this.clonePublicCaseSubscribe) {
      this.clonePublicCaseSubscribe.unsubscribe();
    }
    if (this.saveSessionSubscribe) {
      this.saveSessionSubscribe.unsubscribe();
    }
    if (this.calculateAllSubscribe) {
      this.calculateAllSubscribe.unsubscribe();
    }
    if (this.getGoalSeekSubscribe) {
      this.getGoalSeekSubscribe.unsubscribe();
    }
    if (this.callErrorMsgAPISubscribe) {
      this.callErrorMsgAPISubscribe.unsubscribe();
    }
    if (this.cloneSessionSubscribe) {
      this.cloneSessionSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
  }
}
