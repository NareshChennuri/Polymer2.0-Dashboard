import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HeaderInfoComponent } from '../header-info.component';

@Component({
  selector: 'app-error-calculation-dialog',
  templateUrl: './error-calculation-dialog.component.html',
  styleUrls: ['./error-calculation-dialog.component.css']
})
export class ErrorCalculationDialogComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<HeaderInfoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
