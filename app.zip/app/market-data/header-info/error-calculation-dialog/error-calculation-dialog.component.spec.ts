import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorCalculationDialogComponent } from './error-calculation-dialog.component';

describe('ErrorCalculationDialogComponent', () => {
  let component: ErrorCalculationDialogComponent;
  let fixture: ComponentFixture<ErrorCalculationDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErrorCalculationDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorCalculationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
