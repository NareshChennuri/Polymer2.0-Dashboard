import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-goal-seek',
  templateUrl: './goal-seek.component.html',
  styleUrls: ['./goal-seek.component.css']
})
export class GoalSeekComponent implements OnInit {
dataSource: any = {};
turbinePriceListItems:any = [{id: 'Equity IRR', name: 'Turbine Price to match target EQUITY IRR'},
{id: 'Project IRR', name: 'Turbine Price to match target Project IRR'}, 
{id: 'NPV', name: 'Turbine Price to match target NPV'}];
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.dataSource = {
      price: '',
      turbinePriceSelect: this.turbinePriceListItems[0]
    }
  }

}
