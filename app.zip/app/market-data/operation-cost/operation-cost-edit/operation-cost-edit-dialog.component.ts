import {
  Component,
  Inject,
  OnInit,
  OnDestroy,
  AfterViewInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OperationCostComponent } from '../operation-cost.component';
import { FormControl } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { DataService } from '../../../shared/api/data.service';
import { GlobalsService } from '../../../shared/api/globals.service';

@Component({
  selector: 'app-operation-cost-edit-dialog',
  templateUrl: 'operation-cost-edit-dialog.component.html',
  styleUrls: ['./operation-cost-edit-dialog.component.css']
})
export class OperationCostEditDialogComponent
  implements OnInit, OnDestroy, AfterViewInit {
  private codDateSubscribe: Subscription;
  codDate: string;
  type = new FormControl();
  options: string[];
  typeOptions: Observable<string[]>;
  @ViewChild('picker2') endDatePicker: ElementRef;
  @ViewChild('picker3') tariffStartDatePicker: ElementRef;
  @ViewChild('picker3') startDatePicker: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<OperationCostComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private globals: GlobalsService,
    private cdr: ChangeDetectorRef
  ) {
    this.options = data['typeList'];
    if (data.action === 'edit') {
      this.type.setValue(data.record.type);
    }
  }

  ngOnInit() {
    this.typeOptions = this.type.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
    this.codDateSubscribe = this.globals.codDate.subscribe(date => {
      this.codDate = this.globals.returnFormattedDate(date);
    });
    this.typeChange();
  }
  ngAfterViewInit(): void {
    this.tariffDateChange();
    this.typeChange();
    this.cdr.detectChanges();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  private _filter(value: string): string[] {
    if (value) {
      this.data.record.type = value;
    }
    const filterValue = value.toLowerCase();
    return this.options.filter(option =>
      option.toLowerCase().includes(filterValue)
    );
  }

  typeChange() {
    if (this.data.record) {
      if (
        [
          'Management Fees',
          'Independent Engineer',
          'Interconnect Service Charges'
        ].indexOf(this.data.record.type) !== -1
      ) {
        this.data.applyUnitListItems = [
          { id: '000s-yr-project', name: '000s/Yr/Project' }
        ];
      } else if (this.data.record.type === 'BOP O&M') {
        this.data.applyUnitListItems = [
          { id: '000s-yr-mw', name: '000s/Yr/MW' }
        ];
      } else if (this.data.record.type === 'Development Cost') {
        this.data.applyUnitListItems = [{ id: '000s', name: '000s' }];
      } else if (this.data.record.type === 'Decommisioning') {
        this.data.applyUnitListItems = [
          { id: '000s-project', name: '000s/Project' }
        ];
      } else if (
        this.data.record.type === 'Upfront Royalty / Land Lease Payment'
      ) {
        this.data.applyUnitListItems = [
          { id: 'percent-of-revenue', name: '% of Revenue' },
          { id: '000s-yr-project', name: '000s/Yr/Project' }
        ];
      } else {
        this.data.applyUnitListItems = [
          { id: '000s-yr-project', name: '000s/Yr/Project' }
        ];
      }
    }
  }

  dateChange() {
    const startDate = this.data.record.startDate;
    if (startDate) {
      this.endDatePicker['disabled'] = false;
      // if (
      //   this.data.record.tarriffGrowthChange &&
      //   this.data.record.tarriffGrowthChange.trim() !== '-None-'
      // ) {
      //   this.data.record.tarriffStartDate = startDate;
      // } else {
      //   this.data.record.tarriffStartDate = '';
      // }
    }
  }

  tarriffFrequencyOnChange(event) {
    if (event.value && event.value.trim() === '-None-') {
      this.tariffStartDatePicker['disabled'] = true;
      this.data.record.tarriffStartDate = '';
    } else {
      this.tariffStartDatePicker['disabled'] = false;
      this.data.record.tarriffStartDate = this.data.record.startDate;
    }
  }

  tariffDateChange() {
    if (
      this.data.record &&
      this.data.record.tarriffGrowthChange &&
      this.data.record.tarriffGrowthChange.trim() === '-None-'
    ) {
      this.startDatePicker['disabled'] = true;
      this.data.record.tarriffStartDate = '';
    }
  }

  ngOnDestroy() {
    if (this.codDateSubscribe) {
      this.codDateSubscribe.unsubscribe();
    }
  }
}
