import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OperationCostComponent } from './operation-cost.component';

describe('OperationCostComponent', () => {
  let component: OperationCostComponent;
  let fixture: ComponentFixture<OperationCostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OperationCostComponent]
    }).compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(OperationCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
