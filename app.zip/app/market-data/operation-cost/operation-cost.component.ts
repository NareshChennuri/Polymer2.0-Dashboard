import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { combineLatest, Subscription } from 'rxjs';
import { OperationCostEditDialogComponent } from './operation-cost-edit/operation-cost-edit-dialog.component';
import { AddOperationCostDialogComponent } from './add-operation-cost/add-operation-cost-dialog.component';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';

export interface OperationCostData {
  id: number;
  type: string;
  startDate: object;
  endDate: object;
  price: number;
  frequency: number;
  applyUnit: number;
  tarriffGrowthValue: number;
  tarriffGrowthChange: number;
  tarriffStartDate: object;
  actions: string;
}

@Component({
  selector: 'app-operation-cost',
  templateUrl: './operation-cost.component.html',
  styleUrls: ['./operation-cost.component.css']
})
export class OperationCostComponent implements OnInit, OnDestroy {
  private getDropDownValuesSubscribe: Subscription;
  private combinedSubscribe: Subscription;
  private combinedCasesSubscribe: Subscription;
  private loadedCaseDataSubscribe: Subscription;
  private countryChangeEmitterSubscribe: Subscription;
  private typeFilterSubscribe: Subscription;
  private startDateFilterSubscribe: Subscription;
  private endDateFilterSubscribe: Subscription;
  private priceFilterSubscribe: Subscription;
  private frequencyFilterSubscribe: Subscription;
  private applyUnitFilterSubscribe: Subscription;
  private tarriffGrowthValueFilterSubscribe: Subscription;
  private tarriffGrowthChangeFilterSubscribe: Subscription;
  private tarriffStartDateFilterSubscribe: Subscription;
  private propertyTaxBasisFilterSubscribe: Subscription;
  private propertyTaxBasisDeclineFilterSubscribe: Subscription;
  private propertyTaxEndingBasisFilterSubscribe: Subscription;
  private propertyTaxAbatementFilterSubscribe: Subscription;
  private propertyTaxYearsFilterSubscribe: Subscription;
  private loadCaseSubscribe: Subscription;
  private selectedCaseInfoSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  private saveProjectOperatingCostRecordSubscribe: Subscription;
  private selectedCaseInfo2Subscribe: Subscription;
  private afterClosed2Subscribe: Subscription;
  private saveProjectOperatingCostRecord2Subscribe: Subscription;
  private afterClosed3Subscribe: Subscription;
  private deleteProjectOperatingCostRecordSubscribe: Subscription;
  caseData: any;
  selectedRowId: number;
  sessionId: any;
  userDetails: any;
  marketDataCaseId: any;
  marketDataSessionId: any;
  typeList: string[] = [];
  frequencyListItems: object = [];
  applyUnitListItems: object = [];
  tarriffGrowthChangeListItems: object = [];
  defaultOption = 1;
  selectedRecord: OperationCostData;
  displayedColumns: string[] = [
    'type',
    'startDate',
    'endDate',
    'price',
    'frequency',
    'applyUnit',
    'tarriffGrowthValue',
    'tarriffGrowthChange',
    'tarriffStartDate',
    'propertyTaxBasis',
    'propertyTaxBasisDecline',
    'propertyTaxEndingBasis',
    'propertyTaxAbatement',
    'propertyTaxYears',
    'actions'
  ];
  dataSource = new MatTableDataSource<any>([]);

  typeFilter = new FormControl('');
  startDateFilter = new FormControl('');
  endDateFilter = new FormControl('');
  priceFilter = new FormControl('');
  frequencyFilter = new FormControl('');
  applyUnitFilter = new FormControl('');
  tarriffGrowthValueFilter = new FormControl('');
  tarriffGrowthChangeFilter = new FormControl('');
  tarriffStartDateFilter = new FormControl('');
  propertyTaxBasisFilter = new FormControl('');
  propertyTaxBasisDeclineFilter = new FormControl('');
  propertyTaxEndingBasisFilter = new FormControl('');
  propertyTaxAbatementFilter = new FormControl('');
  propertyTaxYearsFilter = new FormControl('');

  filterValues = {
    type: '',
    startDate: '',
    endDate: '',
    price: '',
    frequency: '',
    applyUnit: '',
    tarriffGrowthValue: '',
    tarriffGrowthChange: '',
    tarriffStartDate: '',
    propertyTaxBasis: '',
    propertyTaxBasisDecline: '',
    propertyTaxEndingBasis: '',
    propertyTaxAbatement: '',
    propertyTaxYears: ''
  };

  @ViewChild(MatSort) sort: MatSort;

  constructor(
    public dialog: MatDialog,
    private dataService: DataService,
    private globals: GlobalsService,
    private toastr: ToastrService
  ) {
    this.getDropDownValuesByKey('project_operating_cost_type');
  }
  getDropDownValuesByKey(key: string) {
    this.tarriffGrowthChangeListItems = [
      { id: '-None-  ', name: '-None-(default)' },
      { id: 'yearly  ', name: 'Yearly' }
    ];
    this.applyUnitListItems = [
      { id: '000s-yr-project', name: '000s/Yr/Project' },
      { id: '000s-yr-mw', name: '000s/Yr/MW' },
      { id: '000s', name: '000s' },
      { id: '000s-project', name: '000s/Project' },
      { id: 'percent-of-revenue', name: '% of Revenue' }
    ];
    this.frequencyListItems = [{ id: 'yearly ', name: 'Yearly (default)' }];
    const postData = {
      key
    };
    this.getDropDownValuesSubscribe = this.dataService
      .getDropDownValues(postData)
      .subscribe(dropdownList => {
        const dataList = [];
        if (dropdownList.length) {
          for (const data of dropdownList) {
            dataList.push({ id: data.value, name: data.displayName });
          }
        }
        if (key === 'project_operating_cost_type') {
          for (const data of dataList) {
            if (
              data.name !== 'O&M Price/Yr Post Cont' &&
              data.name !== 'Development Cost'
            ) {
              this.typeList.push(data.name);
            }
          }
        }
      });
  }
  ngOnInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.data = [];
    this.processFilter();
    const currentUser$ = this.globals.currentUser;
    const curretSession$ = this.globals.currentSession;
    const loadedCaseData$ = this.globals.loadedCaseData;
    const selectedCaseId$ = this.globals.selectedCaseId;
    const casesList$ = this.globals.listOfCases;
    const combined = combineLatest(currentUser$, curretSession$);
    const combinedCases = combineLatest(casesList$, selectedCaseId$);

    this.combinedSubscribe = combined.subscribe(([userDtls, sessionId]) => {
      this.userDetails = userDtls;
      this.sessionId = sessionId;
      // this.getProjectOperatingCostList();
    });
    this.combinedCasesSubscribe = combinedCases.subscribe(
      ([caseList, caseId]) => {
        this.marketDataCaseId = caseId;
        if (caseList && Array.isArray(caseList)) {
          const filterdList = caseList.filter(cs => cs.id === caseId);
          if (filterdList.length) {
            this.marketDataSessionId = filterdList[0].sessionId;
          }
        }
      }
    );

    this.loadedCaseDataSubscribe = loadedCaseData$.subscribe(caseData => {
      if (caseData && caseData.projectOperatingCost) {
        this.processOperatingCostInfo(caseData.projectOperatingCost);
      }
    });

    this.countryChangeEmitterSubscribe = this.globals.countryChangeEmitter.subscribe(
      () => {
        this.dataSource = new MatTableDataSource<any>([]);
      }
    );
  }

  processFilter() {
    this.dataSource.filterPredicate = this.createFilter();
    this.typeFilterSubscribe = this.typeFilter.valueChanges.subscribe(type => {
      this.filterValues.type = type;
      this.dataSource.filter = JSON.stringify(this.filterValues);
    });
    this.startDateFilterSubscribe = this.startDateFilter.valueChanges.subscribe(
      startDate => {
        this.filterValues.startDate = startDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.endDateFilterSubscribe = this.endDateFilter.valueChanges.subscribe(
      endDate => {
        this.filterValues.endDate = endDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.priceFilterSubscribe = this.priceFilter.valueChanges.subscribe(
      price => {
        this.filterValues.price = price;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.frequencyFilterSubscribe = this.frequencyFilter.valueChanges.subscribe(
      frequency => {
        this.filterValues.frequency = frequency;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.applyUnitFilterSubscribe = this.applyUnitFilter.valueChanges.subscribe(
      applyUnit => {
        this.filterValues.applyUnit = applyUnit;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.tarriffGrowthValueFilterSubscribe = this.tarriffGrowthValueFilter.valueChanges.subscribe(
      tarriffGrowthValue => {
        this.filterValues.tarriffGrowthValue = tarriffGrowthValue;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.tarriffGrowthChangeFilterSubscribe = this.tarriffGrowthChangeFilter.valueChanges.subscribe(
      tarriffGrowthChange => {
        this.filterValues.tarriffGrowthChange = tarriffGrowthChange;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.tarriffStartDateFilterSubscribe = this.tarriffStartDateFilter.valueChanges.subscribe(
      tarriffStartDate => {
        this.filterValues.tarriffStartDate = tarriffStartDate;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );

    this.propertyTaxBasisFilterSubscribe = this.propertyTaxBasisFilter.valueChanges.subscribe(
      propertyTaxBasis => {
        this.filterValues.propertyTaxBasis = propertyTaxBasis;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.propertyTaxBasisDeclineFilterSubscribe = this.propertyTaxBasisDeclineFilter.valueChanges.subscribe(
      propertyTaxBasisDecline => {
        this.filterValues.propertyTaxBasisDecline = propertyTaxBasisDecline;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.propertyTaxEndingBasisFilterSubscribe = this.propertyTaxEndingBasisFilter.valueChanges.subscribe(
      propertyTaxEndingBasis => {
        this.filterValues.propertyTaxEndingBasis = propertyTaxEndingBasis;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.propertyTaxAbatementFilterSubscribe = this.propertyTaxAbatementFilter.valueChanges.subscribe(
      propertyTaxAbatement => {
        this.filterValues.propertyTaxAbatement = propertyTaxAbatement;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
    this.propertyTaxYearsFilterSubscribe = this.propertyTaxYearsFilter.valueChanges.subscribe(
      propertyTaxYears => {
        this.filterValues.propertyTaxYears = propertyTaxYears;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    );
  }
  getProjectOperatingCostList() {
    const loadCaseReq = {
      caseId: this.caseData.id,
      sessionId: this.caseData.sessionId
    };
    this.loadCaseSubscribe = this.dataService
      .loadCase(loadCaseReq)
      .subscribe(result => {
        if (result) {
          this.globals.updateLoadedCaseData(result);
        }
      });
  }
  processOperatingCostInfo(projectOperationInfo) {
    const projectOperationData = projectOperationInfo.map(item => {
      item = {
        ...item,
        id: item.projectoperatingcostId || 0,
        type: item.type || '',
        startDate: item.startDate ? item.startDate : '',
        endDate: item.endDate ? item.endDate : '',
        price: item.price || '',
        frequency: item.frequency || '',
        applyUnit: item.applyUnit || '',
        tarriffGrowthValue: item.tarriffGrowthValue || '',
        tarriffGrowthChange: item.tarriffGrowthChange || '',
        tarriffStartDate: item.tarriffStartDate || '',
        actions: ''
      };
      return item;
    });
    this.dataSource.data = projectOperationData;
  }
  createFilter(): (data: any, filter: string) => boolean {
    const filterFunction = function(data, filter): boolean {
      const searchTerms = JSON.parse(filter);
      return (
        data.type.toLowerCase().indexOf(searchTerms.type) !== -1 &&
        data.startDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.startDate) !== -1 &&
        data.endDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.endDate) !== -1 &&
        data.price
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.price) !== -1 &&
        data.frequency
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.frequency) !== -1 &&
        data.applyUnit
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.applyUnit) !== -1 &&
        data.tarriffGrowthValue
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.tarriffGrowthValue) !== -1 &&
        data.tarriffGrowthChange
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.tarriffGrowthChange) !== -1 &&
        data.tarriffStartDate
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.tarriffStartDate) !== -1 &&
        data.propertyTaxBasis
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.propertyTaxBasis) !== -1 &&
        data.propertyTaxBasisDecline
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.propertyTaxBasisDecline) !== -1 &&
        data.propertyTaxEndingBasis
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.propertyTaxEndingBasis) !== -1 &&
        data.propertyTaxAbatement
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.propertyTaxAbatement) !== -1 &&
        data.propertyTaxYears
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.propertyTaxYears) !== -1
      );
    };
    return filterFunction;
  }
  addOperationCost(dataSource) {
    if (!this.marketDataCaseId) {
      this.toastr.error(`Please Select/Create Case Item to Proceed. `);
      return false;
    }
    this.selectedCaseInfoSubscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );
    if (
      this.caseData.accessMode &&
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted.`);
      return false;
    }
    const data = {};
    const record = {
      type: '',
      startDate: '',
      endDate: '',
      price: '',
      frequency: 'yearly ',
      applyUnit: '',
      tarriffGrowthValue: '',
      tarriffGrowthChange: '-None-  ',
      tarriffStartDate: '',
      propertyTaxBasis: '',
      propertyTaxBasisDecline: '',
      propertyTaxEndingBasis: '',
      propertyTaxAbatement: '',
      propertyTaxYears: ''
    };
    data['record'] = record;
    data['frequencyListItems'] = this.frequencyListItems;
    data['applyUnitListItems'] = [];
    data['tarriffGrowthChangeListItems'] = this.tarriffGrowthChangeListItems;
    data['typeList'] = this.typeList;
    const dialogRef = this.dialog.open(AddOperationCostDialogComponent, {
      width: '850px',
      data: data
    });
    this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
      this.selectedRowId = null;
      if (result) {
        result.record['createdBy'] = this.userDetails.userId;
        result.record['createdDate'] = new Date();
        result.record['updatedBy'] = this.userDetails.userId;
        result.record['updatedDate'] = new Date();
        result.record['marketDataCaseId'] = this.marketDataCaseId;
        result.record['caseId'] = this.marketDataCaseId;
        result.record['sessionId'] = this.marketDataSessionId;
        result.record['projectoperatingcostId'] = 0;
        result.record['startDate'] = this.globals.removeTimeZone(
          result.record['startDate']
        );
        result.record['endDate'] = this.globals.removeTimeZone(
          result.record['endDate']
        );
        if (
          result.record['type'] === 'Decommisioning' ||
          result.record['type'] === 'Interconnect Service Charges' ||
          result.record['type'] === 'Upfront Royalty / Land Lease Payment' ||
          result.record['type'] === 'Property Tax'
        ) {
          result.record['tarriffGrowthChange'] = '-None-  ';
          result.record['tarriffGrowthValue'] = '';
          result.record['tarriffStartDate'] = '';
        }
        if (result.record['type'] === 'Property Tax') {
          result.record['applyUnit'] = '000s-yr-project';
          result.record['propertyTaxBasisDecline'] =
            result.record.propertyTaxBasisDecline || 0;
          result.record['propertyTaxEndingBasis'] =
            result.record.propertyTaxEndingBasis || 0;
          result.record['propertyTaxAbatement'] =
            result.record.propertyTaxAbatement || 0;
          result.record['propertyTaxYears'] =
            result.record.propertyTaxYears || 0;
        }
        this.saveProjectOperatingCostRecordSubscribe = this.dataService
          .saveProjectOperatingCostRecord(result.record)
          .subscribe(saveStatus => {
            if (saveStatus) {
              this.toastr.success(`${saveStatus.message} !!`);
              this.getProjectOperatingCostList();
            }
          });
      }
    });
  }

  openActionDialog(id: number, flag: string) {
    if (!this.marketDataCaseId) {
      this.toastr.error(`Please Select/Create Case Item to Proceed. `);
      return false;
    }
    this.selectedCaseInfo2Subscribe = this.globals.selectedCaseInfo.subscribe(
      caseData => {
        if (caseData) {
          this.caseData = caseData;
        }
      }
    );
    if (
      parseInt(this.caseData.accessMode, 10) === 0 &&
      this.userDetails.roleId !== 1
    ) {
      this.toastr.error(`Access restricted. `);
      return false;
    }
    this.selectedRowId = id;
    if (flag === 'edit') {
      const data = {};
      const record = this.dataSource.data.filter(obj => {
        return obj.projectoperatingcostId === id;
      })[0];
      this.selectedRecord = { ...record };
      data['record'] = record;
      data['record']['startDate'] = this.globals.returnFormattedDate(
        record.startDate
      );
      data['record']['endDate'] = this.globals.returnFormattedDate(
        record.endDate
      );
      data['record']['tarriffStartDate'] = this.globals.returnFormattedDate(
        record.tarriffStartDate
      );
      data['action'] = flag;
      data['typeList'] = this.typeList;
      data['frequencyListItems'] = this.frequencyListItems;
      data['applyUnitListItems'] = this.applyUnitListItems;
      data['tarriffGrowthChangeListItems'] = this.tarriffGrowthChangeListItems;
      data['record']['tarriffGrowthValue'] = record.tarriffGrowthValue || 0;
      data['record']['price'] = record.price || 0;
      const dialogRef = this.dialog.open(OperationCostEditDialogComponent, {
        width: '850px',
        data: data
      });
      this.afterClosed2Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          result.record['createdBy'] = this.userDetails.userId;
          result.record['updatedBy'] = this.userDetails.userId;
          result.record['updatedDate'] = new Date();
          result.record['marketDataCaseId'] = this.marketDataCaseId;
          result.record['caseId'] = this.marketDataCaseId;
          result.record['sessionId'] = this.marketDataSessionId;
          result.record['projectoperatingcostId'] = result.record.id;
          if (
            result.record['type'] === 'Decommisioning' ||
            result.record['type'] === 'Interconnect Service Charges' ||
            result.record['type'] === 'Upfront Royalty / Land Lease Payment' ||
            result.record['type'] === 'Property Tax'
          ) {
            result.record['tarriffGrowthChange'] = '-None-  ';
            result.record['tarriffGrowthValue'] = '';
            result.record['tarriffStartDate'] = '';
          }
          if (result.record['type'] === 'Property Tax') {
            result.record['applyUnit'] = '000s-yr-project';
            result.record['propertyTaxBasisDecline'] =
              result.record.propertyTaxBasisDecline || 0;
            result.record['propertyTaxEndingBasis'] =
              result.record.propertyTaxEndingBasis || 0;
            result.record['propertyTaxAbatement'] =
              result.record.propertyTaxAbatement || 0;
            result.record['propertyTaxYears'] =
              result.record.propertyTaxYears || 0;
          }
          this.saveProjectOperatingCostRecord2Subscribe = this.dataService
            .saveProjectOperatingCostRecord(result.record)
            .subscribe(editStatus => {
              if (editStatus) {
                this.toastr.success(`${editStatus.message} !!`);
                this.getProjectOperatingCostList();
              } else {
                this.toastr.error(`Error in editing the record!!`);
              }
            });
        }
        if (!result) {
          const dataSource = this.dataSource.data.map(obj => {
            if (obj.projectoperatingcostId === id) {
              obj = this.selectedRecord;
            }
            return obj;
          });
          this.dataSource.data = dataSource;
        }
      });
    }
    if (flag === 'delete') {
      const record = { id, action: flag };
      const dialogRef = this.dialog.open(OperationCostEditDialogComponent, {
        width: '300px',
        data: record
      });
      this.afterClosed3Subscribe = dialogRef.afterClosed().subscribe(result => {
        this.selectedRowId = null;
        if (result) {
          this.deleteProjectOperatingCostRecordSubscribe = this.dataService
            .deleteProjectOperatingCostRecord({ projectoperatingcostId: id })
            .subscribe(deleteStatus => {
              this.toastr.success(`Item deleted successfully!!`);
              if (deleteStatus) {
                this.getProjectOperatingCostList();
              } else {
                this.toastr.error(`Error in deleting the record!!`);
              }
            });
        }
      });
    }
  }

  ngOnDestroy() {
    if (this.getDropDownValuesSubscribe) {
      this.getDropDownValuesSubscribe.unsubscribe();
    }
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.combinedCasesSubscribe) {
      this.combinedCasesSubscribe.unsubscribe();
    }
    if (this.loadedCaseDataSubscribe) {
      this.loadedCaseDataSubscribe.unsubscribe();
    }
    if (this.countryChangeEmitterSubscribe) {
      this.countryChangeEmitterSubscribe.unsubscribe();
    }
    if (this.typeFilterSubscribe) {
      this.typeFilterSubscribe.unsubscribe();
    }
    if (this.startDateFilterSubscribe) {
      this.startDateFilterSubscribe.unsubscribe();
    }
    if (this.endDateFilterSubscribe) {
      this.endDateFilterSubscribe.unsubscribe();
    }
    if (this.priceFilterSubscribe) {
      this.priceFilterSubscribe.unsubscribe();
    }
    if (this.frequencyFilterSubscribe) {
      this.frequencyFilterSubscribe.unsubscribe();
    }
    if (this.applyUnitFilterSubscribe) {
      this.applyUnitFilterSubscribe.unsubscribe();
    }
    if (this.tarriffGrowthValueFilterSubscribe) {
      this.tarriffGrowthValueFilterSubscribe.unsubscribe();
    }
    if (this.tarriffGrowthChangeFilterSubscribe) {
      this.tarriffGrowthChangeFilterSubscribe.unsubscribe();
    }
    if (this.tarriffStartDateFilterSubscribe) {
      this.tarriffStartDateFilterSubscribe.unsubscribe();
    }
    if (this.propertyTaxBasisFilterSubscribe) {
      this.propertyTaxBasisFilterSubscribe.unsubscribe();
    }
    if (this.propertyTaxBasisDeclineFilterSubscribe) {
      this.propertyTaxBasisDeclineFilterSubscribe.unsubscribe();
    }
    if (this.propertyTaxEndingBasisFilterSubscribe) {
      this.propertyTaxEndingBasisFilterSubscribe.unsubscribe();
    }
    if (this.propertyTaxAbatementFilterSubscribe) {
      this.propertyTaxAbatementFilterSubscribe.unsubscribe();
    }
    if (this.propertyTaxYearsFilterSubscribe) {
      this.propertyTaxYearsFilterSubscribe.unsubscribe();
    }
    if (this.loadCaseSubscribe) {
      this.loadCaseSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfoSubscribe) {
      this.selectedCaseInfoSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
    if (this.saveProjectOperatingCostRecordSubscribe) {
      this.saveProjectOperatingCostRecordSubscribe.unsubscribe();
    }
    if (this.selectedCaseInfo2Subscribe) {
      this.selectedCaseInfo2Subscribe.unsubscribe();
    }
    if (this.afterClosed2Subscribe) {
      this.afterClosed2Subscribe.unsubscribe();
    }
    if (this.saveProjectOperatingCostRecord2Subscribe) {
      this.saveProjectOperatingCostRecord2Subscribe.unsubscribe();
    }
    if (this.afterClosed3Subscribe) {
      this.afterClosed3Subscribe.unsubscribe();
    }
    if (this.deleteProjectOperatingCostRecordSubscribe) {
      this.deleteProjectOperatingCostRecordSubscribe.unsubscribe();
    }
  }
}
