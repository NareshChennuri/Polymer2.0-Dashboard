import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material';
import { take } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { DataService } from '../../shared/api/data.service';
import { GlobalsService } from '../../shared/api/globals.service';
import { CloneSessionCaseComponent } from './clone-session-case/clone-session-case.component';
import { combineLatest, Subscription } from 'rxjs';

@Component({
  selector: 'app-session-case',
  templateUrl: './session-case.component.html',
  styleUrls: ['./session-case.component.css']
})
export class SessionCaseComponent implements OnInit, OnDestroy {
  private cloneSessionEmitterSubscribe: Subscription;
  private callSearchSubscribe: Subscription;
  private countryChangeEmitterSubscribe: Subscription;
  private currentCountrySubscribe: Subscription;
  private getCasesListSubscribe: Subscription;
  private getCasesList2Subscribe: Subscription;
  private getCasesList3Subscribe: Subscription;
  private combinedSubscribe: Subscription;
  private windParkDataSubscribe: Subscription;
  private loadCaseSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  sessionCases: any = [];
  accessModes: any = [];
  caseInfo: any = {};
  selectedSession: any;
  currentUser: any;
  countryId: any;
  countryCasesList: any = [];
  userCasesList: any = [];
  caseData: any;
  loadCall = true;
  countryCases = false;
  userCases = false;
  caseListRequestObj = {};
  constructor(
    public dialog: MatDialog,
    private dataService: DataService,
    private globals: GlobalsService,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    const caseStatusKey = { key: 'market_data_case_case_status' };
    const userDetails$ = this.globals.currentUser;
    const sessionDtls$ = this.globals.currentSession;
    const selectedCountry$ = this.globals.currentCountry;
    const statusList$ = this.dataService.getDropDownValues(caseStatusKey);
    const combined = combineLatest(userDetails$, sessionDtls$, statusList$);

    this.cloneSessionEmitterSubscribe = this.globals.cloneSessionEmitter.subscribe(
      () => {
        this.userCasesList = [];
      }
    );
    let count = 0;
    let userCount = 0;
    this.callSearchSubscribe = this.globals.callSearch.subscribe(() => {
      count = 0;
      userCount = 0;
    });
    this.countryChangeEmitterSubscribe = this.globals.countryChangeEmitter.subscribe(
      () => {
        count = 0;
        userCount = 0;
        this.sessionCases = [];
        this.globals.updateLoadedCaseData([]);
        this.loadCall = true;
        this.userCases = false;
        this.countryCases = false;
      }
    );
    this.currentCountrySubscribe = selectedCountry$.subscribe(countryId => {
      if (countryId && count === 0) {
        count++;
        this.countryCasesList = [];
        this.countryId = countryId;
        const reqInfo = {
          countryId: countryId
        };
        this.getCasesListSubscribe = this.dataService
          .getCasesList(reqInfo)
          .subscribe(caseListRes => {
            const caseList: any = caseListRes;
            if (caseListRes) {
              this.countryCasesList = caseList;
              const combinedCases = [
                ...this.userCasesList,
                ...this.countryCasesList
              ];
              const filteredCases = this.removeDuplicates(combinedCases, 'id');
              this.sessionCases = filteredCases.map(caseItem => {
                const csItem = {
                  ...caseItem,
                  accessMode: caseItem.caseStatus
                };
                return csItem;
              });
              this.countryCases = true;
              this.globals.changeCasesList(this.sessionCases);
              this.onCasesLoaded();
            }
          });
      }
      // If non-admin, load user cases after cloning the public cases (as part of clone public case user story)
      if (
        this.currentUser &&
        this.currentUser.userId &&
        this.currentUser.roleId !== 1 &&
        this.selectedSession &&
        userCount === 0
      ) {
        userCount++;
        if (
          this.caseListRequestObj['sessionId'] !== this.selectedSession ||
          this.caseListRequestObj['createdBy'] !== this.currentUser.userId ||
          this.caseListRequestObj['roleId'] !== this.currentUser.roleId
        ) {
          const caseListRequest = {
            sessionId: this.selectedSession,
            createdBy: this.currentUser.userId,
            roleId: this.currentUser.roleId
          };
          this.caseListRequestObj = caseListRequest;
          this.getCasesList2Subscribe = this.dataService
            .getCasesList(caseListRequest)
            .subscribe(caseListRes => {
              if (caseListRes) {
                this.userCasesList = caseListRes;
                const combinedCases = [
                  ...this.userCasesList,
                  ...this.countryCasesList
                ];
                const filteredCases = this.removeDuplicates(
                  combinedCases,
                  'id'
                );
                this.sessionCases = filteredCases.map(caseItem => {
                  const csItem = {
                    ...caseItem,
                    accessMode: caseItem.caseStatus
                  };
                  return csItem;
                });
                this.userCases = true;
                this.globals.changeCasesList(this.sessionCases);
                this.onCasesLoaded();
              }
            });
        }
      }
    });

    this.combinedSubscribe = combined.subscribe(
      ([userDtls, sessionDtls, statusList]) => {
        if (userDtls && userDtls.userId) {
          this.currentUser = userDtls;
        }
        this.selectedSession = sessionDtls;
        this.accessModes = statusList;

        // NonAdmin can't create public cases
        if (userDtls.roleId === 3) {
          this.accessModes = this.accessModes.filter(
            item => item.displayName !== 'Public'
          );
        }
        if (this.userCasesList.length === 0) {
          if (
            this.caseListRequestObj['sessionId'] !== sessionDtls ||
            this.caseListRequestObj['createdBy'] !== userDtls.userId ||
            this.caseListRequestObj['roleId'] !== userDtls.roleId
          ) {
            const caseListRequest = {
              sessionId: sessionDtls,
              createdBy: userDtls.userId,
              roleId: userDtls.roleId
            };
            this.caseListRequestObj = caseListRequest;

            // userCount++;
            this.getCasesList3Subscribe = this.dataService
              .getCasesList(caseListRequest)
              .subscribe(caseListRes => {
                const caseList: any = caseListRes;
                if (caseListRes) {
                  this.userCasesList = caseListRes;
                  const combinedCases = [
                    ...this.userCasesList,
                    ...this.countryCasesList
                  ];
                  const filteredCases = this.removeDuplicates(
                    combinedCases,
                    'id'
                  );
                  this.sessionCases = filteredCases.map(caseItem => {
                    const csItem = {
                      ...caseItem,
                      accessMode: caseItem.caseStatus
                    };
                    return csItem;
                  });
                  this.userCases = true;
                  this.globals.changeCasesList(this.sessionCases);
                  this.onCasesLoaded();
                }
              });
          }
        }
      }
    );
    this.windParkDataSubscribe = this.globals.windParkData.subscribe(
      parkData => {
        if (parkData.length) {
          this.caseData = { value: parkData[0].caseId };
          this.caseInfo.id = parkData[0].caseId;
        }
      }
    );
  }

  onCasesLoaded() {
    if (this.loadCall && this.userCases && this.countryCases) {
      this.loadCall = false;
      this.sessionCaseChange(this.caseData);
    }
  }

  removeDuplicates(myArr, prop) {
    return myArr.filter((obj, pos, arr) => {
      return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
  }

  sessionCaseChange($eve) {
    const sessionCaseId = $eve.value;
    if (sessionCaseId && this.sessionCases && this.sessionCases.length) {
      const caseInfo = JSON.parse(
        JSON.stringify(
          this.sessionCases.filter(item => {
            if (item.id === sessionCaseId) {
              return item;
            }
          })
        )
      );

      if (caseInfo.length) {
        this.caseInfo = caseInfo[0];
        if (caseInfo[0]) {
          this.globals.changeSelectedCaseId(caseInfo[0].id);
          this.globals.changeSelectedCaseInfo(caseInfo[0]);
          const loadCaseReq = {
            caseId: caseInfo[0].id,
            sessionId: caseInfo[0].sessionId
          };
          this.loadCaseSubscribe = this.dataService
            .loadCase(loadCaseReq)
            .subscribe(result => {
              if (result) {
                this.globals.updateLoadedCaseData(result);
              }
              this.loadCall = true;
              this.userCases = false;
              this.countryCases = false;
            });
        }
      } else {
        this.caseInfo = {};
        this.loadCall = true;
        this.userCases = false;
        this.countryCases = false;
      }
    }
  }

  createCase() {
    const caseInfo = JSON.stringify(this.caseInfo);
    const sessionCases = JSON.stringify(this.sessionCases);

    const dialogRef = this.dialog.open(CloneSessionCaseComponent, {
      disableClose: true,
      width: '600px',
      height: '500px',
      data: {
        caseInfo: JSON.parse(caseInfo),
        sessionCases: JSON.parse(sessionCases),
        accessModes: this.accessModes,
        sessionId: this.selectedSession,
        userDtls: this.currentUser,
        countryCasesList: JSON.parse(JSON.stringify(this.countryCasesList)),
        userCasesList: JSON.parse(JSON.stringify(this.userCasesList))
      }
    });

    this.afterClosedSubscribe = dialogRef
      .afterClosed()
      .pipe(take(1))
      .subscribe(result => {
        this.userCasesList =
          result.userCasesList.length > 0 ? result.userCasesList : [];
        this.sessionCases = [...result.sessionCases];
        this.globals.changeCasesList(this.sessionCases);
      });
  }

  ngOnDestroy() {
    if (this.cloneSessionEmitterSubscribe) {
      this.cloneSessionEmitterSubscribe.unsubscribe();
    }
    if (this.callSearchSubscribe) {
      this.callSearchSubscribe.unsubscribe();
    }
    if (this.countryChangeEmitterSubscribe) {
      this.countryChangeEmitterSubscribe.unsubscribe();
    }
    if (this.currentCountrySubscribe) {
      this.currentCountrySubscribe.unsubscribe();
    }
    if (this.getCasesListSubscribe) {
      this.getCasesListSubscribe.unsubscribe();
    }
    if (this.getCasesList2Subscribe) {
      this.getCasesList2Subscribe.unsubscribe();
    }
    if (this.getCasesList3Subscribe) {
      this.getCasesList3Subscribe.unsubscribe();
    }
    if (this.combinedSubscribe) {
      this.combinedSubscribe.unsubscribe();
    }
    if (this.windParkDataSubscribe) {
      this.windParkDataSubscribe.unsubscribe();
    }
    if (this.loadCaseSubscribe) {
      this.loadCaseSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
  }
}
