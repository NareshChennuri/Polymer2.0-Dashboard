import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { SessionCaseComponent } from '../session-case.component';
import { DataService } from '../../../shared/api/data.service';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-clone-session-case',
  templateUrl: './clone-session-case.component.html',
  styleUrls: ['./clone-session-case.component.css']
})
export class CloneSessionCaseComponent implements OnInit, OnDestroy {
  private deleteCaseSubscribe: Subscription;
  private saveCasesSubscribe: Subscription;
  private cloneMarketDataCaseSubscribe: Subscription;
  private saveCases2Subscribe: Subscription;
  private getCasesListSubscribe: Subscription;
  prevCaseInfo: any;
  isEditMode: Boolean;
  constructor(
    public dialogRef: MatDialogRef<SessionCaseComponent>,
    private dataService: DataService,
    private toastr: ToastrService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.isEditMode = false;
    this.data.caseInfo = { id: 0, caseMode: 'create' };
    this.data.sessionCases = this.disableEditDeleteAccess(
      this.data.sessionCases
    );
  }

  disableEditDeleteAccess(sessionCases) {
    sessionCases = sessionCases.map(item => {
      const details = {
        caseAccessMode: +item.accessMode,
        caseCreatedBy: +item.createdBy,
        caseOriginalSession: +item.sessionId,
        currentSessionId: +this.data.sessionId,
        currentUserType: +this.data.userDtls.roleId,
        currentUserId: +this.data.userDtls.userId
      };
      const disabled = this.caseEditDeleteAccess(details);
      item = {
        ...item,
        disabled
      };
      return item;
    });
    return sessionCases;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  modeChange($eve) {
    const modeVal = $eve.value;
    if (modeVal) {
      const caseStatusData = this.data.accessModes.filter(
        ac => ac.value === modeVal
      );
      const caseStatus = caseStatusData[0] ? caseStatusData[0].value : '';
      this.data.caseInfo = {
        ...this.data.caseInfo,
        caseStatus,
        accessMode: modeVal.toString()
      };
    }
  }

  editCase(caseInfo) {
    this.isEditMode = true;
    this.prevCaseInfo = { ...caseInfo };
    const caseStatusData = this.data.accessModes.filter(
      ac => ac.value === caseInfo.accessMode
    );
    const caseStatus = caseStatusData[0] ? caseStatusData[0].value : '';
    this.data.caseInfo = { ...caseInfo, caseStatus, caseMode: 'edit' };
  }

  cloneCase(caseInfo) {
    this.isEditMode = true;
    this.data.caseInfo = {
      ...caseInfo,
      accessMode: '',
      caseMode: 'clone'
    };
  }
  cancelCase(caseForm: NgForm) {
    // this.data.caseInfo = { ...this.prevCaseInfo };
    caseForm.reset();
  }

  createCase() {
    this.isEditMode = true;
    this.data.caseInfo = { id: 0, caseMode: 'create' };
  }

  removeCase(caseInfo) {
    this.isEditMode = false;
    const deleteReq = {
      sessionId: this.data.sessionId,
      caseId: caseInfo.id,
      roleId: this.data.userDtls.roleId
    };
    this.deleteCaseSubscribe = this.dataService
      .deleteCase(deleteReq)
      .subscribe(delStatus => {
        this.toastr.info(`${delStatus['statusText']}`);
        this.getCasesList();
        // this.data.sessionCases = this.data.sessionCases.filter(
        //   sc => sc.id !== caseInfo.id
        // );
      });
  }

  confirmCase(caseInfo, caseForm: NgForm) {
    if (caseInfo && caseInfo.caseMode) {
      switch (caseInfo.caseMode) {
        case 'create':
          delete caseInfo.caseId;
          delete caseInfo.id;
          const createCaseReq = [
            {
              ...caseInfo,
              sessionId: parseInt(this.data.sessionId, 10),
              createdBy: this.data.userDtls.userId,
              updatedBy: this.data.userDtls.userId,
              roleId: this.data.userDtls.roleId
            }
          ];
          this.saveCasesSubscribe = this.dataService
            .saveCases(createCaseReq)
            .subscribe(res => {
              // this.data.sessionCases = [...this.data.sessionCases, caseInfo];
              this.toastr.success('Case created successfully!!');
              caseForm.reset();
              this.isEditMode = false;
              this.getCasesList();
            });
          break;

        case 'clone':
          const caseId = caseInfo.id;
          delete caseInfo.caseId;
          delete caseInfo.id;
          const cloneCaseReq = {
            ...caseInfo,
            caseId,
            sessionId: parseInt(this.data.sessionId, 10),
            caseSessionId: caseInfo.sessionId,
            currentSessionId: parseInt(this.data.sessionId, 10),
            createdBy: this.data.userDtls.userId,
            updatedBy: this.data.userDtls.userId,
            roleId: this.data.userDtls.roleId
          };
          this.cloneMarketDataCaseSubscribe = this.dataService
            .cloneMarketDataCase(cloneCaseReq)
            .subscribe(res => {
              this.toastr.info(`${res['statusText']}`);
              caseForm.reset();
              this.isEditMode = false;
              this.getCasesList();
            });
          break;

        case 'edit':
          this.data.caseInfo = caseInfo;
          this.data.sessionCases = this.data.sessionCases.map(item => {
            if (item.id === caseInfo.id) {
              item = {
                ...caseInfo
              };
            }
            return item;
          });
          this.data.sessionCases = this.disableEditDeleteAccess(
            this.data.sessionCases
          );
          const editReq = [
            {
              ...caseInfo,
              caseId: caseInfo.id,
              sessionId: parseInt(this.data.sessionId, 10),
              updatedBy: this.data.userDtls.userId,
              roleId: this.data.userDtls.roleId
            }
          ];
          this.saveCases2Subscribe = this.dataService
            .saveCases(editReq)
            .subscribe(res => {
              this.toastr.success('Case edited successfully!!');
              caseForm.reset();
              this.isEditMode = false;
              this.getCasesList();
            });
          break;
      }
    }
  }

  getCasesList() {
    const caseListRequest = {
      sessionId: this.data.sessionId,
      createdBy: this.data.userDtls.userId,
      roleId: this.data.userDtls.roleId
    };

    this.getCasesListSubscribe = this.dataService
      .getCasesList(caseListRequest)
      .subscribe(caseListRes => {
        const caseList: any = caseListRes;
        this.data.userCasesList = caseListRes;
        const combinedCases = [...caseList, ...this.data.countryCasesList];
        const filterdCases = this.removeDuplicates(combinedCases, 'id');
        this.data.sessionCases = filterdCases.map(caseItem => {
          const csItem = {
            ...caseItem,
            accessMode: caseItem.caseStatus
          };
          return csItem;
        });
        this.data.sessionCases = this.disableEditDeleteAccess(
          this.data.sessionCases
        );
      });
  }

  removeDuplicates(myArr, prop) {
    return myArr.filter((obj, pos, arr) => {
      return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
  }

  caseEditDeleteAccess(details) {
    // disable if currentSession Id and Case Session Id is not same
    if (details['caseOriginalSession'] !== details['currentSessionId']) {
      return true; // disable edit & delete
    } else if (
      // enable if user is an Admin and case is public
      details['currentUserType'] === 1 &&
      details['caseAccessMode'] === 0
    ) {
      return false; // enable edit & delete
    } else if (
      // enable if case is created by current user and it is a private case
      details['caseCreatedBy'] === details['currentUserId'] &&
      details['caseAccessMode'] === 1
    ) {
      return false; // enable edit & delete
    }
    return true; // disable edit & delete
  }

  ngOnDestroy() {
    if (this.deleteCaseSubscribe) {
      this.deleteCaseSubscribe.unsubscribe();
    }
    if (this.saveCasesSubscribe) {
      this.saveCasesSubscribe.unsubscribe();
    }
    if (this.cloneMarketDataCaseSubscribe) {
      this.cloneMarketDataCaseSubscribe.unsubscribe();
    }
    if (this.saveCases2Subscribe) {
      this.saveCases2Subscribe.unsubscribe();
    }
    if (this.getCasesListSubscribe) {
      this.getCasesListSubscribe.unsubscribe();
    }
  }
}
