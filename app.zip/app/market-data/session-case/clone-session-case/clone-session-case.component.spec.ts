import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloneSessionCaseComponent } from './clone-session-case.component';

describe('CloneSessionCaseComponent', () => {
  let component: CloneSessionCaseComponent;
  let fixture: ComponentFixture<CloneSessionCaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloneSessionCaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloneSessionCaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
