import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SessionCaseComponent } from './session-case.component';

describe('SessionCaseComponent', () => {
  let component: SessionCaseComponent;
  let fixture: ComponentFixture<SessionCaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SessionCaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SessionCaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
