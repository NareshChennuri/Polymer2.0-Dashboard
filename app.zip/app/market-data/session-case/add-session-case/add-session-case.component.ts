import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SessionCaseComponent } from '../session-case.component';

@Component({
  selector: 'app-add-session-case',
  templateUrl: './add-session-case.component.html',
  styleUrls: ['./add-session-case.component.css']
})
export class AddSessionCaseComponent implements OnInit {
  addCaseData: Object = {};
  constructor(public dialogRef: MatDialogRef<SessionCaseComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
