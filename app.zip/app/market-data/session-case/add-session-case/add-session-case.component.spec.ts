import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSessionCaseComponent } from './add-session-case.component';

describe('AddSessionCaseComponent', () => {
  let component: AddSessionCaseComponent;
  let fixture: ComponentFixture<AddSessionCaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSessionCaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSessionCaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
