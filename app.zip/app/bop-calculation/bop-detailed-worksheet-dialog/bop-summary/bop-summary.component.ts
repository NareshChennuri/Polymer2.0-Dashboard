import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bop-summary',
  templateUrl: './bop-summary.component.html',
  styleUrls: ['./bop-summary.component.css']
})
export class BopSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
