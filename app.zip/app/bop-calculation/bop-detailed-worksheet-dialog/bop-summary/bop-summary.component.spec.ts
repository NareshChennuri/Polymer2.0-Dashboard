import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopSummaryComponent } from './bop-summary.component';

describe('BopSummaryComponent', () => {
  let component: BopSummaryComponent;
  let fixture: ComponentFixture<BopSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
