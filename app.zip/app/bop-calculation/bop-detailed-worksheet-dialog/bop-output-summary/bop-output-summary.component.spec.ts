import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopOutputSummaryComponent } from './bop-output-summary.component';

describe('BopOutputSummaryComponent', () => {
  let component: BopOutputSummaryComponent;
  let fixture: ComponentFixture<BopOutputSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopOutputSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopOutputSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
