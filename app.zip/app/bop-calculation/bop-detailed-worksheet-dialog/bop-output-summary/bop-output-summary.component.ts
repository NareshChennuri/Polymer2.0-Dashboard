import { Component, OnInit } from '@angular/core';

export interface OutputSummary {
  outputSummary: string;
  totalBopCostsPark: string;
  totalBopCostTurbine: string;
  totalBoPCostsMwh: string;
  installationCostPark: string;
  installationCostTurbine: string;
  installationCostMwh: string;
}

const outputSummaryData: OutputSummary[] = [
  {
    outputSummary: 'GE 3.63 137 Rev2',
    totalBopCostsPark: '12760148',
    totalBopCostTurbine: '1595019',
    totalBoPCostsMwh: '425338',
    installationCostPark: '0',
    installationCostTurbine: '0',
    installationCostMwh: '0'
  }
];

@Component({
  selector: 'app-bop-output-summary',
  templateUrl: './bop-output-summary.component.html',
  styleUrls: ['./bop-output-summary.component.css']
})
export class BopOutputSummaryComponent implements OnInit {
  dataSource = outputSummaryData;
  displayedColumns: string[] = [
    'outputSummary',
    'totalBopCostsPark',
    'totalBopCostTurbine',
    'totalBoPCostsMwh',
    'installationCostPark',
    'installationCostTurbine',
    'installationCostMwh'
  ];
  constructor() {}

  ngOnInit() {}
}
