import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopDetailedWorksheetDialogComponent } from './bop-detailed-worksheet-dialog.component';

describe('BopDetailedWorksheetDialogComponent', () => {
  let component: BopDetailedWorksheetDialogComponent;
  let fixture: ComponentFixture<BopDetailedWorksheetDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopDetailedWorksheetDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopDetailedWorksheetDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
