import { Component, OnInit } from '@angular/core';

export interface DetailedCalculations {
  balanceOfPlantCostEstimation: string;
  installationComplexityFactor: string;
  installationLaborHours: string;
  installationRate: string;
  equipmentCost: string;
  towerBaseMoment: string;
  concreteVolume: string;
  rebarWeight: string;
  laborCost: string;
  totalLengthOfNetworkRoads: string;
  totalLengthOfElec: string;
  cablingPrice: string;
  fiberPrice: string;
  powerConditioningEquipment: string;
  numberOfCircuits: string;
}

const detailedCalculationsData: DetailedCalculations[] = [
  {
    balanceOfPlantCostEstimation: 'GE 3.63 137 Rev2',
    installationComplexityFactor: '1',
    installationLaborHours: '1677',
    installationRate: '5',
    equipmentCost: '0',
    towerBaseMoment: '173807',
    concreteVolume: '589',
    rebarWeight: '56',
    laborCost: '69569',
    totalLengthOfNetworkRoads: '3069',
    totalLengthOfElec: '6138',
    cablingPrice: '71',
    fiberPrice: '5',
    powerConditioningEquipment: '0',
    numberOfCircuits: '2'
  }
];
@Component({
  selector: 'app-bop-detailed-calculations',
  templateUrl: './bop-detailed-calculations.component.html',
  styleUrls: ['./bop-detailed-calculations.component.css']
})
export class BopDetailedCalculationsComponent implements OnInit {
  dataSource = detailedCalculationsData;
  detailedCalcSummary = [
    {
      key: 'E Module',
      value: [
        ['GE 234 kd 32', '', '', ''],
        ['GE 234 kd 32', '', '', ''],
        ['GE 234 kd 32', '', '', '']
      ]
    },
    {
      key: 'L',
      value: [
        ['Park', 'Turbine', 'MW', 'Cost%'],
        ['Park', 'Turbine', 'MW', 'Cost%'],
        ['Park', 'Turbine', 'MW', 'Cost%']
      ]
    },
    {
      key: 'I Installation',
      value: [
        ['1456151', '182019', '48538', '0'],
        ['1482870', '211839', '49429', '0'],
        ['1531150', '211839', '27145', '1']
      ]
    }
  ];
  displayedColumns: string[] = [
    'balanceOfPlantCostEstimation',
    'installationComplexityFactor',
    'installationLaborHours',
    'installationRate',
    'equipmentCost',
    'towerBaseMoment',
    'concreteVolume',
    'rebarWeight',
    'laborCost',
    'totalLengthOfNetworkRoads',
    'totalLengthOfElec',
    'cablingPrice',
    'fiberPrice',
    'powerConditioningEquipment',
    'numberOfCircuits'
  ];
  constructor() {}

  ngOnInit() {}
}
