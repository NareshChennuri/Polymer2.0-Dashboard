import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from 'src/app/shared/api/data.service';
import { GlobalsService } from 'src/app/shared/api/globals.service';

@Component({
  selector: 'app-bop-globaldetails',
  templateUrl: './bop-globaldetails.component.html',
  styleUrls: ['./bop-globaldetails.component.css']
})
export class BopGlobaldetailsComponent implements OnInit, OnDestroy {
  private currentCountryNameSubscribe: Subscription;
  private getDropDownValuesSubscribe: Subscription;
  country: string;
  offShore = false;
  dataSource: any = [];
  parkLayoutListItems: any = [];
  projectScopeListItems: any = [];
  topoGrophyListItems: any = [];
  soilTypeListItems: any = [];
  transmissionListItems: any = [];
  topoGraphyListItems: any = [];
  parkLayout: string;
  topoGraphy: string;
  soilType: string;
  projectScope: string;
  transmission: string;
  weatherrisk: string;

  bopGlobalDetails = {
    maxarea: 0,
    distanceToShore: 10,
    distanceToOnMPort: 10,
    distanceToStagingArea: 10,
    weatherRisk: 10
  };

  constructor(
    private dataService: DataService,
    private globals: GlobalsService
  ) {
    this.getDropDownValuesByKey('park_layout');
    this.getDropDownValuesByKey('proj_scope');
    this.getDropDownValuesByKey('topo_graphy');
    this.getDropDownValuesByKey('soil_type');
    this.getDropDownValuesByKey('transmission');
  }

  ngOnInit() {
    this.currentCountryNameSubscribe = this.globals.currentCountryName.subscribe(
      country => {
        this.country = country;
        if (this.country.endsWith('-Offshore')) {
          this.offShore = true;
        }
      }
    );
  }

  updateGlobalDetailsData(event): void {
    // parseInt(event.target.value)
    const maxarea = parseInt(event.target.value, 10);
    this.globals.updateParkMaxArea(maxarea);
  }

  getDropDownValuesByKey(key: string) {
    const postData = {
      key
    };

    this.getDropDownValuesSubscribe = this.dataService
      .getDropDownValues(postData)
      .subscribe(dropdownList => {
        const dataList = [];
        const parkLayoutList = [];
        const projScopeList = [];
        const topoGraphyList = [];
        if (dropdownList.length) {
          for (const data of dropdownList) {
            dataList.push({ id: data.value, name: data.displayName });
          }
        }
        if (key === 'park_layout') {
          this.parkLayoutListItems = dataList;
        }
        if (key === 'proj_scope') {
          this.projectScopeListItems = dataList;
        }
        if (key === 'topo_graphy') {
          this.topoGrophyListItems = dataList;
          console.log('topoGrophyListItems', this.topoGrophyListItems);
        }
        if (key === 'soil_type') {
          this.soilTypeListItems = dataList;
          console.log('soilTypeListItems', this.soilTypeListItems);
        }
        if (key === 'transmission') {
          this.transmissionListItems = dataList;
          console.log('transmissionListItems', this.transmissionListItems);
        }
      });
  }

  ngOnDestroy() {
    if (this.currentCountryNameSubscribe) {
      this.currentCountryNameSubscribe.unsubscribe();
    }
    if (this.getDropDownValuesSubscribe) {
      this.getDropDownValuesSubscribe.unsubscribe();
    }
  }
}
