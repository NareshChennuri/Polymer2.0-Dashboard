import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopGlobaldetailsComponent } from './bop-globaldetails.component';

describe('BopGlobaldetailsComponent', () => {
  let component: BopGlobaldetailsComponent;
  let fixture: ComponentFixture<BopGlobaldetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopGlobaldetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopGlobaldetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
