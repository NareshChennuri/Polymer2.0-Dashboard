import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { DataService } from 'src/app/shared/api/data.service';
import { GlobalsService } from 'src/app/shared/api/globals.service';
import { Router } from '@angular/router';
import { disableBindings } from '@angular/core/src/render3';

export interface PeriodicElement {
  parkTitle: string;
  parkIndex: number;
  casesList: any[];
  windParkData: any[];
  projectScope: string;
}

@Component({
  selector: 'app-bop-balanceofplantcosts',
  templateUrl: './bop-balanceofplantcosts.component.html',
  styleUrls: ['./bop-balanceofplantcosts.component.css']
})
export class BopBalanceofplantcostsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
