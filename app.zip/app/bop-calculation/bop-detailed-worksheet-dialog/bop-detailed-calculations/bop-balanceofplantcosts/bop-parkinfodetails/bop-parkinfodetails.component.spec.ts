import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopParkinfodetailsComponent } from './bop-parkinfodetails.component';

describe('BopParkinfodetailsComponent', () => {
  let component: BopParkinfodetailsComponent;
  let fixture: ComponentFixture<BopParkinfodetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopParkinfodetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopParkinfodetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
