import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopParkinfoTurbinContainerComponent } from './bop-parkinfo-turbin-container.component';

describe('BopParkinfoTurbinContainerComponent', () => {
  let component: BopParkinfoTurbinContainerComponent;
  let fixture: ComponentFixture<BopParkinfoTurbinContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopParkinfoTurbinContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopParkinfoTurbinContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
