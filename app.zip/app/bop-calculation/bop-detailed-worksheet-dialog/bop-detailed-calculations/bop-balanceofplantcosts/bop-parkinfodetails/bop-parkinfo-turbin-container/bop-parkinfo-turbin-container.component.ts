import { Subscription } from 'rxjs';
import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { DataService } from 'src/app/shared/api/data.service';
import { GlobalsService } from 'src/app/shared/api/globals.service';

@Component({
  selector: 'app-bop-parkinfo-turbin-container',
  templateUrl: './bop-parkinfo-turbin-container.component.html',
  styleUrls: ['./bop-parkinfo-turbin-container.component.css']
})
export class BopParkinfoTurbinContainerComponent implements OnInit, OnDestroy {
  private bopParkInfoDataSubscribe: Subscription;
  private currentSessionSubscribe: Subscription;
  private getDropDownValuesSubscribe: Subscription;
  private getBopConfigurationDefaultsSubscribe: Subscription;
  bopParkInfo: any;
  data: any;
  parkName: string;
  parkId: number;
  pinParkId: number;
  dataSource: any = [];
  towerTypeListItems: any = [];
  towerType: object[];
  turbineSelectedId: number;
  currentSessionId: any;

  @Input() type: string;
  @Output() updatePinPark = new EventEmitter<{}>();
  @Output() updateUnpinPark = new EventEmitter<{}>();
  @Output() updateDefaultPark = new EventEmitter<{}>();
  @Output() updateTurbineSelected = new EventEmitter<{}>();

  constructor(
    private dataService: DataService,
    private globals: GlobalsService
  ) {
    this.getDropDownValuesByKey('tower_type');
  }

  ngOnInit() {
    this.bopParkInfoDataSubscribe = this.globals.bopParkInfoData.subscribe(
      bopParkInfo => {
        this.bopParkInfo = bopParkInfo;
        if (
          this.type === 'pinParkData' &&
          this.bopParkInfo['pinParkData'] &&
          this.bopParkInfo['pinParkData'].selectedPCList.length
        ) {
          this.data = this.bopParkInfo['pinParkData'].selectedPCList;
          this.parkName = this.bopParkInfo['pinParkData'].parkName;
          this.parkId = this.bopParkInfo['pinParkData'].parkId;
          this.pinParkId = this.bopParkInfo['pinParkData'].parkId;
        }
        if (
          this.type === 'compareParkData' &&
          this.bopParkInfo['compareParkData'] &&
          this.bopParkInfo['compareParkData'].selectedPCList.length
        ) {
          this.data = this.bopParkInfo['compareParkData'].selectedPCList;
          this.parkName = this.bopParkInfo['compareParkData'].parkName;
          this.parkId = this.bopParkInfo['compareParkData'].parkId;
        }
      }
    );
    this.currentSessionSubscribe = this.globals.currentSession.subscribe(
      country => {
        this.currentSessionId = country;
      }
    );
  }

  getDropDownValuesByKey(key: string) {
    const postData = {
      key
    };
    this.getDropDownValuesSubscribe = this.dataService
      .getDropDownValues(postData)
      .subscribe(dropdownList => {
        const towerTypeList = [];
        if (dropdownList.length) {
          for (const data of dropdownList) {
            towerTypeList.push({ id: data.value, name: data.displayName });
          }
        }
        this.towerTypeListItems = towerTypeList;
      });
  }

  pinPark(parkId: number) {
    this.updatePinPark.emit(parkId);
  }

  unpinPark() {
    this.updateUnpinPark.emit();
  }

  defaultPark(parkId: number) {
    this.updateDefaultPark.emit(parkId);
  }

  turbineSelected(parkId: number, turbineId: number, turbineFirst: boolean) {
    this.turbineSelectedId = turbineId;
    this.updateTurbineSelected.emit([parkId, turbineId, turbineFirst]);
    if (parkId && turbineId && turbineFirst) {
      const req = {
        sessionId: parseInt(this.currentSessionId, 10),
        parkId: parkId,
        turbineId: turbineId
      };
      this.getBopConfigurationDefaultsSubscribe = this.dataService
        .getBopConfigurationDefaluts(req)
        .subscribe(res => {
          if (res && res.length) {
            this.globals.UpdateBopTurbineDefaultData(res);
          }
        });
    }
  }

  ngOnDestroy() {
    if (this.bopParkInfoDataSubscribe) {
      this.bopParkInfoDataSubscribe.unsubscribe();
    }
    if (this.currentSessionSubscribe) {
      this.currentSessionSubscribe.unsubscribe();
    }
    if (this.getDropDownValuesSubscribe) {
      this.getDropDownValuesSubscribe.unsubscribe();
    }
    if (this.getBopConfigurationDefaultsSubscribe) {
      this.getBopConfigurationDefaultsSubscribe.unsubscribe();
    }
  }
}
