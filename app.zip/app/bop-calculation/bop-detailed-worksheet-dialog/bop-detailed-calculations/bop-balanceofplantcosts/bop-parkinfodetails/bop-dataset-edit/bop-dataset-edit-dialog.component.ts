import {
  Component,
  Inject,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DataService } from '../../../../../../shared/api/data.service';
import { GlobalsService } from '../../../../../../shared/api/globals.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-bop-dataset-edit-dialog',
  templateUrl: 'bop-dataset-edit-dialog.component.html',
  styleUrls: ['./bop-dataset-edit-dialog.component.css']
})
export class BopDatasetEditDialogComponent implements OnInit, OnDestroy {
  private constructionStartDateGlobalSubscribe: Subscription;
  codDate: string;
  @ViewChild('startDate') startDate: ElementRef;
  @ViewChild('picker2') endDate: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _service: DataService,
    private globals: GlobalsService
  ) {}

  ngOnInit() {
    this.constructionStartDateGlobalSubscribe = this.globals.constructionStartDateGlobal.subscribe(
      date => {
        this.codDate = this.globals.returnFormattedDate(date);
      }
    );
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  dateChange() {
    const startDate = this.data.record.startDate;
    if (startDate) {
      this.endDate['disabled'] = false;
    }
  }

  updateTotal() {
    this.data.record.total = this.data.record.unitCost * this.data.record.quantity;
  }

  ngOnDestroy() {
    this.constructionStartDateGlobalSubscribe.unsubscribe();
  }
}
