import { Subscription } from 'rxjs';
import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { GlobalsService } from 'src/app/shared/api/globals.service';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { BopDatasetEditDialogComponent } from '../bop-dataset-edit/bop-dataset-edit-dialog.component';

@Component({
  selector: 'app-bop-configuration-turbineinfo',
  templateUrl: './bop-configuration-turbineinfo.component.html',
  styleUrls: ['./bop-configuration-turbineinfo.component.css']
})
export class BopConfigurationTurbineinfoComponent implements OnInit, OnDestroy {
  private bopParkInfoDataSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  bopParkInfo: any;
  data: any;
  index = 0;
  selectedRowId: number;
  @Input() type: string;
  dataSource = new MatTableDataSource<any>([]);

  constructor(private globals: GlobalsService, public dialog: MatDialog) {}

  ngOnInit() {
    if (this.type === 'pinParkConfigBop' || this.type === 'pinParkBop') {
      this.index = 0;
    } else if (
      this.type === 'compareParkConfigBopData' ||
      this.type === 'compareParkBopData'
    ) {
      this.index = 1;
    }

    this.bopParkInfoDataSubscribe = this.globals.bopParkInfoData.subscribe(
      bopParkInfo => {
        this.bopParkInfo = bopParkInfo;
        this.data = this.bopParkInfo[this.type][this.index];
      }
    );
  }

  openActionDialog(id: any) {
    const data = {
      record: {
        id: id,
        dorSelector: '2',
        startDate: new Date(),
        endDate: new Date(),
        unitCost: '150',
        quantity: '10',
        notes: 'some notes',
        total: '1500'
      },
      dorSelectorListItems: [
        { id: '1', name: 'dor1' },
        { id: '2', name: 'dor2' }
      ],
      flag: 'editDataset'
    };

    const dialogRef = this.dialog.open(BopDatasetEditDialogComponent, {
      width: '1100px',
      data: data
    });
    this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
      this.selectedRowId = null;
      if (result) {
        debugger;
        // this.saveBopDatasetRecordSubscribe = this.dataService
        //   .saveBopDatasetRecord(result.record)
        //   .subscribe(editStatus => {
        //     if (editStatus.message) {
        //       this.toastr.success(`${editStatus.message} !!`);
        //     }
        //     this.getFinanceRecordList();
        //   });
      }
      if (!result) {
        // const dataSource = this.dataSource.data.map(obj => {
        // if (obj.id === id) {
        //   obj = this.selectedRecord;
        // }
        // return obj;
        // });
        // this.dataSource.data = dataSource;
      }
    });
  }

  ngOnDestroy() {
    if (this.bopParkInfoDataSubscribe) {
      this.bopParkInfoDataSubscribe.unsubscribe();
    }

    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
  }
}
