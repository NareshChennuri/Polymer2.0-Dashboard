import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopConfigurationTurbineinfoComponent } from './bop-configuration-turbineinfo.component';

describe('BopConfigurationTurbineinfoComponent', () => {
  let component: BopConfigurationTurbineinfoComponent;
  let fixture: ComponentFixture<BopConfigurationTurbineinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopConfigurationTurbineinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopConfigurationTurbineinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
