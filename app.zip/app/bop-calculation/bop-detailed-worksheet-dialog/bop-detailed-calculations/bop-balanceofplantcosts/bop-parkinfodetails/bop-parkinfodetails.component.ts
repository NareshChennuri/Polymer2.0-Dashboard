import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { GlobalsService } from 'src/app/shared/api/globals.service';
import { Subject, Subscription } from 'rxjs';
import { DataService } from 'src/app/shared/api/data.service';

@Component({
  selector: 'app-bop-parkinfodetails',
  templateUrl: './bop-parkinfodetails.component.html',
  styleUrls: ['./bop-parkinfodetails.component.css']
})
export class BopParkinfodetailsComponent implements OnInit, OnDestroy {
  private currentCountrySubscribe: Subscription;
  private bopTurbineDefaultDataSubscribe: Subscription;
  private windParkDataSubscribe: Subscription;
  private parkMaxAreaSubscribe: Subscription;
  private getBopConfigurationElementsSubscribe: Subscription;
  private getBopParkElementsSubscribe: Subscription;
  bopParkInfo = {};
  gotoPage: Subject<any> = new Subject();
  currentCountry: any;
  bopConfigurationDefaults: any = [];

  constructor(
    private globals: GlobalsService,
    private dataService: DataService
  ) {
    this.currentCountrySubscribe = this.globals.currentCountry.subscribe(country => {
      this.currentCountry = country;
    });
    let groupId;
    let cataId;
    let taskId;
    this.bopTurbineDefaultDataSubscribe = this.globals.bopTurbineDefaultData.subscribe(
      turbDefaults => {
        if (turbDefaults && turbDefaults.length) {
          turbDefaults.map(groupDetails => {
            if (!groupId || groupId !== groupDetails.groupId) {
              groupId = groupDetails.groupId;
              const grpSrtDate = new Date(groupDetails.startDate);
              const startDate =
                grpSrtDate.toUTCString().split(' ')[1] +
                ' ' +
                grpSrtDate.toUTCString().split(' ')[2] +
                ' ' +
                grpSrtDate
                  .toUTCString()
                  .split(' ')[3]
                  .match(/\d{2}$/)[0];
              const grpEndDate = new Date(groupDetails.endDate);
              const endDate =
                grpEndDate.toUTCString().split(' ')[1] +
                ' ' +
                grpEndDate.toUTCString().split(' ')[2] +
                ' ' +
                grpEndDate
                  .toUTCString()
                  .split(' ')[3]
                  .match(/\d{2}$/)[0];
              const configBopData = {
                id: groupId,
                type: 'mainCategory',
                parentId: [],
                display: false,
                dor: groupDetails.dor,
                startDate: startDate,
                endDate: endDate,
                unitCost: groupDetails.price,
                qty: groupDetails.quantity,
                notes: groupDetails.notes,
                total: groupDetails.total
              };
              this.bopConfigurationDefaults.push(configBopData);
            } else if (!cataId || cataId !== groupDetails.categoryId) {
              cataId = groupDetails.categoryId;
              const grpSrtDate = new Date(groupDetails.startDate);
              const startDate =
                grpSrtDate.toUTCString().split(' ')[1] +
                ' ' +
                grpSrtDate.toUTCString().split(' ')[2] +
                ' ' +
                grpSrtDate
                  .toUTCString()
                  .split(' ')[3]
                  .match(/\d{2}$/)[0];
              const grpEndDate = new Date(groupDetails.endDate);
              const endDate =
                grpEndDate.toUTCString().split(' ')[1] +
                ' ' +
                grpEndDate.toUTCString().split(' ')[2] +
                ' ' +
                grpEndDate
                  .toUTCString()
                  .split(' ')[3]
                  .match(/\d{2}$/)[0];
              const configBopData = {
                id: cataId,
                type: 'subCategory',
                parentId: [groupDetails.groupId],
                display: false,
                dor: groupDetails.dor,
                startDate: startDate,
                endDate: endDate,
                unitCost: groupDetails.price,
                qty: groupDetails.quantity,
                notes: groupDetails.notes,
                total: groupDetails.total
              };
              this.bopConfigurationDefaults.push(configBopData);
            } else {
              taskId = groupDetails.taskId;
              const grpSrtDate = new Date(groupDetails.startDate);
              const startDate =
                grpSrtDate.toUTCString().split(' ')[1] +
                ' ' +
                grpSrtDate.toUTCString().split(' ')[2] +
                ' ' +
                grpSrtDate
                  .toUTCString()
                  .split(' ')[3]
                  .match(/\d{2}$/)[0];
              const grpEndDate = new Date(groupDetails.endDate);
              const endDate =
                grpEndDate.toUTCString().split(' ')[1] +
                ' ' +
                grpEndDate.toUTCString().split(' ')[2] +
                ' ' +
                grpEndDate
                  .toUTCString()
                  .split(' ')[3]
                  .match(/\d{2}$/)[0];
              const configBopData = {
                id: taskId,
                type: 'categoryItem',
                parentId: [groupDetails.groupId, groupDetails.categoryId],
                display: false,
                dor: groupDetails.dor,
                startDate: startDate,
                endDate: endDate,
                unitCost: groupDetails.price,
                qty: groupDetails.quantity,
                notes: groupDetails.notes,
                total: groupDetails.total
              };
              this.bopConfigurationDefaults.push(configBopData);
            }
          });
          this.bopParkInfo[
            'pinParkConfigBopData'
          ][0] = this.bopConfigurationDefaults;
        }
        this.updateGlobalBopData();
      }
    );
    this.bopParkInfo['pinDataFlag'] = false;
    this.bopParkInfo['compareDataFlag'] = false;
    this.bopParkInfo['turbineSelected'] = false;
    this.bopParkInfo['pinParkData'] = [];
    this.bopParkInfo['compareParkData'] = [];
    this.bopParkInfo['compareParkDataRemaining'] = [];
    this.bopParkInfo['pinParkSelectedTurbine'] = [];
    this.bopParkInfo['pinParkConfigBopData'] = [];
    this.bopParkInfo['compareParkConfigBopData'] = [];
    this.bopParkInfo['pinParkBopData'] = [];
    this.bopParkInfo['compareParkBopData'] = [];
  }

  ngOnInit() {
    // get global windpark data
    this.windParkDataSubscribe = this.globals.windParkData.subscribe(
      bopData => {
        this.bopParkInfo['bopData'] = bopData;
        if (this.bopParkInfo['bopData'] && this.bopParkInfo['bopData'].length) {
          this.arrangeParkData();
        }
        this.updateGlobalBopData();
      }
    );
    // on Max Area update
    this.parkMaxAreaSubscribe = this.globals.parkMaxArea.subscribe(value => {
      this.onMaxArea(value);
      this.updateGlobalBopData();
    });
    // get Country BOP Configuration & Park Elements
    if (this.currentCountry) {
      this.getBopConfigurationElementsSubscribe = this.dataService
        .getBopConfigurationElements({ countryId: this.currentCountry })
        .subscribe(turb => {
          if (turb && turb.length) {
            this.processElements(turb, 'TURB');
          }
        });
      this.getBopParkElementsSubscribe = this.dataService
        .getBopParkElements({ countryId: this.currentCountry })
        .subscribe(park => {
          if (park && park.length) {
            this.processElements(park, 'PARK');
          }
        });
    }
  }

  processElements(bopTurb, flag) {
    const mainData = [];
    if (bopTurb && bopTurb.length) {
      bopTurb.forEach(group => {
        const groupData = [];
        if (group.bopCategory && group.bopCategory.length) {
          group.bopCategory.forEach(cata => {
            const cataData = [];
            if (cata.bopTask && cata.bopTask.length) {
              cata.bopTask.forEach(task => {
                const taskName = {
                  name: {
                    categoryName: task.taskName,
                    display: false,
                    id: task.taskId,
                    parentId: [cata.categoryId],
                    uom: task.uomId
                  }
                };
                cataData.push(taskName);
              });
              const cataChild = {
                name: {
                  categoryName: cata.categoryName,
                  display: false,
                  id: cata.categoryId,
                  type: 'subCategory',
                  parentId: [group.groupId]
                },
                children: cataData
              };
              groupData.push(cataChild);
            } else {
              const cataChild = {
                name: {
                  categoryName: cata.categoryName,
                  display: false,
                  id: cata.categoryId,
                  type: 'subCategory',
                  parentId: [group.groupId]
                }
              };
              groupData.push(cataChild);
            }
          });
          const groupChild = {
            name: {
              categoryName: group.groupName,
              display: false,
              id: group.groupId,
              type: 'mainCategory'
            },
            children: groupData
          };
          mainData.push(groupChild);
        } else {
          const groupChild = {
            name: {
              categoryName: group.groupName,
              display: false,
              id: group.groupId,
              type: 'mainCategory'
            }
          };
          mainData.push(groupChild);
        }
      });
    }
    if (flag === 'TURB') {
      this.bopParkInfo['configurationBopCategoryData'] = mainData;
    } else {
      this.bopParkInfo['parkBopCategoryData'] = mainData;
    }
  }

  updateGlobalBopData() {
    this.globals.updateBopParkInfoDetails(this.bopParkInfo);
  }

  onMaxArea(maxArea: number) {
    this.bopParkInfo['bopData'].map(result => {
      result.selectedPCList.map(item => {
        item['spacing'] = +(Math.sqrt(+maxArea / +item.units) * 1000).toFixed(
          2
        );
      });
      return result;
    });
    this.updatePinPark(this.bopParkInfo['pinParkData'].parkId, true);
  }

  updatePinPark(parkId: number, flag: boolean) {
    if (this.bopParkInfo['bopData'] && this.bopParkInfo['bopData'].length) {
      this.bopParkInfo['pinParkData'] = this.bopParkInfo['bopData'].find(
        item => item.parkId === parkId
      );
      this.bopParkInfo['compareParkDataRemaining'] = this.bopParkInfo[
        'bopData'
      ];
      this.bopParkInfo['compareParkDataRemaining'] = this.bopParkInfo[
        'compareParkDataRemaining'
      ].filter(item => item.parkId !== parkId);
      if (!flag) {
        this.bopParkInfo['compareParkData'] = this.bopParkInfo[
          'compareParkDataRemaining'
        ][0];
        this.bopParkInfo['compareParkId'] = this.bopParkInfo['compareParkData'][
          'parkId'
        ];
      } else {
        // go to page
        const oldParkId = this.bopParkInfo['compareParkId'];
        setTimeout(() => {
          const pageId = this.bopParkInfo['compareParkDataRemaining']
            .map(i => i.parkId)
            .indexOf(oldParkId);
          this.notifyGotoPage(pageId + 1);
        }, 10);
      }
    }
  }

  updateUnpinPark() {
    if (this.bopParkInfo['bopData'] && this.bopParkInfo['bopData'].length) {
      this.bopParkInfo['pinParkData'] = '';
      this.bopParkInfo['compareParkDataRemaining'] = [];
      this.bopParkInfo['pinDataFlag'] = false;
      this.bopParkInfo['compareDataFlag'] = false;
      this.arrangeParkData();
      this.updateGlobalBopData();
    }
  }

  updateDefaultPark(parkId: number) {
    alert(parkId + ' - default parkId');
    this.updateGlobalBopData();
  }

  updateTurbineSelected($event) {
    this.globals.parkTurbineSelectEmit();
    this.bopParkInfo['turbineSelected'] = true;
    const configBopData = [
      {
        id: 101,
        type: 'mainCategory',
        parentId: [],
        display: false,
        dor: 'config1' + $event[0],
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 102,
        type: 'subCategory',
        parentId: [101],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 103,
        type: 'categoryItem',
        parentId: [101, 102],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 104,
        type: 'categoryItem',
        parentId: [101, 102],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 105,
        type: 'categoryItem',
        parentId: [101, 102],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 106,
        type: 'categoryItem',
        parentId: [101, 102],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 107,
        dor: 'Reason1',
        type: 'subCategory',
        parentId: [101],
        display: false,
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 108,
        type: 'categoryItem',
        parentId: [101, 107],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 109,
        type: 'categoryItem',
        parentId: [101, 107],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 110,
        type: 'categoryItem',
        parentId: [101, 107],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 111,
        type: 'categoryItem',
        parentId: [101, 107],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 112,
        type: 'mainCategory',
        parentId: [],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 113,
        type: 'subCategory',
        parentId: [112],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 114,
        type: 'categoryItem',
        parentId: [112, 113],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 115,
        type: 'categoryItem',
        parentId: [112, 113],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 116,
        type: 'categoryItem',
        parentId: [112, 113],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 117,
        type: 'categoryItem',
        parentId: [112, 113],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 118,
        type: 'subCategory',
        parentId: [112],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 119,
        type: 'categoryItem',
        parentId: [112, 118],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 120,
        type: 'categoryItem',
        parentId: [112, 118],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 121,
        type: 'categoryItem',
        parentId: [112, 118],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 122,
        type: 'categoryItem',
        parentId: [112, 118],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      }
    ];
    const parkBopData = [
      {
        id: 123,
        type: 'mainCategory',
        parentId: [],
        display: false,
        dor: 'park' + $event[0],
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 124,
        type: 'subCategory',
        parentId: [123],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 125,
        type: 'categoryItem',
        parentId: [123, 124],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 126,
        type: 'categoryItem',
        parentId: [123, 124],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 127,
        type: 'categoryItem',
        parentId: [123, 124],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 128,
        type: 'categoryItem',
        parentId: [123, 124],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 19',
        endDate: '09 Sept 19',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 129,
        type: 'subCategory',
        parentId: [123],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 130,
        type: 'categoryItem',
        parentId: [123, 129],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 131,
        type: 'categoryItem',
        parentId: [123, 129],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 132,
        type: 'categoryItem',
        parentId: [123, 129],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 133,
        type: 'categoryItem',
        parentId: [123, 129],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 134,
        type: 'mainCategory',
        parentId: [],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 135,
        type: 'subCategory',
        parentId: [134],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 136,
        type: 'categoryItem',
        parentId: [134, 135],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 137,
        type: 'categoryItem',
        parentId: [134, 135],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 138,
        type: 'categoryItem',
        parentId: [134, 135],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 139,
        type: 'categoryItem',
        parentId: [134, 135],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 140,
        type: 'subCategory',
        parentId: [134],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 141,
        type: 'categoryItem',
        parentId: [134, 140],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 142,
        type: 'categoryItem',
        parentId: [134, 140],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 143,
        type: 'categoryItem',
        parentId: [134, 140],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      },
      {
        id: 144,
        type: 'categoryItem',
        parentId: [134, 140],
        display: false,
        dor: 'Reason1',
        startDate: '09 Jan 2019',
        endDate: '09 Sept 2019',
        unitCost: '120',
        qty: '10',
        notes: 'abc',
        total: '123'
      }
    ];

    if ($event[2]) {
      // first Park turbine
      this.bopParkInfo['pinParkSelectedTurbine'][0] = {
        parkId: $event[0],
        turbineId: $event[1]
      };
      // this.bopParkInfo['pinParkConfigBopData'][0] = configBopData;
      this.bopParkInfo['compareParkConfigBopData'][0] = configBopData;
      this.bopParkInfo['pinParkBopData'][0] = parkBopData;
      this.bopParkInfo['compareParkBopData'][0] = parkBopData;
    } else {
      // second Park turbine
      this.bopParkInfo['pinParkSelectedTurbine'][1] = {
        parkId: $event[0],
        turbineId: $event[1]
      };
      // this.bopParkInfo['pinParkConfigBopData'][1] = configBopData;
      this.bopParkInfo['compareParkConfigBopData'][1] = configBopData;
      this.bopParkInfo['pinParkBopData'][1] = parkBopData;
      this.bopParkInfo['compareParkBopData'][1] = parkBopData;
    }
    this.updateGlobalBopData();
  }

  arrangeParkData() {
    // update pinPark & comparePark data to global bopData
    if (
      this.bopParkInfo['pinParkData'] &&
      this.bopParkInfo['pinParkData'].parkId
    ) {
      this.bopParkInfo['bopData'].map(result => {
        if (result.parkId === this.bopParkInfo['pinParkData'].parkId) {
          result = this.bopParkInfo['pinParkData'];
        }
      });
    }

    if (
      this.bopParkInfo['compareParkData'] &&
      this.bopParkInfo['compareParkData'].parkId
    ) {
      this.bopParkInfo['bopData'].map(result => {
        if (result.parkId === this.bopParkInfo['compareParkData'].parkId) {
          result = this.bopParkInfo['compareParkData'];
        }
      });
    }

    this.bopParkInfo['bopData'].forEach(item => {
      if (!this.bopParkInfo['pinParkData'].parkId) {
        this.bopParkInfo['pinParkData'] = item;
        this.bopParkInfo['pinDataFlag'] = true;
      } else {
        if (this.bopParkInfo['compareParkDataRemaining'].length === 0) {
          this.bopParkInfo['compareParkId'] = item.parkId;
          this.bopParkInfo['compareParkData'] = item;
        }
        this.bopParkInfo['compareParkDataRemaining'].push(item);
      }
    });
    if (this.bopParkInfo['compareParkId']) {
      this.bopParkInfo['compareDataFlag'] = true;
    }
    this.updateGlobalBopData();
  }

  onChangePage(pageOfItems: Array<any>) {
    if (pageOfItems.length) {
      // update current page of items
      this.bopParkInfo['compareParkId'] = pageOfItems[0]['parkId'];
      const compareParkData = this.bopParkInfo['bopData'].find(
        item => item.parkId === pageOfItems[0]['parkId']
      );
      this.bopParkInfo['compareParkData'] = compareParkData;
      this.updateGlobalBopData();
    }
  }

  notifyGotoPage(pageId: number) {
    this.gotoPage.next(pageId);
    this.updateGlobalBopData();
  }

  ngOnDestroy() {
    if (this.currentCountrySubscribe) {
      this.currentCountrySubscribe.unsubscribe();
    }
    if (this.getBopParkElementsSubscribe) {
      this.getBopParkElementsSubscribe.unsubscribe();
    }
    if (this.bopTurbineDefaultDataSubscribe) {
      this.bopTurbineDefaultDataSubscribe.unsubscribe();
    }
    if (this.windParkDataSubscribe) {
      this.windParkDataSubscribe.unsubscribe();
    }
    if (this.parkMaxAreaSubscribe) {
      this.parkMaxAreaSubscribe.unsubscribe();
    }
    if (this.getBopConfigurationElementsSubscribe) {
      this.getBopConfigurationElementsSubscribe.unsubscribe();
    }
  }
}
