import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopConfigurationComponent } from './bop-configuration.component';

describe('BopConfigurationComponent', () => {
  let component: BopConfigurationComponent;
  let fixture: ComponentFixture<BopConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
