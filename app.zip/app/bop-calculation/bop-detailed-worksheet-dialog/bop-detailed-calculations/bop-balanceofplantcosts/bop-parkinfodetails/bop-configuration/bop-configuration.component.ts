import { Subscription } from 'rxjs';
import {
  Component,
  OnInit,
  Input,
  AfterViewInit,
  ViewChild,
  OnDestroy
} from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import {
  MatTreeFlatDataSource,
  MatTreeFlattener
} from '@angular/material/tree';
import { GlobalsService } from 'src/app/shared/api/globals.service';
import { TooltipPosition } from '@angular/material';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { BopDatasetEditDialogComponent } from '../bop-dataset-edit/bop-dataset-edit-dialog.component';

interface FoodNode {
  name: string[];
  children?: FoodNode[];
}

interface ExampleFlatNode {
  expandable: boolean;
  name: string[];
  level: number;
}

const _transformer = (node: FoodNode, level: number) => {
  return {
    expandable: !!node.children && node.children.length > 0,
    name: node.name,
    level: level
  };
};

@Component({
  selector: 'app-bop-configuration',
  templateUrl: './bop-configuration.component.html',
  styleUrls: ['./bop-configuration.component.css']
})
export class BopConfigurationComponent
  implements OnInit, AfterViewInit, OnDestroy {
  private bopParkInfoDataSubscribe: Subscription;
  private parkTurbineSelectEmitterSubscribe: Subscription;
  private afterClosedSubscribe: Subscription;
  bopParkInfo: any;
  data: any;
  dialogueDataSource = new MatTableDataSource<any>([]);
  @Input() type: string;
  @ViewChild('tree') tree;
  positionOptions: TooltipPosition[] = [
    'after',
    'before',
    'above',
    'below',
    'left',
    'right'
  ];
  position = this.positionOptions[0];

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    node => node.level,
    node => node.expandable
  );

  treeFlattener = new MatTreeFlattener(
    _transformer,
    node => node.level,
    node => node.expandable,
    node => node.children
  );

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

  constructor(private globals: GlobalsService, public dialog: MatDialog) {}

  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;

  ngOnInit() {
    this.bopParkInfoDataSubscribe = this.globals.bopParkInfoData.subscribe(
      bopParkInfo => {
        this.bopParkInfo = bopParkInfo;
        this.data = this.bopParkInfo[this.type];
      }
    );
    this.dataSource.data = this.data;
    this.parkTurbineSelectEmitterSubscribe = this.globals.parkTurbineSelectEmitter.subscribe(
      () => {
        this.tree.treeControl.collapseAll();
        this.collapseAllRecords();
      }
    );
  }

  ngAfterViewInit() {
    this.tree.treeControl.collapseAll();
  }

  categoryClick(event: any) {
    const id = event.categoryId;
    const display = event.isOpen;
    if (!display) {
      this.treeControl.collapseDescendants(event.node);
    }
    const type = this.type;
    const catData = this.bopParkInfo[this.type];
    let categoryType = '';
    if (catData && catData.length) {
      catData.map(item => {
        if (+item.name.id === +id) {
          item.name.display = display;
          categoryType = item.name.type;
        } else if (item.children && item.children.length) {
          item.children.map(children => {
            if (+children.name.id === +id) {
              children.name.display = display;
              categoryType = children.name.type;
            }
          });
        }
      });
    }
    this.toggleRecords({ id, display, type, categoryType, catData });
  }

  toggleRecords(toggleData) {
    let pinBopRecords = '';
    let compareBopRecords = '';
    if (toggleData.type === 'parkBopCategoryData') {
      pinBopRecords = 'pinParkBopData';
      compareBopRecords = 'compareParkBopData';
    } else if (toggleData.type === 'configurationBopCategoryData') {
      pinBopRecords = 'pinParkConfigBopData';
      compareBopRecords = 'compareParkConfigBopData';
    }
    if (
      this.bopParkInfo[pinBopRecords] &&
      this.bopParkInfo[pinBopRecords].length
    ) {
      this.bopParkInfo[pinBopRecords].map(item => {
        item = this.checkToggle(
          item,
          toggleData.id,
          toggleData.display,
          toggleData.categoryType
        );
      });
    }
    if (
      this.bopParkInfo[compareBopRecords] &&
      this.bopParkInfo[compareBopRecords].length
    ) {
      this.bopParkInfo[compareBopRecords].map(item => {
        item = this.checkToggle(
          item,
          toggleData.id,
          toggleData.display,
          toggleData.categoryType
        );
      });
    }
    this.bopParkInfo[this.type] = toggleData.catData;
    this.collapseSubCategoryIfMainCategoryfalse();
    this.globals.updateBopParkInfoDetails(this.bopParkInfo);
  }

  checkToggle(data, parentId, flag, categoryType) {
    if (data && data.length) {
      data.map(item => {
        if (categoryType === 'mainCategory') {
          if (item.type === 'subCategory') {
            if (item.parentId.indexOf(+parentId) !== -1) {
              item.display = flag;
            }
          }
          if (!flag) {
            if (item.type === 'categoryItem') {
              if (item.parentId.indexOf(+parentId) !== -1) {
                item.display = flag;
              }
            }
          }
        }
        if (categoryType === 'subCategory') {
          if (item.type === 'categoryItem') {
            if (item.parentId.indexOf(+parentId) !== -1) {
              item.display = flag;
            }
          }
        }
      });
    }
    return data;
  }

  collapseAllRecords() {
    const dataList = [
      'pinParkBopData',
      'compareParkBopData',
      'pinParkConfigBopData',
      'compareParkConfigBopData'
    ];

    dataList.map(data => {
      if (this.bopParkInfo[data] && this.bopParkInfo[data].length) {
        this.bopParkInfo[data].map(item => {
          if (item && item.length) {
            item.map(i => {
              i.display = false;
            });
          }
        });
      }
    });
    const catList = ['configurationBopCategoryData', 'parkBopCategoryData'];
    catList.map(data => {
      if (this.bopParkInfo[data] && this.bopParkInfo[data].length) {
        this.bopParkInfo[data].map(item => {
          item.name.display = false;
          if (item.children && item.children.length) {
            item.children.map(children => {
              children.name.display = false;
            });
          }
        });
      }
    });
    this.globals.updateBopParkInfoDetails(this.bopParkInfo);
  }

  collapseSubCategoryIfMainCategoryfalse() {
    const catList = ['configurationBopCategoryData', 'parkBopCategoryData'];
    catList.map(data => {
      if (this.bopParkInfo[data] && this.bopParkInfo[data].length) {
        this.bopParkInfo[data].map(item => {
          if (item.name.type === 'mainCategory') {
            if (!item.name.display) {
              if (item.children && item.children.length) {
                item.children.map(child => {
                  child.name.display = false;
                });
              }
            }
          }
        });
      }
    });
  }

  openActionDialog(id: any) {
      const data = {
        record: {
          parentId: id,
          id: 1,
          categoryName: '',
          uom: '',
          dorSelector: '',
          startDate: new Date(),
          endDate: new Date(),
          unitCost: '0',
          quantity: '0',
          notes: '',
          total: '0'
        },
        dorSelectorListItems: [
          { id: '1', name: 'dor1' },
          { id: '2', name: 'dor2' }
        ],
        flag: 'addDataset'
      };

      const dialogRef = this.dialog.open(BopDatasetEditDialogComponent, {
        width: '1100px',
        data: data
      });
      this.afterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
        if (result) {
          debugger;
          // this.saveBopDatasetRecordSubscribe = this.dataService
          //   .saveBopDatasetRecord(result.record)
          //   .subscribe(editStatus => {
          //     if (editStatus.message) {
          //       this.toastr.success(`${editStatus.message} !!`);
          //     }
          //     this.getFinanceRecordList();
          //   });
        }
        if (!result) {
          // const dataSource = this.dataSource.data.map(obj => {
          // if (obj.id === id) {
          //   obj = this.selectedRecord;
          // }
          // return obj;
          // });
          // this.dataSource.data = dataSource;
        }
      });
  }

  ngOnDestroy() {
    if (this.bopParkInfoDataSubscribe) {
      this.bopParkInfoDataSubscribe.unsubscribe();
    }
    if (this.parkTurbineSelectEmitterSubscribe) {
      this.parkTurbineSelectEmitterSubscribe.unsubscribe();
    }
    if (this.afterClosedSubscribe) {
      this.afterClosedSubscribe.unsubscribe();
    }
  }
}
