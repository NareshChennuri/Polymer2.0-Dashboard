import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopBalanceofplantcostsComponent } from './bop-balanceofplantcosts.component';

describe('BopBalanceofplantcostsComponent', () => {
  let component: BopBalanceofplantcostsComponent;
  let fixture: ComponentFixture<BopBalanceofplantcostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopBalanceofplantcostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopBalanceofplantcostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
