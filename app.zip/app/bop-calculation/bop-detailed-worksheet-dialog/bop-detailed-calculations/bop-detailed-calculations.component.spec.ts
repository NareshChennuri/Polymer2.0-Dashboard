import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopDetailedCalculationsComponent } from './bop-detailed-calculations.component';

describe('BopDetailedCalculationsComponent', () => {
  let component: BopDetailedCalculationsComponent;
  let fixture: ComponentFixture<BopDetailedCalculationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopDetailedCalculationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopDetailedCalculationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
