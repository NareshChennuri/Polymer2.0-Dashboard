import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopInputsComponent } from './bop-inputs.component';

describe('BopInputsComponent', () => {
  let component: BopInputsComponent;
  let fixture: ComponentFixture<BopInputsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopInputsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopInputsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
