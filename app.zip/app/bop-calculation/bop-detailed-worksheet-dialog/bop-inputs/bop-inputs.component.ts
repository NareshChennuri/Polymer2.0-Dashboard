import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';

export interface TurbineUserInputs {
  turbineName: string;
  hubHeight: number;
  towerType: object[];
  parklayout: object[];
  landType: object[];
  terrainType: object[];
  oemScope: object[];
  transInBopScope: object[];
  numberOfTurbines: number;
  farmMW: number;
}

const turbineUserInputsData: TurbineUserInputs[] = [
  {
    turbineName: 'GE 3.63 137 Rev2',
    hubHeight: 110,
    towerType: [{ id: 1, name: 'Tubular Steel' }, { id: 2, name: 'Hybrid' }],
    parklayout: [{ id: 1, name: 'Cluster' }, { id: 2, name: 'Lines' }],
    landType: [{ id: 1, name: 'Ranch Land' }, { id: 2, name: 'Agriculture' }],
    terrainType: [{ id: 1, name: 'Normal' }, { id: 2, name: 'Rocks' }],
    oemScope: [{ id: 1, name: 'eLI' }, { id: 2, name: 'eLIF' }],
    transInBopScope: [{ id: 1, name: 'No' }, { id: 2, name: 'Yes' }],
    numberOfTurbines: 8,
    farmMW: 3.6
  }
];
const defaultInputValuesData = [
  [
    { key: 'Foundation', name: 'Fixed Cost', value: '360000', type: 'USD/park' },
    { key: 'Foundation', name: 'Other Materials Cost', value: '180.00', type: 'USD/Yd3 of concrete' }
  ],
  [
    {
      key: 'Civil Works',
      name: 'Access road/Town Upgrade Cost',
      value: '0.00',
      type: 'USD/Park'
    }
  ]
];

const defaultInputValuesData2 = [
  [
    {
      key: 'Installation',
      name: 'Crane Availability',
      value: [{ id: '1', name: 'Normal' }],
      type: ''
    }
  ],
  [
    {
      key: 'Elec Collection & Communication',
      name: 'Cabling Option',
      value: [{ id: '1', name: 'Underground' }],
      type: ''
    },
    {
      key: 'Elec Collection & Communication',
      name: 'ElecColl Fixed Cost',
      value: '480000',
      type: 'USD/Turb'
    }
  ],

  [
    {
      key: 'O&M Building & MET tower',
      name: 'O&M Building Capacity',
      value: '60',
      type: 'Turb/Bldg'
    }
  ],
  [
    {
      key: 'Transformer',
      name: 'Transformer Install Cost',
      value: '45000',
      type: 'USD/trubine'
    }
  ],
  [
    {
      key: 'Site Superv',
      name: 'Site Supervision Exponent',
      value: '-0.83',
      type: ''
    }
  ],
  [
    {
      key: 'Substation',
      name: 'Power Conditioning Equipment',
      value: [{ id: '1', name: 'No' }],
      type: ''
    }
  ],
  [
    {
      key: 'Transmission',
      name: 'Transmission Distance',
      value: '10.00',
      type: 'Km'
    }
  ],
  [{ key: 'Finance/Margin', name: 'Contingency', value: '0.10', type: '%' }]
];

@Component({
  selector: 'app-bop-inputs',
  templateUrl: './bop-inputs.component.html',
  styleUrls: ['./bop-inputs.component.css']
})
export class BopInputsComponent implements OnInit {
  dataSource = turbineUserInputsData;
  defaultValuesDataSource = defaultInputValuesData;
  defaultValuesDataSource2 = defaultInputValuesData2;
  displayedColumns: string[] = [
    'turbineName',
    'hubHeight',
    'towerType',
    'parklayout',
    'landType',
    'terrainType',
    'oemScope',
    'transInBopScope',
    'numberOfTurbines',
    'farmMW'
  ];
  constructor() {}

  ngOnInit() {}
}
