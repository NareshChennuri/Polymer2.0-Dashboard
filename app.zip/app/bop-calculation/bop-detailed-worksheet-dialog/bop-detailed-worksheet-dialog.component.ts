import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';
import { GlobalsService } from '../../shared/api/globals.service';

@Component({
  selector: 'app-bop-detailed-worksheet-dialog',
  templateUrl: './bop-detailed-worksheet-dialog.component.html',
  styleUrls: ['./bop-detailed-worksheet-dialog.component.css']
})
export class BopDetailedWorksheetDialogComponent implements OnInit, OnDestroy {
  private currentCountryNameSubscribe: Subscription;
  country: string;
  constructor(
    public dialogRef: MatDialogRef<{}>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private globals: GlobalsService
  ) {
    this.currentCountryNameSubscribe = this.globals.currentCountryName.subscribe(
      country => {
        this.country = country;
      }
    );
  }

  ngOnInit() {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnDestroy() {
    if (this.currentCountryNameSubscribe) {
      this.currentCountryNameSubscribe.unsubscribe();
    }
  }
}
