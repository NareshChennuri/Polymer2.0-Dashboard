import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';
import { GlobalsService } from '../../shared/api/globals.service';

@Component({
  selector: 'app-bop-dialog',
  templateUrl: './bop-dialog.component.html',
  styleUrls: ['./bop-dialog.component.css']
})
export class BopDialogComponent implements OnInit, OnDestroy {
  private currentCountryNameSubscribe: Subscription;
  bopOption = '2';
  country: string;
  constructor(
    public dialogRef: MatDialogRef<{}>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private globals: GlobalsService
  ) {
    this.currentCountryNameSubscribe = this.globals.currentCountryName.subscribe(
      country => {
        this.country = country;
      }
    );
  }

  ngOnInit() {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnDestroy() {
    if (this.currentCountryNameSubscribe) {
      this.currentCountryNameSubscribe.unsubscribe();
    }
  }
}
