import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopDialogComponent } from './bop-dialog.component';

describe('BopDialogComponent', () => {
  let component: BopDialogComponent;
  let fixture: ComponentFixture<BopDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
