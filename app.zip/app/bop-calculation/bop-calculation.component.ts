import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { BopDialogComponent } from './bop-dialog/bop-dialog.component';
import { ProjectEconomicsDetailsComponent } from '../project-economics-details/project-economics-details.component';
import { BopDetailedWorksheetDialogComponent } from './bop-detailed-worksheet-dialog/bop-detailed-worksheet-dialog.component';
import { GlobalsService } from '../shared/api/globals.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-bop-calculation',
  templateUrl: './bop-calculation.component.html',
  styleUrls: ['./bop-calculation.component.css']
})
export class BopCalculationComponent implements OnInit, OnDestroy {
  private bopValueSubscribe: Subscription;
  private bopAfterClosedSubscribe: Subscription;
  private bopDetailedAfterClosedSubscribe: Subscription;
  bopValue: string;
  @Output() openUpdateBOP = new EventEmitter<{}>();

  constructor(public dialog: MatDialog, private _globals: GlobalsService) {
    this.bopValueSubscribe = this._globals.bopValue.subscribe(value => {
      this.bopValue = value;
    });
  }

  ngOnInit() {}

  openBOP() {
    const data = {};
    const record = {
      perMW: this.bopValue
    };
    data['record'] = record;
    const dialogRef = this.dialog.open(BopDialogComponent, {
      width: '700px',
      data: data
    });
    this.bopAfterClosedSubscribe = dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (result.record.perMW) {
          // Bop per MW calculation
          this._globals.changeBopValue(result.record.perMW);
          this.updateBOP();
        } else {
          // open the BOP detailed worksheet dialog
          this.openBopDetailedCalculation();
        }
      }
    });
  }

  openBopDetailedCalculation() {
    const data = {};
    const record = {};
    data['record'] = record;
    const dialogRef = this.dialog.open(BopDetailedWorksheetDialogComponent, {
      width: '1300px',
      height: '650px',
      data: data
    });
    this.bopDetailedAfterClosedSubscribe = dialogRef
      .afterClosed()
      .subscribe(result => {
        if (result) {
          // if (result.record.perMW) {
          // Bop per MW calculation
          //   console.log('Bop per MW calculation');
          // } else {
          // open the BOP detailed worksheet dialog
          // }
        }
      });
  }

  updateBOP() {
    this.openUpdateBOP.emit({});
  }

  ngOnDestroy() {
    if (this.bopValueSubscribe) {
      this.bopValueSubscribe.unsubscribe();
    }
    if (this.bopAfterClosedSubscribe) {
      this.bopAfterClosedSubscribe.unsubscribe();
    }
    if (this.bopDetailedAfterClosedSubscribe) {
      this.bopDetailedAfterClosedSubscribe.unsubscribe();
    }
  }
}
