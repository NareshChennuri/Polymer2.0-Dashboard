import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BopCalculationComponent } from './bop-calculation.component';

describe('BopCalculationComponent', () => {
  let component: BopCalculationComponent;
  let fixture: ComponentFixture<BopCalculationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BopCalculationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BopCalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
