import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { MarketDataComponent } from '../market-data/market-data.component';
import { TurbineDetailsComponent } from '../turbine-details/turbine-details.component';
import { ProjectEconomicsDetailsComponent } from '../project-economics-details/project-economics-details.component';
import { BopCalculationComponent } from '../bop-calculation/bop-calculation.component';
import { ActivatedRoute } from '@angular/router';
import { GlobalsService } from '../shared/api/globals.service';
import { CommentsDetailsComponent } from '../comments-details/comments-details.component';
import { CompareDetailsComponent } from '../compare-details/compare-details.component';
import { ProjectResultDetailsComponent } from '../project-result-details/project-result-details.component';
import { ParkCommentsComponent } from '../comments-details/park-comments/park-comments.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-actions',
  templateUrl: './actions.component.html',
  styleUrls: ['./actions.component.css']
})
export class ActionsComponent implements OnInit, OnDestroy {
  private paramMapSubscription: Subscription;
  private goalSeekLabelSubscription: Subscription;
  private goalSeekDataSubscription: Subscription;
  currrentSession: any;
  selectedSession: any;
  @ViewChild('projectEconomicsDetails')
  projectEconomicsDetails: ProjectEconomicsDetailsComponent;

  @ViewChild('projectResultDetails')
  projectResultDetails: ProjectResultDetailsComponent;

  @ViewChild('bopCalculation')
  bopCalculation: BopCalculationComponent;

  @ViewChild('parkCommentsDetails')
  parkCommentsDetails: ParkCommentsComponent;

  goalSeekDetails: any[] = [];
  goalSeekLabel: any;

  constructor(
    private route: ActivatedRoute,
    private _globals: GlobalsService
  ) {}

  ngOnInit() {
    this.paramMapSubscription = this.route.paramMap.subscribe(params => {
      this.currrentSession = params.get('id');
      this._globals.changeSesssion(this.currrentSession);
    });
    this.goalSeekLabelSubscription = this._globals.goalSeekLabel.subscribe(
      label => {
        this.goalSeekLabel = label;
      }
    );
    this.goalSeekDataSubscription = this._globals.goalSeekData.subscribe(
      goal => {
        if (goal) {
          this.goalSeekDetails = goal;
        }
      }
    );
  }

  onAddTrubine(trbInfo) {
    this.projectEconomicsDetails.addEnergy(trbInfo.trbData);
    this.projectResultDetails.addProjectResult(trbInfo.trbData);
    this.parkCommentsDetails.addParkComment(trbInfo.trbData);
  }
  onDeleteTurbine(trbI) {
    this.projectEconomicsDetails.deleteParkInfo(trbI);
    this.projectResultDetails.deleteProjectResultInfo(trbI);
    this.parkCommentsDetails.deleteParkComment(trbI);
  }

  onOpenBOP() {
    this.bopCalculation.openBOP();
  }

  updateBopValue() {
    this.projectEconomicsDetails.updateBOP();
  }

  updateParkDetails() {
    this.projectEconomicsDetails.updateParkDetails();
  }

  ngOnDestroy() {
    if (this.paramMapSubscription) {
      this.paramMapSubscription.unsubscribe();
    }
    if (this.goalSeekLabelSubscription) {
      this.goalSeekLabelSubscription.unsubscribe();
    }
    if (this.goalSeekDataSubscription) {
      this.goalSeekDataSubscription.unsubscribe();
    }
  }
}
