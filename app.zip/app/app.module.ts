import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { HttpClientModule } from '@angular/common/http';
import { NgHttpLoaderModule } from 'ng-http-loader';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { NgModule } from '@angular/core';
import 'hammerjs';
import {MatMenuModule} from '@angular/material/menu';

import { MatComponentsModule } from './mat-components.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DraggableDialogDirective } from './shared/utility/directives/draggable-dialog.directive';
import { NumbersOnlyDirective } from './shared/utility/directives/numbers-only.directive';
import {
  TRANSLATION_PROVIDERS,
  TranslatePipe,
  TranslateService
} from './shared/utility/translate';
import {
  MatMomentDateModule,
  MAT_MOMENT_DATE_FORMATS
} from '@angular/material-moment-adapter';
import { MomentUtcDateAdapter } from './moment-utc-date-adapter';
import {
  MAT_DATE_FORMATS,
  DateAdapter,
  MAT_DATE_LOCALE
} from '@angular/material';

import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { MarketDataComponent } from './market-data/market-data.component';
import { RevenueStreamComponent } from './market-data/revenue-stream/revenue-stream.component';
import { AddRevenueStreamDialogComponent } from './market-data/revenue-stream/add-revenue-stream/add-revenue-stream-dialog.component';
import { RevenueStreamEditDialogComponent } from './market-data/revenue-stream/revenue-stream-edit/revenue-stream-edit-dialog.component';
import { OperationCostComponent } from './market-data/operation-cost/operation-cost.component';
import { AddOperationCostDialogComponent } from './market-data/operation-cost/add-operation-cost/add-operation-cost-dialog.component';
import { OperationCostEditDialogComponent } from './market-data/operation-cost/operation-cost-edit/operation-cost-edit-dialog.component';
import { InformationComponent } from './information/information.component';
import { SelectRoutesComponent } from './shared/select-routes/select-routes.component';
import { TurbineDetailsComponent } from './turbine-details/turbine-details.component';
import { TariffFinanceComponent } from './market-data/tariff-finance/tariff-finance.component';
import { TariffFinanceEditDialogComponent } from './market-data/tariff-finance/tariff-finance-edit/tariff-finance-edit-dialog.component';
import { FinancialModellingComponent } from './financial-modelling/financial-modelling.component';
import { ProjOpCostComponent } from './proj-op-cost/proj-op-cost.component';
import { PcInfoEditComponent } from './turbine-details/pc-info-edit/pc-info-edit.component';
import { AddTariffFinanceDialogComponent } from './market-data/tariff-finance/add-tariff-finance/add-tariff-finance-dialog.component';
import { MySessionsComponent } from './dashboard/my-sessions/my-sessions.component';
import { ActionsComponent } from './actions/actions.component';
import { RecentSessionsComponent } from './dashboard/recent-sessions/recent-sessions.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TaxDepreciationComponent } from './market-data/tax-depreciation/tax-depreciation.component';
import { AddTaxDeprDialogComponent } from './market-data/tax-depreciation/add-tax-depr/add-tax-depr-dialog.component';
import { EditTaxDeprDialogComponent } from './market-data/tax-depreciation/edit-tax-depr/edit-tax-depr-dialog.component';
import { SessionCaseComponent } from './market-data/session-case/session-case.component';
import { CloneSessionCaseComponent } from './market-data/session-case/clone-session-case/clone-session-case.component';
import { AddSessionCaseComponent } from './market-data/session-case/add-session-case/add-session-case.component';
import { HeaderInfoComponent } from './market-data/header-info/header-info.component';
import { ProjectEconomicsDetailsComponent } from './project-economics-details/project-economics-details.component';
import { ProjEconomicsDialogComponent } from './project-economics-details/proj-economics-dialog/proj-economics-dialog.component';
import { ProjectResultDetailsComponent } from './project-result-details/project-result-details.component';
import { CommentsDetailsComponent } from './comments-details/comments-details.component';
import { CompareDetailsComponent } from './compare-details/compare-details.component';
import { BopCalculationComponent } from './bop-calculation/bop-calculation.component';
import { BopDialogComponent } from './bop-calculation/bop-dialog/bop-dialog.component';
// tslint:disable-next-line:max-line-length
import { BopDetailedWorksheetDialogComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-worksheet-dialog.component';
import { BopSummaryComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-summary/bop-summary.component';
import { BopInputsComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-inputs/bop-inputs.component';
// tslint:disable-next-line:max-line-length
import { BopDetailedCalculationsComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-detailed-calculations.component';
import { BopOutputSummaryComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-output-summary/bop-output-summary.component';
import { ProformaReportsComponent } from './proforma-reports/proforma-reports.component';
import { YearlyProformaComponent } from './proforma-reports/yearly-proforma/yearly-proforma.component';
import { ConsolidatedProformaComponent } from './proforma-reports/consolidated-proforma/consolidated-proforma.component';
// tslint:disable-next-line:max-line-length
import { ProjEconomicsEditComponent } from './project-economics-details/proj-economics-dialog/proj-economics-edit/proj-economics-edit.component';
// tslint:disable-next-line:max-line-length
import { ProjEconomicsAddComponent } from './project-economics-details/proj-economics-dialog/proj-economics-add/proj-economics-add.component';
import { ParkCommentsComponent } from './comments-details/park-comments/park-comments.component';
import { ErrorCalculationDialogComponent } from './market-data/header-info/error-calculation-dialog/error-calculation-dialog.component';
//import { BopPlantcostsComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-plantcosts/bop-plantcosts.component';
import { BopBalanceofplantcostsComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-balanceofplantcosts/bop-balanceofplantcosts.component';
import { BopGlobaldetailsComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-balanceofplantcosts/bop-globaldetails/bop-globaldetails.component';
import  { BopParkinfodetailsComponent }   from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-balanceofplantcosts/bop-parkinfodetails/bop-parkinfodetails.component';
import { BopParkinfoTurbinContainerComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-balanceofplantcosts/bop-parkinfodetails/bop-parkinfo-turbin-container/bop-parkinfo-turbin-container.component';
import { CompareParkPCComponent } from './turbine-details/compare-park-pc/compare-park-pc.component';
import { GoalSeekComponent } from './market-data/header-info/goal-seek/goal-seek.component';
import { WsPaginationComponent } from './shared/utility/ws-pagination.component';
import { PowerCurveComponent } from './power-curve/power-curve.component';
import { BopConfigurationComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-balanceofplantcosts/bop-parkinfodetails/bop-configuration/bop-configuration.component';
import { BopConfigurationTurbineinfoComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-balanceofplantcosts/bop-parkinfodetails/bop-configuration-turbineinfo/bop-configuration-turbineinfo.component';
import { BopDatasetEditDialogComponent } from './bop-calculation/bop-detailed-worksheet-dialog/bop-detailed-calculations/bop-balanceofplantcosts/bop-parkinfodetails/bop-dataset-edit/bop-dataset-edit-dialog.component';
export const DateFormat = {
  parse: {
    dateInput: 'input'
  },
  display: {
    dateInput: 'DD-MMM-YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'MM/DD/YYYY',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SelectRoutesComponent,
    DraggableDialogDirective,
    MarketDataComponent,
    RevenueStreamComponent,
    AddRevenueStreamDialogComponent,
    RevenueStreamEditDialogComponent,
    OperationCostComponent,
    AddOperationCostDialogComponent,
    OperationCostEditDialogComponent,
    PcInfoEditComponent,
    InformationComponent,
    TurbineDetailsComponent,
    FinancialModellingComponent,
    ProjOpCostComponent,
    NumbersOnlyDirective,
    TranslatePipe,
    TariffFinanceComponent,
    TariffFinanceEditDialogComponent,
    AddTariffFinanceDialogComponent,
    MySessionsComponent,
    ActionsComponent,
    RecentSessionsComponent,
    DashboardComponent,
    ActionsComponent,
    TaxDepreciationComponent,
    AddTaxDeprDialogComponent,
    EditTaxDeprDialogComponent,
    SessionCaseComponent,
    CloneSessionCaseComponent,
    AddSessionCaseComponent,
    ProjectEconomicsDetailsComponent,
    CommentsDetailsComponent,
    CompareDetailsComponent,
    ProjectResultDetailsComponent,
    ProjEconomicsDialogComponent,
    HeaderInfoComponent,
    BopCalculationComponent,
    BopDialogComponent,
    BopDetailedWorksheetDialogComponent,
    BopSummaryComponent,
    BopInputsComponent,
    BopDetailedCalculationsComponent,
    BopOutputSummaryComponent,
    ProformaReportsComponent,
    ConsolidatedProformaComponent,
    YearlyProformaComponent,
    ProjEconomicsEditComponent,
    ProjEconomicsAddComponent,
    ParkCommentsComponent,
    ErrorCalculationDialogComponent,
   //BopPlantcostsComponent,
    BopBalanceofplantcostsComponent,
    BopGlobaldetailsComponent,
    BopParkinfodetailsComponent,
    BopParkinfoTurbinContainerComponent,
    CompareParkPCComponent,
    GoalSeekComponent,
    WsPaginationComponent,
    PowerCurveComponent,
    BopConfigurationComponent,
    BopConfigurationTurbineinfoComponent,
    BopDatasetEditDialogComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    NgHttpLoaderModule.forRoot(),
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    MatComponentsModule,
    AngularSvgIconModule,
    MatMomentDateModule,
    MatMenuModule
  ],
  entryComponents: [
    AddRevenueStreamDialogComponent,
    RevenueStreamEditDialogComponent,
    TariffFinanceEditDialogComponent,
    AddTariffFinanceDialogComponent,
    PcInfoEditComponent,
    AddTaxDeprDialogComponent,
    EditTaxDeprDialogComponent,
    AddOperationCostDialogComponent,
    OperationCostEditDialogComponent,
    CloneSessionCaseComponent,
    AddSessionCaseComponent,
    ProjEconomicsDialogComponent,
    ProjEconomicsAddComponent,
    ProjEconomicsEditComponent,
    BopDialogComponent,
    BopDetailedWorksheetDialogComponent,
    ErrorCalculationDialogComponent,
    CompareParkPCComponent,
    GoalSeekComponent,
    BopDatasetEditDialogComponent
  ],
  providers: [
    TRANSLATION_PROVIDERS,
    TranslateService,
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    { provide: MAT_DATE_FORMATS, useValue: DateFormat },
    { provide: DateAdapter, useClass: MomentUtcDateAdapter }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
