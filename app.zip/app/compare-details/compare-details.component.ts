import { Component } from '@angular/core';


@Component({
  selector: 'app-compare-details',
  templateUrl: './compare-details.component.html',
  styleUrls: ['./compare-details.component.css']
})
export class CompareDetailsComponent {}
