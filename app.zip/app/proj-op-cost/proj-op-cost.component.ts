import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proj-op-cost',
  templateUrl: './proj-op-cost.component.html',
  styleUrls: ['./proj-op-cost.component.css']
})
export class ProjOpCostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
