import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjOpCostComponent } from './proj-op-cost.component';

describe('ProjOpCostComponent', () => {
  let component: ProjOpCostComponent;
  let fixture: ComponentFixture<ProjOpCostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjOpCostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjOpCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
