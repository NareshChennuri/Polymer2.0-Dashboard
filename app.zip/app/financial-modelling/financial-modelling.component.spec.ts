import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialModellingComponent } from './financial-modelling.component';

describe('FinancialModellingComponent', () => {
  let component: FinancialModellingComponent;
  let fixture: ComponentFixture<FinancialModellingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialModellingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialModellingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
