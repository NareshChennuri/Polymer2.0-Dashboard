define(['./sample-module', './sample-directive', './sample-filter', './sample-service', './dashboard-controller', './actions-controller', './admins-controller',
    './sample-controller', './alert-controller', './predix-asset-service', './alert-service', './predix-user-service', './predix-view-service'], function() {

});
