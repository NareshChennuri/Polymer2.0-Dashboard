define(['angular', './sample-module'], function(angular, sampleModule) {
    'use strict';
    return sampleModule.controller('alertCtrl', ['$scope', 'alertService', function($scope, alertService) {
		$scope.iconname = "fa fa-exclamation-triangle icon";
		$scope.containerHeading = 'GV_VTM_STEP';
		$scope.containerHeadingDate = '09-21-2016 01:28:00 PM EST';
		$scope.containerHeadingDataOne = 'Vibration';
		$scope.containerHeadingDataTwo = 'In Proces';
       alertService.getAlert().then(function(result) {
		   $scope.alertsData = result;
	   });
		for (var key in $scope.alertsData) {								
			if ($scope.alertsData[key].opportunityNumber == oppNumber)  {						       	
						$scope.alertsData[key].selected = true;
					}  else{ $scope.alertsData[key].selected = false; }

		}	
		alertService.getAlertDetail().then(function(result) {
				$scope.result = result;
			   console.log($scope.result[0].alertId)
	   });
		
    }]);
});
