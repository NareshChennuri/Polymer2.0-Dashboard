define(['angular', './sample-module'], function(angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('AdminsCtrl', ['$scope', '$log', 'PredixAssetService', 'PredixViewService', 'alertService', '$compile', function($scope, $log, PredixAssetService, PredixViewService, alertService, $compile) {
		
        // window.onload = load;
        $(document).ready(function() {
			$('.more').on('change',function(){
				$('.moreText').text($(this).val());
			});
        });
    }]);
	
});