define(['angular', './sample-module'], function (angular, sampleModule) {
    'use strict';

    sampleModule.factory('alertService', ['$http','$rootScope', '$q', function ($http,$rootScope, $q) {
                                return {
        	isValidUser: function () {
                var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
                $http({
				  method: 'GET',
				  url: localStorage.baseUrl + 'user_validation?userid=' + $(".u-mh--").html(),
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					  'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					  'Access-Control-Max-Age': '3600',
					  'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
                return deferred.promise;
            },
            getAlert: function () {
                var deferred = $q.defer();
				$http.get('sample-data/sample-alert.json')
                    .then(function (res) {
                        deferred.resolve(res.data);
                    },
                    function () {
                        deferred.reject('Error fetching decks with tags');
                    });
                return deferred.promise;
            },
            getAlertDetail: function () {
                var deferred = $q.defer();
                $http.get('sample-data/sample-alert-detail.json')
                    .then(function (res) {
                        deferred.resolve(res.data);
                   },
                    function () {
                        deferred.reject('Error fetching decks with tags');
                    });
                return deferred.promise;
            },
            countryChange: function (countryId, role_id, current_user) {
                var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
                $http({
				  method: 'GET',
				  url: localStorage.baseUrl+'countryChange?country_id='+countryId+'&role_id='+role_id+'&current_user='+current_user,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
             'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
             'Access-Control-Max-Age': '3600',
             'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
                    $("#outerSpinner").hide();
                    if(err.status==500) {
                        deferred.reject(err);
                    }
				  return err;
			  });
                return deferred.promise;
            },
            countryList: function () {
                var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
                $http({
				  method: 'GET',
				  url: localStorage.baseUrl+'countries_list',
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
             'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
             'Access-Control-Max-Age': '3600',
             'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();

			  }, function(err) {
                    if(err.status==500) {
                        deferred.reject(err);
                    }
				  $("#outerSpinner").hide();
				  return err;
			  });
                return deferred.promise;
            },
            recommend: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'recommend',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
            aep: function ($data) {
               var deferred = $q.defer();
			   var $spinner =  $("#spinner");
			   $("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'aepCalc',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
            npv: function ($data, all) {
                if(!all){
                    all = 'no';
                }
               var deferred = $q.defer();
			   var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				if(all=='all')
					var url = localStorage.baseUrl+'npvCalculationsAll';
				else
					var url = localStorage.baseUrl+'npvCalculations';
				$http({
				  method: 'POST',
				  url: url,
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
            addTurbine1: function ($data) {
               var deferred = $q.defer();
			   var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'addTurbine',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
            addTurbine2: function ($data) {
               var deferred = $q.defer();
			   var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'addTurbine',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			selectmanufacturer: function ($data) {
               var deferred = $q.defer();
			   var $spinner =  $("#spinner");
			   $("#outerSpinner").show();
				$http({
				  method: 'GET',
				  url: localStorage.baseUrl+'selectmanufacturer?manufacturer='+$data.manufacturer+'&powercurvetype=global',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			saveTurbine: function ($data) {
               var deferred = $q.defer();
			   var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'saveTurbine',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			bop: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#bopouterSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'bopcal',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#bopouterSpinner").hide();

			  }, function(err) {
				  return err;
				  $("#bopouterSpinner").hide();
			  });
			  return deferred.promise;
			},
			LFCalculate: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#lfouterSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'callossfactor',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#lfouterSpinner").hide();
			  }, function(err) {
				  return err;
				  $("#lfouterSpinner").hide();
			  });
			  return deferred.promise;
            },
			windbo: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'windBO',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			windbosave: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'windBOSave',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			windapm: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'windAPM',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
				tariff: function ($data) {
				var deferred = $q.defer();
				$http({
				  method: 'GET',
				  url: '../../../views/Tariff.json',

				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
					console.log("tarcheck");
					console.log(data);
				  deferred.resolve(data);
			  }, function(err) {
				  return err;
			  });
			  return deferred.promise;
            },
				approval: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'GET',
				  url: '../../../views/Approval.json',

				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
					console.log("apprcheck");
					console.log(data);
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			funcmapping: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'GET',
				  url: '../../../views/Funcmap.json',

				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
					console.log("funcmapcheck");
					console.log(data);
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			depreciation: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'GET',
				  url: '../../../views/Depreciation.json',

				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
					console.log("depcheck");
					console.log(data);
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			operation: function ($data) {
				var deferred = $q.defer();
				$http({
				  method: 'GET',
				  url: '../../../views/Operation.json',

				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
					console.log("opecheck");
					console.log(data);
				  deferred.resolve(data);
			  }, function(err) {
				  return err;
			  });
			  return deferred.promise;
            },
			getpc: function ($data) {
			var deferred = $q.defer();
			var $spinner =  $("#spinner");
			$("#outerSpinner").show();
			$http({
			  method: 'GET',
			  url: '../../../views/Getpc.json',

			  headers: {
				  'X-Requested-With': 'XMLHttpRequest',
				  'Accept': 'application/json, text/plain, ',
				  'Access-Control-Allow-Origin': '*',
				 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
				 'Access-Control-Max-Age': '3600',
				 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
			 }
			}).then(function(data) {
				console.log("getpccheck");
				console.log(data);
			  deferred.resolve(data);
			  $("#outerSpinner").hide();
			}, function(err) {
			  $("#outerSpinner").hide();
			  return err;
			});
			return deferred.promise;
			},
			windapmsave: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'windAPMSave',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			windoo: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'windOO',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			windoosave: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'windOOSave',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			windcalculate: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'loadDigital',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			windsave: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'saveDigital',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
            
            getSiteConditions: function ($data) {
                var deferred = $q.defer();
                var $spinner = $("#spinner");
                $http({
                    method: 'POST',
                    url: localStorage.baseUrl + 'windConditions',
                    data: $data,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json, text/plain, ',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
                        'Access-Control-Max-Age': '3600',
                        'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
                    }
                }).then(function (data) {
                    deferred.resolve(data);
                    $("#outerSpinner").hide();
                }, function (err) {
                    $("#outerSpinner").hide();
                    return err;
                });
                return deferred.promise;
            },
            
			savesession: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'save',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
			},
			/* US251126 : savePCTurbineInfo Service Impl */
			savePCTurbineInfo: function ($data) {
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				$("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: localStorage.baseUrl+'saveWindselectPCTurbineInfo',
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  $("#outerSpinner").hide();
			  }, function(err) {
				  $("#outerSpinner").hide();
				  return err;
			  });
			  return deferred.promise;
            },
			commonpost: function ($data, $url, obj) {
				obj = obj || {};
				var commonObj = {
					spinner: true
				};
				if(obj !== undefined){
					if(obj.spinner !== undefined) {
						commonObj.spinner = obj.spinner;
					}
				}
				var deferred = $q.defer();
				var $spinner =  $("#spinner");
				commonObj.spinner && $("#outerSpinner").show();
				$http({
				  method: 'POST',
				  url: $url,
				  data:  $data,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  commonObj.spinner && $("#outerSpinner").hide();
			  }, function(err) {
				  if(err.status==500){
					  commonObj.spinner && $("#outerSpinner").hide();
					  $(".msgforsession").css("display","block");
                      deferred.reject(err);
				  }

				  return err;
			  });
			  return deferred.promise;
            },
			commonget: function ($url,obj) {
			   obj = obj || {};
			   var commonObj = {
					spinner: true
			   };
			   if(obj !== undefined){
					if(obj.spinner !== undefined) {
						commonObj.spinner = obj.spinner;
					}
			   }
               var deferred = $q.defer();
			   var $spinner =  $("#spinner");
			   $(".savesuccesfullforcolor").text();
			   commonObj.spinner && $("#outerSpinner").show();
				$http({
				  method: 'GET',
				  url: $url,
				  headers: {
					  'X-Requested-With': 'XMLHttpRequest',
					  'Accept': 'application/json, text/plain, ',
					  'Access-Control-Allow-Origin': '*',
					 'Access-Control-Allow-Methods': "POST, GET, OPTIONS, DELETE ,PUT",
					 'Access-Control-Max-Age': '3600',
					 'Access-Control-Allow-Headers': "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers,Authorization"
				 }
			  }).then(function(data) {
				  deferred.resolve(data);
				  commonObj.spinner && $("#outerSpinner").hide();
			  }, function(err) {
				    if(err.status==500){
					  commonObj.spinner && $("#outerSpinner").hide();
					  $(".savesuccesfullforcolor").css("display","block");
					  $(".savesuccesfullforspan").text(err.statusText);
                        deferred.reject(err);
				  }

				  return err;
				  commonObj.spinner && $("#outerSpinner").hide();
			  });
			  return deferred.promise;
            }
        };
    }]);
});
