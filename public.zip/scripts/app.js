/**
 * Load controllers, directives, filters, services before bootstrapping the application.
 * NOTE: These are named references that are defined inside of the config.js RequireJS configuration file.
 */
define([
    'jquery',
    'angular',
    'main',
    'routes',
    'interceptors',
    'px-datasource',
    'ng-bind-polymer'
], function ($, angular) {
    'use strict';

    /**
     * Application definition
     * This is where the AngularJS application is defined and all application dependencies declared.
     * @type {module}
     */
    var predixApp = angular.module('predixApp', [
        'app.routes',
        'app.interceptors',
        'sample.module',
        'predix.datasource',
        'px.ngBindPolymer'
    ]);

    /**
     * Main Controller
     * This controller is the top most level controller that allows for all
     * child controllers to access properties defined on the $rootScope.
     */
    predixApp.controller('MainCtrl', ['$scope', '$rootScope', 'PredixUserService', function ($scope, $rootScope, predixUserService) {
    	$rootScope.serviceBaseUrl = 'https://gewindselect.run.asv-pr.ice.predix.io';
        //Global application object
        window.App = $rootScope.App = {
            version: '1.0',
            name: 'Predix Seed',
            session: {},
            tabs: [
                {icon: 'fa-sort-amount-desc', state: 'actions', label: 'Actions', subitems: [
                    {state: 'new', label: 'New'},
                    //{state: 'save', label: 'Save'},
                    {state: 'clone', label: 'Clone'},
                    {state: 'search', label: 'Search'},
                    {state: 'getPC', label: 'Get PC'},
                    {state: 'download', label: 'Download'},
					{state: 'sessiongroup', label: 'Session Group'},
					{state: 'supplyprimary', label: 'Supply Primary'}
                ]},
                {icon: 'fa-male', state: 'admin', label: 'Admin', subitems: [
                    {state: 'powercurve', label: 'Power Curve'},
					{state: 'permissions', label: 'Permissions'},
					{state: 'maintenance', label: 'Maintenance'},
					{state: 'userapproval', label: 'User Approval'},
					{state: 'pushtooppty', label: 'Push To Oppty'},
					{state: 'searchoppty', label: 'Search Oppty'},
					{state: 'staticsreport', label: 'Stats Report'}
                ]},
                {icon: 'fa-retweet', state: 'user-preferences', label: 'User preferences'},
                {icon: 'fa-cog', state: 'digitalservices', label: 'Digital Services'},
                {icon: 'fa-tachometer', state: 'dashboards', label: 'Dashboards'},
                {icon: 'fa-question', state: 'needhelp', label: 'Log Issues/Ideas'}
            ]
        };

        $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
            if (angular.isObject(error) && angular.isString(error.code)) {
                switch (error.code) {
                    case 'UNAUTHORIZED':
                        //redirect
                        predixUserService.login(toState);
                        break;
                    default:
                        //go to other error state
                }
            }
            else {
                // unexpected error
            }
        });
    }]);
	
	// predixApp.directive('removeOnClick', function() {
    // return {
    // scope:{},
     // restrict: 'E',
      // template:'<div ng-click="remove()">Hi</div>',
        // link: function(scope, elt, attrs) {
            // scope.remove = function() {
                // elt.html('');
            // };
            
        // }
    // }
// });
	
	// predixApp.directive('myDirective', function() {
    // return {
        // restrict: 'A',
        // link: function(scope, element) {
            // scope.height = element.prop('offsetHeight');
            // scope.width = element.prop('offsetWidth');
			// }
		// };
	// });
	



    //Set on window for debugging
    window.predixApp = predixApp;

    //Return the application  object
    return predixApp;
});
