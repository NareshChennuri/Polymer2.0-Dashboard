/**
 * Router Config
 * This is the router definition that defines all application routes.
 */
define(['angular', 'angular-ui-router'], function (angular) {
    'use strict';
    return angular.module('app.routes', ['ui.router']).config(['$stateProvider', '$urlRouterProvider', '$locationProvider', function ($stateProvider, $urlRouterProvider, $locationProvider) {

        //Turn on or off HTML5 mode which uses the # hash
        $locationProvider.html5Mode(true).hashPrefix('!');

        /**
         * Router paths
         * This is where the name of the route is matched to the controller and view template.
         */
        $stateProvider
            .state('secure', {
                template: '<ui-view/>',
                abstract: true,
                resolve: {
                    authenticated: ['$q', 'PredixUserService', function ($q, predixUserService) {
                        var deferred = $q.defer();
                        predixUserService.isAuthenticated().then(function (userInfo) {
                            deferred.resolve(userInfo);
                        }, function () {
                            deferred.reject({code: 'UNAUTHORIZED'});
                        });
                        return deferred.promise;
                    }]
                }
            })
            .state('/', {
                parent: 'secure',
                url: '/actions/:id',
                templateUrl: 'views/actions.html',
                controller: 'ActionsCtrl'
            })
            .state('roletouser', {
                url: '/roletouser',
                templateUrl: 'views/roletouser2.html',
                controller: 'ActionsCtrl'
            })
            .state('managerole', {
                url: '/managerole',
                templateUrl: 'views/managerole.html',
                controller: 'ActionsCtrl'
            })
            .state('rolefunction', {
                url: '/rolefunction',
                templateUrl: 'views/rolefunction.html',
                controller: 'ActionsCtrl'
            })
            .state('supplyprimary', {
                url: '/supplyprimary',
                templateUrl: 'views/supplyprimary.html',
                controller: 'ActionsCtrl'
            })
            .state('supplyprimarycharts', {
                url: '/supplyprimarycharts',
                templateUrl: 'views/supplyPrimaryCharts.html'
            })
            .state('sensitivitycharts', {
                url: '/sensitivitycharts',
                templateUrl: 'views/sensitivityCharts.html'
            })
            .state('getpccharts', {
                url: '/getpccharts',
                templateUrl: 'views/getPCCharts.html'
            })
            .state('maintenance', {
                url: '/maintenance',
                templateUrl: 'views/admin.html',
                controller: 'ActionsCtrl'
            })
            .state('powercurve', {
                url: '/powercurve',
                templateUrl: 'views/powercurve.html',
                controller: 'ActionsCtrl'
            })
            .state('dashboards', {
                url: '/dashboards',
                templateUrl: 'views/dashboards.html'
            })
            .state('windstudio', {
                url: '/windstudio',
                templateUrl: 'views/windstudio.html',
                controller: ''
            })
            .state('timebin', {
                url: '/timebin',
                templateUrl: 'views/time-bin.html',
                controller: ''
            })
            .state('windscrsuitabilitythree', {
                url: '/windscrsuitabilitythree',
                templateUrl: 'views/windscrsuitabilitythree.html',
                controller: ''
            })
            .state('windscrsuitabilityfour', {
                url: '/windscrsuitabilityfour',
                templateUrl: 'views/windscrsuitabilityfour.html',
                controller: ''
            })
            .state('windscreenmap', {
                url: '/windscreenmap',
                templateUrl: 'views/wind-screen-map.html',
                controller: ''
            })
            .state('unauthorized', {
                url: '/unauthorized',
                templateUrl: 'views/unauthorized.html'
            });


        $urlRouterProvider.otherwise(function ($injector) {
            var $state = $injector.get('$state');
            document.querySelector('px-app-nav').markSelected('/');
            $state.go('/');
        });

    }]);
});
